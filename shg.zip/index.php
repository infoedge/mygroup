<?php
Header("HTTP/1.1 301 Moved Permanently");
if(gethostbyname(gethostname())== '127.0.0.1')
{ Header("Location: http://localhost:8080/shg/frontend/web/index.php");}
else
{Header("Location: http://www.ronwest.co.ke/frontend/web/index.php");}
?>