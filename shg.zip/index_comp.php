<?php
Header("HTTP/1.1 301 Moved Permanently");
Header("Location: http://localhost:8080/shg/frontend/web/index.php");
?>