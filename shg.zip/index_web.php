<?php
Header("HTTP/1.1 301 Moved Permanently");
Header("Location: http://www.ronwest.co.ke/frontend/web/index.php");
?>