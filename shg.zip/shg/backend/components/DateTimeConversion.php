<?php
namespace backend\components;
//use Yii;
use \yii\base\Component;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of DateTimeConversion
 *
 * @author apache
 */
class DateTimeConversion extends Component {
    //converts from yyyy-mm-dd to dd/mm/yyyy format
    public function EnglishDate($datetime){
        return date('d/m/Y',mktime(0,0,0,(int)substr($datetime,5,2),(int)substr($datetime,8,2),(int)substr($datetime,0,4)));
    }
}
