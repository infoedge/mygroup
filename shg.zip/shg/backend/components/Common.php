<?php
namespace backend\components;

use yii\base\Component;
use common\models\Permissions;

/**
 * Description of Common
 *
 * @author Apache
 */
class Common extends Component {
    /*
     * Returns an array with ControllerName,ActionName and PermissionName
     */
    public function extractPermissionNames($controllerFilename){
       if(is_file($controllerFilename) && $this->instr("Controller", $controllerFilename) ){
            $permissions=array();
            $handle = fopen($controllerFilename, 'r');
            $mypath=pathinfo($controllerFilename);
            $permissions[]['controller']= strstr($mypath['filename'],"Controller");
            do{
                $strRead=fgets($handle);
                //does string contain word action
                if($this->instr("action", $strRead)){
                    //get action name
                    $permissions[]['action']=strrchr($strRead,"action");
                    while(!feof($handle)){
                    $str_can=fgets($handle);
                         if($this->instr("can", $str_can)){
                             $mysplitStr=explode(quoteType($str_can),$str_can);
                             $permissions[]['name']=$mysplitStr[1];
                             break;
                         }
                    }
                }//if($this->instr("action", $strRead))
            }while (!feof($handle));
            fclose($handle);
            return $permissions;
        }
    }
    /*
     * Returns true if needle is in haystack else false
     */
    public function instr($needle, $haystack){
        if(strpos($haystack, $needle)){
            return TRUE;
        }
        return FALSE;
    }/*
     * determins type of quotation i.e. ' or " and returns it
     * if no quotes returns false
     */
    public function quoteType($str_in){
        if($this->instr("'", $str_in)){
            return "'";
        }elseif($this->instr('"', $str_in)){
            return '"';
        }
        return false;
    }
    /*
     * searches root + subdirectories for files with keyword
     */
    public function searchForFile($root, $keyword){
        $directories=scandir($root);
        if($directories){
            
            foreach($directories as $directory){
                if(is_dir($directory)){
                    chdir($directory);
                    $this->searchForFile(getcwd(),'Controller');
                    chdir('.');
                }elseif($this->instr("Controller",$directory)){// $directory is a file
                    $mypermissions[]=$this->extractPermissionNames($directory);
                    foreach($mypermissions as $mypermission){
                    $model= Permissions::find()->where(
                            'filename =:filename and 
                            controller=:controller and
                            action = :action and
                            permission = :permission',[
                                ':filename'=>$mypermission['filename'],
                                ':controller'=>$mypermission['controller'],
                                ':action'=>$mypermission['action'],
                                ':name'=>$mypermission['name'],
                                ]
                            )->one();
                        if($model==null){
                            $model= new Permissions();
                            $model->filename= $mypermission['filename'];
                            $model->controller=$mypermission['controller'];
                            $model->action=$mypermission['action'];
                            $model->name=$mypermission['name'];
                            $model->save();
                        }
                    }
                }
            }
        }
    }
}
