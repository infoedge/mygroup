<?php

namespace backend\components;
use Yii;
use \yii\base\Component;

use \common\models\User;
use \common\models\AuthAssignment;
use common\models\AuthItem;
use \common\models\Members;
use \common\models\People;
/**
 * Description of Authorizations
 *
 * @author apache
 */
class Authorizations extends Component {
    /*
     * Assigns a role given a peopleId;
     */
    public function assignRole($personId,$role){
        //get userid
        $theAssignment=AuthAssignment::find()->where('item_name=:item_name and user_id =:user_id',[':item_name'=>$role,':user_id'=>$this->getUserId($personId)])->one();
        if($theAssignment==null){ //confirm the assignment is not there
            $theAssignment= new AuthAssignment();
            $theAssignment->item_name=$role;
            $theAssignment->user_id=$this->getUserId($personId);
            $theAssignment->save();
        }
    }
    /*
     * Returns userId given a peopleId
     */
    public function getUserId($personId){
        $theuser=  User::find()->where('people_id=:personId',[':personId'=>$personId]);
        return $theuser->scalar();   
    }
    /*
     * returns a comma seperated list of all roles assigned to userId
     */
    public function listRoles($userId){
        $assignments=  AuthAssignment::find()->where('user_id=:userId', [':userId'=>$userId])->all();
        $allAssigns='';
        $i=0;
        foreach ($assignments as $myassigns){
           if($i==0 && $myassigns->itemName->type ==2) {
               
               $allAssigns.=$myassigns->item_name;
               $i++;
           }elseif($myassigns->itemName->type ==2){
               $allAssigns.=', '.$myassigns->item_name;
               $i++;
           }
           
        }
        return $allAssigns;
    }
    /*
     * 
     */
    public function getPeopleId($userId){
        $theUser= User::findIdentity($userId);
        return $theUser->people_id;
    }
    /*
     * 
     */
    public function getAllNextofkinIds(){
        return $rows = (new \yii\db\Query())
                        ->select('PeopleId')
                        ->from('nextofkin')->column();
    }
    public function getCurrentShortName(){
        $usermodel = User::findIdentity(Yii::$app->user->id);
        //$model=\Yii::$app->user->
        
        $person= People::findOne($usermodel->people_id);
        $currentUser='';      
        //$currentUser=$model->;
        if($person){
            return $currentUser=$person->getInitialsAndSurname();    
        }
        else{
            Yii::$app->session->setFlash('error','Sorry Could NOT get Current User');
            return null;
        }
    }
    public function getProfileShortName($personId){
        
        $person= People::findOne($personId);
        $currentUser='';      
        //$currentUser=$model->;
        if($person){
            return $currentUser=$person->getInitialsAndSurname();    
        }
        else{
            Yii::$app->session->setFlash('error','Sorry Could NOT get profile');
            return null;
        }
    }
    /*
     * Returns a real Date from meetingDates
     */
    public function getRealDate($atDate/*integer*/)
    {
        return ( new yii\db\Query())->select('MeetingDate')->from('meetings')->where(['id'=>$atDate])->scalar();
    }
            
}
