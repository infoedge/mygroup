<?php

namespace backend\controllers;

use Yii;
use \common\models\People;
use \common\models\PeopleSearch;
use \common\models\User;
//use frontend\models\SignupForm;

use \yii\web\Controller;
use \yii\web\NotFoundHttpException;
use \yii\filters\VerbFilter;
use \yii\filters\AccessControl;

/**
 * PeopleController implements the CRUD actions for People model.
 */
class PeopleController extends Controller
{
    public function behaviors()
    {
        return [
            'access'=>[
                'class'=>  AccessControl::className(),
                'only'=>['completesignup'],
                'rules'=>[
                    [
                        'allow'=>true,
                        'roles'=>['@'],
                    ],
                    
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['post'],
                ],
            ],
        ];
    }

    /**
     * Lists all People models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new PeopleSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single People model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new People model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new People();
        $backlink=Yii::$app->session['backlink'];
        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect([$backlink/*, 'id' => $model->id*/]);
            
        } else {
            return $this->render('create', [
                'model' => $model,
            ]);
        }
    }

   /**
     * Creates a new People model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     
    public function actionCompletesignup()
    {
        $model = new People();

        if ($model->load(Yii::$app->request->post()) ) {
            try{
                $model->save();
                $this->confirmUser($model->id);
                Yii::$app->session['firstlogin']=true;
                Yii::$app->session->setFlash('Success', 'Signup succesfully completed!');
                return $this->redirect(['switchboard/index']);
            }catch(Exception $ex){
                Yii::$app->session->setFlash('error','There was an error: '.$ex->getMessage());
            }
            
        } 
            return $this->render('completesignup', [
                'model' => $model,
            ]);
        
    }*/
    /**
     * 
     * 
     */
    public function actionRegisterMember()
    {
        $model = new People(['scenario' => 'memberRegistration']);
        $backlink=Yii::$app->session['backlink'];
        if($model->load(Yii::$app->request->post())  ){ 
            //$transaction = Yii::$app->db->beginTransaction();
            try {
                $model->RecordBy=Yii::$app->user->id;
                $model->RecordDate=date('Y-m-d');
                $theUser = $this->saveUser( $model->IDNo, $model->IDType, $model->email);
                if($theUser){
                    $model->save();
                    //$people_id=$model->id;
                    if($this->updateUser($model->id,$theUser)){//Update people_id in User
                        Yii::$app->session['RegisteredPersonId']=$model->id;
                        // set as member in autorizations
                        Yii::$app->authorize->assignRole($model->id,"Member");
                        Yii::$app->session->setFlash('success',$model->getFullName().' successfully registered');
                    }else{
                        Yii::$app->session->setFlash('error','unable to update user detail for '.$model->getFullName());
                    }
                }else{
                    echo " unable to save user: in actionRegisterMember";
                     Yii::$app->session->setFlash('error','unable to register '.$model->getFullName());
                }

                return $this->redirect([$backlink/*, 'id' => $model->id*/]);   
            }
            catch(Exception $ex){
                //$transaction->rollBack();
                Yii::$app->session->setFlash('error','unable to register member'.$ex->getMessage());
            }
            
        }
        return $this->render('register-member', [
            'model' => $model,
            'backlink' => $backlink,
        ]);
    }
    /**
     * 
     * 
     */
    public function actionCompleteSignup()
    {
        $model = new People();

        if ($model->load(Yii::$app->request->post()) ) {
            try{
                $model->save();
                $this->confirmUser($model->id);
                Yii::$app->session['firstlogin']=true;
                Yii::$app->session->setFlash('Success', 'Signup succesfully completed!');
                return $this->redirect(['switchboard/index']);
            }catch(Exception $ex){
                Yii::$app->session->setFlash('error','There was an error: '.$ex->getMessage());
            }
            
        } 

        return $this->render('complete-signup', [
            'model' => $model,
        ]);
    }
    /**
     * Updates an existing People model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('update', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Deletes an existing People model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the People model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return People the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = People::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
    /*
     * checks that user exists and if so updates personId and returns true
     * else returns false 
     */
    public function confirmUser($person_id)
    {   
        $retval=false;
        $myuser= User::findIdentity(Yii::$app->user->id);
        $myuser->people_id=$person_id;
        if($myuser->save()){
            $retval=true;
        }
        return $retval;
    }
    /*
     * checks that user exists and if so updates personId and returns true
     * else returns false 
     */
    public function updateUser($person_id,$userId)
    {   
        $retval=false;
        $myuser= User::findIdentity($userId);
        $myuser->people_id=$person_id;
        if($myuser->save()){
            $retval=true;
        }
        return $retval;
    }
    /**
     * returns true if user exists else false
     * 
     */
    public function checkUser($person_id)
    {   
        $retval=false;
        $myuser= User::find()->where(['people_id'=>$person_id])->one();
        
        if($myuser!==null){
            $retval=true;
        }
        return $retval;
    }
    public function saveUser($idno,$idtype,$email){
        try{
            //if(!$this->checkUser($person_id)){
                $myuser=new User();
                $myuser->username = $this->generateUsername($email) ;//$this->username;
                $myuser->email = $email;
                $myuser->idno = $idno;
                $myuser->idtype = (string)$idtype;
                //$myuser->people_id = $person_id;
                $myuser->setPassword((string)$idno);
                $myuser->generateAuthKey();
                
                if ($myuser->save()) {
                    return $myuser->id;
                }
                
                
            /*}else{
                 Yii::$app->session->setFlash('error','User already Exists ');
                return;
            }*/
        }
        catch(Exception $e){
            Yii::$app->session->setFlash('error','Unable to save '.$e->getMessage());
            return;
        }
    }
    private function generateUsername($email){
        $myusername=explode('@', $email);
        $strout=$myusername[0];
        $mystrlen= strlen($strout);
            if($mystrlen<6){ 
                for($i=$mystrlen,$k=0;$i<6;$i++,$k++){
                    $strout.=(string)$k;
                }
            }
        return $strout;
    }
}
