<?php
namespace backend\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use common\models\LoginForm;
use yii\filters\VerbFilter;
use yii\helpers\Url;

//use \common\models\Users;

/**
 * Site controller
 */
class SiteController extends Controller
{
    private $PersonsName;
    //private $is_FirstLogin;
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'only' => ['logout', 'login','index','error'],
                'rules' => [
                    [
                        'actions' => ['login', 'error'],
                        'allow' => true,
                    ],
                    [
                        'actions' => ['logout', 'index'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'logout' => ['post'],
                ],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
             
            ],
            'captcha' => [
                'class' => 'yii\captcha\CaptchaAction',
                'fixedVerifyCode' => YII_ENV_TEST ? 'testme' : null,
            ],
        ];
    }

    public function actionIndex()
    {
        return $this->render('index');
    }

    public function actionLogin()
    {
        if (!\Yii::$app->user->isGuest) {
            //if(($currentuser= $this->findUsersFullName())!==null){
            return $this->redirect(['/switchboard/index']);    
            //}
            //return $this->goHome();
        }

        $model = new LoginForm();
        if ($model->load(Yii::$app->request->post()) && $model->login()) {
            $currentuser=Yii::$app->user->getIdentity();
            if(empty($currentuser->people_id)){
                return $this->redirect(['/people/completesignup']);
            }else{
                Yii::$app->session['firstlogin']=false;
                return $this->redirect(['switchboard/index']);
            }
            
        } else {
            return $this->render('login', [
                'model' => $model,
            ]);
        }
    }

    public function actionLogout()
    {
        Yii::$app->user->logout();
        $url=Url::toRoute(str_replace('backend', 'frontend',  '/switchboard/index'),true);
        return $this->redirect($url);
    }
    /*
     * returns the users full name
     */
    public function findUsersFullName(){
        $person=  User::findIdentity(Yii::$app->user->id);
        if(!$person== null){
            $this->PersonsName=$person->people->getFullName();
        }
        return $retval;
    }
}
