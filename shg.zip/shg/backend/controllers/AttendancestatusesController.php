<?php

namespace backend\controllers;

use Yii;
use backend\models\Attendancestatuses;
use backend\models\AttendancestatusesSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * AttendancestatusesController implements the CRUD actions for Attendancestatuses model.
 */
class AttendancestatusesController extends Controller
{
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['post'],
                ],
            ],
        ];
    }

    /**
     * Lists all Attendancestatuses models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new AttendancestatusesSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Attendancestatuses model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Attendancestatuses model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        if(Yii::$app->user->can('add-meeting-attendance-statuses')){
			$model = new Attendancestatuses();
			$searchModel = new AttendancestatusesSearch();
			$dataProvider = $searchModel->search(Yii::$app->request->queryParams);

			if ($model->load(Yii::$app->request->post()) && $model->save()) {
				//return $this->redirect(['view', 'id' => $model->id]);
				Yii::$app->session->setFlash("success","Status '".$model->StatusName."' Successfully Saved!");
			} 
				return $this->render('create', [
					'model' => $model,
					'searchModel' => $searchModel,
					'dataProvider' => $dataProvider,
				]);
        }else{
            Yii::$app->session['MyPage']="'Meeting Attendance'";
            $this->redirect(['disallowed/error']);
        }
    }

    /**
     * Updates an existing Attendancestatuses model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        if(Yii::$app->user->can('alter-attendance-statuses')){
            $model = $this->findModel($id);

            if ($model->load(Yii::$app->request->post()) && $model->save()) {
                return $this->redirect(['create']);
            } else {
                return $this->render('update', [
                    'model' => $model,
                ]);
            }
        }else{
           Yii::$app->session['MyPage']="'Alter Attendance Statuses'";
            $this->redirect(['disallowed/error']); 
        }
    }

    /**
     * Deletes an existing Attendancestatuses model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['create']);
    }

    /**
     * Finds the Attendancestatuses model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Attendancestatuses the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Attendancestatuses::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
