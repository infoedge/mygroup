<?php

namespace backend\controllers;

use Yii;
use common\models\Members;
use common\models\MembersSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * MembersController implements the CRUD actions for Members model.
 */
class MembersController extends Controller
{
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['post'],
                ],
            ],
        ];
    }

    /**
     * Lists all Members models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new MembersSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Members model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Members model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {   
        $backlink = Yii::$app->session['backlink'];
        $focususer=Yii::$app->session['RegisteredPersonId'];
        $model = new Members();
        $theDate=Yii::$app->session['MeetingDate'];
        $searchModel = new MembersSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        $con=\Yii::$app->db;
        $stmt= "SELECT peopleid FROM members";
        // $con->createCommand($stmt)->queryAll();
        $currentMembers = $this->getMembersList($theDate);
        if($focususer){
            $model->peopleid=$focususer;
        }
        if ($model->load(Yii::$app->request->post()) ) {
            
            try{
            $model->RecordBy=Yii::$app->user->id;
            $model->RecordDate=date('Ymd');
            $model->save();
            Yii::$app->authorize->assignRole($focususer,'Member');//focususer contains person_id
            Yii::$app->session->setflash('Success', 'Registration of '.$model->people->getFullName().' as a member is successfully ');
            Yii::$app->session['RegisteredPersonId']='';
                if(!empty($backlink)){
                    $this->redirect([$backlink]);
                }
            }
            catch (Exception $ex){
                Yii::$app->session->setflash('error', 'Unable to Register '.$model->people->getFullName().' as member: '.$ex->getMessage());
            }
        } 
        return $this->render('create', [
            'model' => $model,
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
            'currentMembers'=>$currentMembers,
            'focususer'=>$focususer,
            'backlink' => $backlink,
        ]);
        
    }

    /**
     * Updates an existing Members model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);
        $model->peopleid=$model->people->id;
        $backlink ='/members/create';
        $focususer=Yii::$app->session['RegisteredPersonId'];
        $theDate=Yii::$app->session['MeetingDate'];
        $currentMembers = $this->getMembersList($theDate);
        $stmt= "SELECT peopleid FROM members";
        // $con->createCommand($stmt)->queryAll();
        $currentMembers = $this->getMembersList($theDate);
        if($focususer){
            $model->peopleid=$focususer;
        }
        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            Yii::$app->session->setFlash('success','Member details updated successfully');
            return $this->redirect(['create']);
        } 
            return $this->render('update', [
                'model' => $model,
                'currentMembers'=>$currentMembers,
                'focususer'=>$focususer,
                'backlink'=> $backlink,
            ]);
        
    }

    /**
     * Deletes an existing Members model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Members model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Members the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Members::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
    /*
     * 
     */
    public function getMembersList(){
        $con=\Yii::$app->db;
        $stmt= "SELECT peopleid FROM members";
        return $con->createCommand($stmt)->queryColumn();
    }
    public function actionCreatePerson(){
        //if(Yii::$app->request->post('Btn')==1 ){
                Yii::$app->session['backlink']='/members/create';
                $this->redirect(['/people/register-member']);
           // }
    }
    public function actionPdfReport(){
        //$content = $this->renderPartial('_form');
        $pdf_report= new \kartik\mpdf\Pdf([
        // set to use core fonts only
        'mode' => Pdf::MODE_CORE, 
        // A4 paper format
        'format' => Pdf::FORMAT_A4, 
        // portrait orientation
        'orientation' => Pdf::ORIENT_PORTRAIT, 
        // stream to browser inline
        'destination' => Pdf::DEST_BROWSER, 
        // your html content input
        'content' => "This is a test pdf",  
        // format content from your own css file if needed or use the
        // enhanced bootstrap css built by Krajee for mPDF formatting 
        'cssFile' => '@vendor/kartik-v/yii2-mpdf/assets/kv-mpdf-bootstrap.min.css',
        // any css to be embedded if required
        'cssInline' => '.kv-heading-1{font-size:18px}', 
         // set mPDF properties on the fly
        'options' => ['title' => 'Krajee Report Title'],
         // call mPDF methods on the fly
        'methods' => [ 
            'SetHeader'=>['Krajee Report Header'], 
            'SetFooter'=>['{PAGENO}'],
        ]
    ]);
        return $pdf_report->render();
    }
    
}
