<?php

namespace backend\controllers;

use Yii;
use backend\models\Meetingtypes;
use backend\models\MeetingtypesSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * MeetingtypesController implements the CRUD actions for Meetingtypes model.
 */
class MeetingtypesController extends Controller
{
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['post'],
                ],
            ],
        ];
    }

    /**
     * Lists all Meetingtypes models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new MeetingtypesSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Meetingtypes model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Meetingtypes model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        if(Yii::$app->user->can('define-meeting-types')){
            $model = new Meetingtypes();
            $searchModel = new MeetingtypesSearch();
            $dataProvider = $searchModel->search(Yii::$app->request->queryParams);


            if ($model->load(Yii::$app->request->post()) && $model->save()) {
                Yii::$app->session->setFlash('success','Meeting Type '.$model->TypeName.' Successfully added!');
                $model= new Meetingtypes();
                //return $this->redirect(['view', 'id' => $model->id]);
            } 
            return $this->render('create', [
                'model' => $model,
                'searchModel' => $searchModel,
                'dataProvider' => $dataProvider,
            ]);
        }else{
            Yii::$app->session['MyPage']="'Define Meeting Types'";
            $this->redirect(['disallowed/error']);
        }
        
    }

    /**
     * Updates an existing Meetingtypes model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
		if(Yii::$app->user->can('alter-meeting-types')){
			$model = $this->findModel($id);

			if ($model->load(Yii::$app->request->post()) && $model->save()) {
				return $this->redirect(['create']);
			} else {
				return $this->render('update', [
					'model' => $model,
				]);
			}
		}else{
            Yii::$app->session['MyPage']="'Alter Meeting Types'";
            $this->redirect(['disallowed/error']);
        }
    }

    /**
     * Deletes an existing Meetingtypes model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Meetingtypes model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Meetingtypes the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Meetingtypes::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
