<?php

namespace backend\controllers;

use Yii;
//use \yii\web\NotFoundHttpException;
use \yii\web\Controller;
use \yii\filters\AccessControl;
use yii\filters\VerbFilter;
use yii\helpers\Url;



//use \common\models\Users;
use \common\models\User;
//use \common\models\People;
use \backend\models\Switchboard;
use \common\models\Profile;

class SwitchboardController extends Controller
{
    public function behaviors()
    {
        return [
            'access'=>[
                'class'=>  AccessControl::className(),
                'only'=>['index'],
                'rules'=>[
                    [
                        'allow'=>TRUE,
                        'roles'=>['@'],
                    ],
                    
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['post'],
                ],
            ],
        ];
    }
    public function actionIndex()
    {
        $buttonPressedName='';
        $buttonPressedValue='';
        if(Yii::$app->session['firstlogin']==true){
            $welcomemsg= 'Welcome '; 
            $secondline = 'you have successfully signed up';
        }else{
            $welcomemsg = 'Welcome back ';
            $secondline = 'You are signed in';
        }
        $authorize=Yii::$app->authorize;
        //$myId=  \Yii::$app->user->id;
        $usermodel = User::findIdentity(Yii::$app->user->id);
        //$model=\Yii::$app->user->
        $profile= Profile::find()->where(['peopleId'=>$authorize->getPeopleId(Yii::$app->user->id)])->one();
        $myimg=  str_replace('backend','frontend',dirname(url::to(['']))).'/'.$profile->portrait;
        /*$person= People::findOne($usermodel->people_id);
        $currentUser='';      @*/
        //Get the name of the current user
        $currentUser=$usermodel->people->fullName;
        if(!$currentUser){
           Yii::$app->session->setFlash('error','Sorry Could NOT get Current User');
        }
        $model=new Switchboard();
        Yii::$app->session['model']=$model;
        if ($model->load(Yii::$app->request->post()) ) {
            //print_r(Yii::$app->request->post());
            //exit;
            //$buttonPressedName=Yii::$app->request->post();
            if(Yii::$app->request->post('Btn')==2 ){
                Yii::$app->session['MeetingDate']= $model->meetingdate;
                //Yii::$app->session->setFlash('success','Meeting Date is '.$model->meetingdate);
                return $this->redirect(['attendance/create']);
            }
            elseif (Yii::$app->request->post('Btn')==1 ) {
                Yii::$app->session['MeetingDate']= $model->meetingdate;
                //Yii::$app->session->setFlash('success','Meeting Date is '.$model->meetingdate);
                return $this->redirect(['monthlypayments/create']);
            }else{
                Yii::$app->session->setFlash('error','Meeting Date not set ');
            }
        }
        return $this->render('index',[
            
            'currentUser'=>$currentUser,
            'welcomeMsg'=>$welcomemsg,
            'secondLine'=>$secondline,
            'model'=>$model,
            'profile'=>$profile,
            'myimg'=>$myimg,
        ]);
        
    } 
    public function actionMeetingattendance(){
        $model=Yii::$app->session['model'];
        if ($model->load(Yii::$app->request->post()) ) {
            if($model->validate() ){
            Yii::$app->session['MeetingDate']= $model->meetingdate;
            Yii::$app->session->setFlash('success','Meeting Date is '.$model->meetingdate);
            return $this->redirect(['attendance/create']);
            }
            else{
               Yii::$app->session->setFlash('error','Meeting Date not set for Meeting Attendance');
               return $this->redirect(['index']);
            }
        }

    }
    public function actionEnterpayments(){
        $model=Yii::$app->session['model'];
        if ($model->load(Yii::$app->request->post()) ) {
            Yii::$app->session['MeetingDate']= $model->meetingdate;
            Yii::$app->session->setFlash('success','Meeting Date is '.$model->meetingdate);
            return $this->redirect(['monthlypayments/create']);
        }else{
               Yii::$app->session->setFlash('error','Meeting Date not set for Monthly Payments');
               return $this->redirect(['index']);
            }

    }
    public function actionMembers(){
        Yii::$app->session['backlink']='/members/create';
        $this->redirect(['/members/create']);
    }
}
