<?php

namespace backend\controllers;

use Yii;
use yii\base\Model;
use backend\models\Attendance;
use backend\models\AttendanceSearch;
use backend\models\Attendancefines;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use backend\models\Meetings;
use yii\base\Exception;

use yii\helpers\Json;
/*use yii\db\Query;

use common\models\Members;
use common\models\People;
use common\models\MembersSearch;
use common\models\PeopleSearch;
*/

/**
 * AttendanceController implements the CRUD actions for Attendance model.
 */
class AttendanceController extends Controller
{
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['post'],
                ],
            ],
        ];
    }

    /**
     * Lists all Attendance models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new AttendanceSearch();
        $dataProvider = $searchModel->with('Members.People')->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Attendance model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Attendance model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        if(Yii::$app->user->can('change-attendance-record')){
            $book = Yii::$app->authorize;
            $myMeetingDate=Yii::$app->session['MeetingDate'];
            $meetingModel=$this->findMeeting($myMeetingDate) ;
            //echo 'Meeting Date: '.$meetingModel->MeetingDate .'; MeetingDateId: '.$myMeetingDate.'<br>';
            $meetingType=$meetingModel->meetingType->TypeName;
            $models=$this->updateAttendance($myMeetingDate);
            //$models = Attendance::find()->where(['MeetingDate'=>$meetingModel->meetingType->id])->all();
            //$models= $this->findModelByParams ()                    
            
            //$updateAttendance= (new \yii\db\Query());

            if (Model::loadMultiple($models,Yii::$app->request->post())&& Model::validateMultiple($models)) {
                foreach ($models as $k=>$model){
                    //print_r($model->dirtyAttributes);
                    $this->setAttendanceStatus($model->Status, $model->MemberId, $meetingModel->id);
                    $cashAcId=$book->confirmAcctNo('Cash','Asset');
                    $acctPartName= "fine";
                    $acctType= "Revenue";
                    $memberName=$model->MemberId;
                    $transactionDate= $myMeetingDate;
                    $book->doubleEntry($cashAcId/*int*/,$acctPartName/*String*/,$acctType/*string*/,$memberName/*int*/,$transactionDate/*String format yyyy-mm-dd*/,$model->fine,2/*CR*/,'Attendance fine levied');
                }
                Yii::$app->session->setFlash("success","Attendance Record Update Completed Successfully");
            } 
              /*  return $this->render('create', [
                    'models' => $models,
                ]);*/
            $searchModel = new AttendanceSearch();
            $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

            return $this->render('create', [
                'models' => $models,
                'searchModel' => $searchModel,
                'dataProvider' => $dataProvider,
                'meetingType' => $meetingType,
                'meetingdateId' => $meetingModel->id,
                'MeetingDate' => $myMeetingDate,
            ]);
        }else{
            Yii::$app->session['MyPage']="'Attendance Record'";
            $this->redirect(['disallowed/error']);
        }
    }

    /**
     * Updates an existing Attendance model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            Yii::$app->session->setFlash('success','Member attendance record updated');
            return $this->redirect(['create']);           
        } else {
            return $this->render('update', [
                'model' => $model,
                
            ]);
        }
    }

    /**
     * Deletes an existing Attendance model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }
    /*
     * 
     */
    public function actionGetFineAmount($mymemberid,$mystatus,$mymeetingdateid){
        //echo 'MemberId: '.$mymemberid.'; Status : '.$mystatus;
        $finemodel = Attendancefines::find()->where(['AttendanceStatus'=>$mystatus])->one();
        if(!$finemodel==null ){
            $this->setAttendanceStatus($mystatus, $mymemberid, $mymeetingdateid);
            echo Json::encode($finemodel);
        }   
    }
    /**
     * Finds the Attendance model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Attendance the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Attendance::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
    /*
     * 
     */
    protected function findModelByParams($memberid,$meetingDateId,$meetingTypeId)
    {
        $book=Yii::$app->postings;
        $meetingModel=$this->findMeeting($meetingDateId) ;
        if (($model = Attendance::find()->where(['MemberId'=>$memberid,'MeetingDate'=>$meetingDateId])->one()) !== null) {
            $model->fineBal=$book->getBroughtForward($memberid,$meetingDateId,'Revenue','fine','');
            //echo "Fine Bal: ".$model->fineBal."; Member Id: ".$memberid."; Meeting Date: ".$meetingDateId."<br>";
            $model->fine = $this->getFine($model->Status, $meetingTypeId, $meetingDateId);
            //echo " In Table Fine: ".$model->fine."; Attendatbce Status: ".$model->Status."<br>";
            return $model;
        } else {
            $model=new Attendance();
            $model->MeetingDate= $meetingDateId;
            $model->MemberId= $memberid;
            $model->Status = 1;
            $model->fineBal=$book->getBroughtForward($model->MemberId,$meetingDateId,'Revenue','fine','');
            $model->fine = $this->getFine($model->Status, $meetingTypeId, $meetingDateId);
                
            $model->RecordBy = Yii::$app->user->id;
            $model->RecordDate= date('Y-m-d H:i:s');
            $model->save();
            return $model;
        }
    }
    /*
     * returns the relevant Meeting Model
     */
    public function findMeeting($theMeetingDate)
    {
        return Meetings::findOne(['MeetingDate'=>$theMeetingDate]);
    }
    public function updateAttendance($theDate)
    {
        
        $models=array();
        $meetingModel=$this->findMeeting($theDate) ;
            //echo 'Meeting Date: '.$meetingModel->MeetingDate .'; MeetingDateId: '.$myMeetingDate.'<br>';
            $meetingTypeId=$meetingModel->meetingType->id;
           // echo 'Meeting Type ID: '.$meetingTypeId.'<br>';
        $dateModel=Meetings::find()->where(['MeetingDate'=>$theDate])->one();
        $data= (new \yii\db\Query())->select('*')->from('members')->all();
        if(!$data== null){//echo 'got Data <br>';
            foreach($data as $i=>$listRow) {
                $models[]=$this->findModelByParams($listRow['id'], $dateModel->id,$meetingTypeId);
            }
        }else{ 
            //echo 'no Data'; 
            $models[] = new Attendance();
            
        }
        /*$mysql_count="SELECT COUNT(*)  FROM `members` `m` "
                . " LEFT JOIN `attendance` `a` ON a.MemberId=m.id "
                . " WHERE (`a`.`MemberId` IS NULL) AND (`m`.`JoiningDate` <=  :theDate)  AND ((`m`.`TerminationDate` IS NULL) OR (`m`.`TerminationDate` >  :theDate))";
        
        $mysql_stmt="SELECT m.id as memId FROM `members` `m` "
                . " LEFT JOIN `attendance` `a` ON a.MemberId=m.id "
                . " WHERE (`a`.`MemberId` IS NULL) AND (`m`.`JoiningDate` <=  :theDate)  AND ((`m`.`TerminationDate` IS NULL) OR (`m`.`TerminationDate` >  :theDate))";
        $con=\Yii::$app->db;
        $myQueryCount=$con->createCommand($mysql_count);
        $myQueryCount->bindParam(':theDate', $theDate);
        $recCount=$myQueryCount->queryScalar();  */         
        /*if($recCount>0){
            $myQuery=$con->createCommand($mysql_stmt);
            $myQuery->bindParam(':theDate', $theDate);
            $addList=$myQuery->queryAll();
            $dateModel=Meeting::find()->where(['MeetingDate'=>$theDate])->one();
            echo 'Update Attendance: Date: '.$theDate .'; Date ID: ' .  $dateModel->id.'<br>';    
            foreach($addList as $i=>$listRow) {
                $models[]=$this->findModelByParams($listRow['memId'], $dateModel->id);
                //$this->addAttendant($listRow['memId'],$theDate);
               // Yii::$app->session->setFlash('success','Member Id '.$listRow['memId'].' added');
            }
            //Yii::$app->session->setFlash('success',$recCount.' records added');
        }else{
           // Yii::$app->session->setflash('error','No New Attendants to add');
        }*/
        return $models;
    }
    public function addAttendant($memberId,$meetingDate){
        $meetingModel=$this->findMeeting($meetingDate) ;
        $theAttendant= new Attendance();
        //$myinsert = (new \yii\db\Query());
        try{
           // $myinsert->insert
            $theAttendant->MemberId=(int)$memberId;
            $theAttendant->MeetingDate = $meetingModel->id;//get metting date id from Meetings
            $theAttendant->Status=1;//set default meeting status
            $theAttendant->RecordBy= Yii::$app->user->id;
            $theAttendant->RecordDate=date("Y-m-d h:i:s");
            
            if($theAttendant->save(false)){
                 Yii::$app->session->setFlash('success','Member Id '.$memberId.' added');
            }else{
                Yii::$app->session->setFlash('error','unable to add Member Id '.$memberId);
            }
        }
        catch(Exception $ex){
            Yii::$app->session->setFlash('error','Member Id '.$memberId.' NOT added: '.$ex->getMessage());
        }
    }
    public function getFine($attendanceStatus,$meetingTypeId,$atDate){
        $model=  Attendancefines::find()->where(
                                    [
                                        'AttendanceStatus'=>$attendanceStatus,
                                        'MeetingType'=>$meetingTypeId,

                                        ]
                                    )
                ->one();
        if(!$model==null){
            //echo "Fine amount: ".$model->Amount;
            return $model->Amount;
        }else{
            return 0;
        }
    }
    public function setAttendanceStatus($status,$memberId,$MeetingDateId){
        $attendance = Attendance::find()
                ->where([
                    'MemberId'=>$memberId,
                    'MeetingDate'=>$MeetingDateId,
                    ])
                ->one();
        $attendance->Status = $status;
        $meetingModel =  Meetings::find($MeetingDateId)->one();
        $attendance->fine = $this->getFine($status, $meetingModel->MeetingType, $meetingModel->MeetingDate);
        $attendance->save();
        /*$query = (new yii\db\Query())
                ->update('attendance')
                ->set(['status'=>$status])
                ->where([
                    'MemberId'=>$memberId,
                    'MeetingDate'=>$MeetingDateId,
                    ])
                ->execute();*/
    }
}
