<?php

namespace backend\controllers;

use backend\models\Monthlypayments;
use Yii;
use yii\web\Controller;
use yii\base\Model;
use yii\helpers\Json;
//use \backend\modules\Finance\models\Loanrepaymentrecord;

use yii\db\Exception;
//use yii\web\HttpException;
//use backend\modules\finance\models\Loans;
//use yii\web\ForbiddenHttpException;

//use \backend\modules\Finance\models\Loanrepaymentrecord;


class MonthlypaymentsController extends Controller
{   
/**
 * MyValues array explained
 * @modelvalue = conforms to the text field form control name that the value is taken from
 * @acctPartName = modifier for Ac name
 * @acctType = Account type
 * @description = short desciiption of the reason for posting in cashbook or ledger ac
 * @payin = 1=>Debit 2=>credit
 * @ChangeCode = 0=> normal code used - only one value involved; 1=> multiple values, dependent on loantype are used
 * @ChooseTotal = special values determined in function Postpayments() when changecode=1
 * @AcNameOption = option value for CreateAccountName() function
 * @var type 
 */
    public $myValues=array(
                        0=>array("modelvalue"=>"principal","acctPartName"=>"loan","acctType"=>"Liability","description"=>"Loan Repayment","payin"=>1,"ChangeCode"=>1,"ChooseTotal"=>1,"AcNameOption"=>1),
                        1=>array("modelvalue"=>"interest","acctPartName"=>"interest","acctType"=>"Revenue","description"=>"Interest Payment","payin"=>1,"ChangeCode"=>1,"ChooseTotal"=>2,"AcNameOption"=>2),
                        2=>array("modelvalue"=>"contribution","acctPartName"=>"capital","acctType"=>"Capital","description"=>"Savings","payin"=>1,"ChangeCode"=>0,"ChooseTotal"=>0,"AcNameOption"=>1),
                        3=>array("modelvalue"=>"subscription","acctPartName"=>"subscription","acctType"=>"Revenue","description"=>"Membership payment","payin"=>1,"ChangeCode"=>0,"ChooseTotal"=>0,"AcNameOption"=>1),
                        4=>array("modelvalue"=>"loaned","acctPartName"=>"loan","acctType"=>"Liability","description"=>"Loan Taken","payin"=>2,"ChangeCode"=>1,"ChooseTotal"=>3,"AcNameOption"=>1),
                        5=>array("modelvalue"=>"benevolent","acctPartName"=>"benevolent","acctType"=>"Revenue","description"=>"Benevolent saving","payin"=>1,"ChangeCode"=>0,"ChooseTotal"=>0,"AcNameOption"=>1), 
                        6=>array("modelvalue"=>"fine","acctPartName"=>"fine","acctType"=>"Revenue","description"=>"Fine paid","payin"=>1,"ChangeCode"=>0,"ChooseTotal"=>0,"AcNameOption"=>1),
                        //interest accrued
                        7=>array("modelvalue"=>"carriedForward","acctPartName"=>"recievable","acctType"=>"Asset","description"=>"Interest on loan","payin"=>1,"ChangeCode"=>1,"ChooseTotal"=>4,"AcNameOption"=>2),
                    );
    public function actionCreate()
    {
        //Yii::$app->view->registerJs("\backend\js");
        if(Yii::$app->user->can('edit-monthly-payments')){
        $flashmsg=Yii::$app->session;
        
        $theDate=$flashmsg['MeetingDate'];
        if($theDate==''){
            $flashmsg->setFlash('error','There must be a meeting date selected!!');
            $this->redirect(['/switchboard/index']);
        }
        
        $myarr=$this->getMembersList($theDate);//array with member IDs
        $memberCount=count($myarr);
        $myCashId=Yii::$app->postings->confirmAcctNo('Cash','Asset');
        $models=$this->getPreviousPayments($myarr,$theDate,$myCashId);
        
        
        if (Model::loadMultiple($models,Yii::$app->request->post())&& Model::validateMultiple($models)) {
            foreach ($models as $k=>$model){
                $model->formdate=$theDate;
                $this->Postpayments($model, $theDate,$myarr[$k]['memId']);
            }
            $flashmsg->setFlash('Success','Saved Payments for '.$theDate);
        }elseif(Model::loadMultiple($models,Yii::$app->request->post())){
            $flashmsg->setFlash('error','Payments NOT Saved  for '.$theDate);
        }

        return $this->render('create', [
            'models' => $models,
            'meetingDate'=>$theDate,
            'memberCount'=>$memberCount,
            'myarr'=>$myarr,
            'allowLoansDisbursement'=> Yii::$app->user->can('disburse-loans'),
            'allowLoansRepay'=> Yii::$app->user->can('checkoff-loans'),
        ]);
      }else{//
          //throw new ForbiddenHttpException;
          Yii::$app->session['MyPage']="'Monthly Payments'";
          $this->redirect(['disallowed/error']);
      }
    }

    public function actionUpdate()
    {
        return $this->render('update');
    }
    
    public function actionIndex()
    {
        $mypost=Yii::$app->postings;
        $myAcctType = $mypost->getAcTypeNo('Liability');
        $model = new Monthlypayments();

        if ($model->load(Yii::$app->request->post())) {
            if ($model->validate()) {
                // form inputs are valid, do something here
                return;
            }
        }

        return $this->render('index', [
            'model' => $model,
            'myAcctType'=> $myAcctType, 
        ]);
    }
    public function getMembersList($theDate)
    {
        $array=array();
        $mysql_count="SELECT COUNT(*)  FROM `members` `m` Where( JoiningDate <= :atDate and( (TerminationDate IS NULL )OR (TerminationDate >  :atDate)))";
               /* . " LEFT JOIN `attendance` `a` ON a.MemberId=m.id "
                . " WHERE (`a`.`MemberId` IS NULL) AND (`m`.`JoiningDate` <=  ':theDate')  AND ((`m`.`TerminationDate` IS NULL) OR (`m`.`TerminationDate` >  ':theDate'))";*/
        
        /*$mysql_stmt="SELECT m.peopleid as memId FROM `members` `m` "
                . " LEFT JOIN `attendance` `a` ON a.MemberId=m.id "
                . " WHERE (`a`.`MemberId` IS NULL) AND (`m`.`JoiningDate` <=  ':theDate')  AND ((`m`.`TerminationDate` IS NULL) OR (`m`.`TerminationDate` >  ':theDate'))";*/
        $mysql_stmt="SELECT m.id as memId FROM `members` `m` Where( JoiningDate <= :atDate and( (TerminationDate IS NULL )OR (TerminationDate >  :atDate)))";
        $con=\Yii::$app->db;
        $myQueryCount=$con->createCommand($mysql_count);
        $myQueryCount->bindParam(':atDate', $theDate);
        //$myQueryCount->bindParam(':theDate', $theDate);
        $recCount=$myQueryCount->queryScalar();           
        if($recCount>0){
            $myQuery=$con->createCommand($mysql_stmt);
            //$myQuery->bindParam(':theDate', $theDate);
            //Yii::$app->session->setFlash('success',$recCount.' members available');
            $myQuery->bindParam(':atDate', $theDate);
            $retArr = $myQuery->queryAll();
            //echo "Members List: " ;
            //print_r($retArr);//echo "<br>";
            return $retArr;
        }else{
            Yii::$app->session->setflash('error','No Members available');
            //echo "Members List: ".'No Members available' ;
            return $array;
        }
    }

    public function getPreviousPayments($myMemberIds,$DBMeetingDate,$myCashId){
        $book=Yii::$app->postings;
        $loan=Yii::$app->loan;
        $memberCount= count($myMemberIds);
        if($memberCount==0){
            $models=[new MonthlyPayments()];
        }
        else{
            //set up initial values to be shown
            for($i=0;$i<count($myMemberIds);$i++){
                    $models[]=(new MonthlyPayments());
                    $models[$i]->membername=$myMemberIds[$i]["memId"];
                    $models[$i]->formdate=$DBMeetingDate;
                    $models[$i]->broughtForward=$models[$i]->prev_broughtForward =$this->getTotalBroughtForward($myMemberIds[$i]["memId"],$DBMeetingDate)+$loan->getTotalInterestBal($myMemberIds[$i]["memId"],$DBMeetingDate);
                    $models[$i]->principal=$models[$i]->prev_principal=$this->getTotalPaid($models[$i]->membername, $DBMeetingDate,1);//$book->getCashbookValue($myCashId,$book->createAccountName("loan","Liability",$models[$i]->membername),$DBMeetingDate,1/*Dr*/,"Amount");
                    $models[$i]->interest=$models[$i]->prev_interest=$this->getTotalPaid($models[$i]->membername, $DBMeetingDate,2);//$book->getCashbookValue($myCashId,$book->createAccountName("interest","Revenue",$models[$i]->membername),$DBMeetingDate,1/*Dr*/,"Amount");
                    $models[$i]->totalRepayment=$models[$i]->prev_totalRepayment=$models[$i]->principal + $models[$i]->interest;
                    $models[$i]->contribution=$models[$i]->prev_contribution = $book->getCashbookValue($myCashId,$book->createAccountName("capital","Capital",$models[$i]->membername),$DBMeetingDate,1/*Dr*/,"Amount");
                    $models[$i]->loaned=$models[$i]->prev_loaned=$this->getTotalLoaned($models[$i]->membername,$DBMeetingDate);//$book->getCashbookValue($myCashId,$book->createAccountName("loan","Liability",$models[$i]->membername),$DBMeetingDate,2/*Cr*/,"Amount");
                    $models[$i]->carriedForward=$models[$i]->prev_carriedForward=$models[$i]->broughtForward - $models[$i]->principal + $models[$i]->loaned + $loan->getTotalInterest($models[$i]->membername, $DBMeetingDate) ;
                    $models[$i]->subscription=$models[$i]->prev_subscription=$book->getCashbookValue($myCashId,$book->createAccountName("subscription","Revenue",$models[$i]->membername),$DBMeetingDate,1/*Dr*/,"Amount");
                    
                    $models[$i]->benevolent=$models[$i]->prev_benevolent=$book->getCashbookValue($myCashId,$book->createAccountName("benevolent","Revenue",$models[$i]->membername),$DBMeetingDate,1/*Dr*/,"Amount");
                    $models[$i]->fine=$models[$i]->prev_fine=$book->getCashbookValue($myCashId,$book->createAccountName("fine","Revenue",$models[$i]->membername),$DBMeetingDate,1/*Dr*/,"Amount");
            }
        }//end if
         return $models;   
    }
public function Postpayments($model, $theDate,$myNameId){
    $loan= Yii::$app->loan;
    $flashmsg = Yii::$app->session;
    try{        $somethingSaved=0;
                $book=Yii::$app->postings;
                $myCashId=$book->confirmAcctNo('Cash','Asset');
                $model->membername=$myNameId;
                $model->formdate=$transactionDate=$theDate;
                for($j=0;$j<8;$j++){
                    $myLedgerId=0;
                    $myvar=$this->myValues[$j];
                    $var=$myvar["modelvalue"];$prev_var='prev_'.$myvar["modelvalue"];$changecode=$myvar["ChangeCode"];$ChooseTotal=$myvar["ChooseTotal"];$description=$myvar['description'];
                    if((doubleval($model->$var)>0 || (doubleval($model->$prev_var)>0 && doubleval($model->$var)==0) )&& !($changecode)){
                        $myLedgerId=$book->createAccountName($myvar["acctPartName"],$myvar["acctType"],$model->membername,$myvar["AcNameOption"]);
                        //echo "MyLedgerId: ".$myLedgerId.'<br>';
                        $cashTrId=$book->postToCash($myCashId,$myLedgerId,$transactionDate,$model->$var,$myvar["payin"]/*DR or CR*/,1/*Cash*/,$myvar["description"]);
                        $ledgerTrId = $book->postToLedger($myLedgerId,$myCashId,$transactionDate,$model->$var,$this->toggle($myvar["payin"])/*CR or DR*/,1/*Cash*/,$myvar["description"]);
                        $book->updateCashbookRef($cashTrId,$ledgerTrId);
                        $book->updateLedgerRef($ledgerTrId,$cashTrId);
                        //echo "Used Single Value:="."j: ".$j."; ChooseTotal: ".$ChooseTotal."; myLedgerId: ".$myLedgerId."<br>";
                        $somethingSaved+=(2^$j);//set bits in something saved depending on myValues
                    }elseif(((doubleval($model->$var)>0) || (doubleval($model->$prev_var)>0 && doubleval($model->$var)==0) ) && $changecode/* different code */){
                        //check types of loans and and iterate over each type
                        $myloantypes=$loan->getLoanTypes($theDate,2/*Sort Desc payment priority*/);
                        $postedTotal=0;
                        foreach($myloantypes as $myloantype){
                            
                            //echo "MonthlyPayments_PostPayments:-ModelValue: ".$j."; Loan Type Name: ".$myloantype["loanTypeName"].'; acctPartName: '.$myvar["acctPartName"].'. acctType: '.$myvar["acctType"].'; Member No: '.$model->membername.'<br>';
                            switch($ChooseTotal){
                                
                                case 2:
                                    $myLedgerId=$book->createAccountName($myloantype["loanTypeName"].' '.$myvar["acctPartName"],$myvar["acctType"],$model->membername);
                                    //$myLedgerId=$book->createAccountName($myvar["acctPartName"].' on '.$myloantype["loanTypeName"],$myvar["acctType"],$myNameId,2);
                                    $postAmount= $loan->getPaidAmount($myNameId,$theDate,$myloantype['loanType'],"Interest"/* Principal or Interest*/);
                                    $description = 'Interest accrued on '.$myloantype["loanTypeName"];
                                    //echo "Account Name: ".$myvar["acctPartName"].' on '.$myloantype["loanTypeName"]."; MemberId: ".$myNameId.'; AccountType: '.$myvar["acctType"].'; myLedgerId: '.$myLedgerId.'; postAmount: '.$postAmount.'; j: '.$j.'</br>';
                                    break;
                                case 3:
                                    $myLedgerId=$book->createAccountName($myloantype["loanTypeName"].' '.$myvar["acctPartName"],$myvar["acctType"],$model->membername);
                                    $postAmount= $loan->getLoanedAmount($myNameId,$theDate,$myloantype['loanType']);
                                    $description = $myloantype["loanTypeName"]. ' taken';
                                    //echo "Account Name: ".$myvar["acctPartName"].' on '.$myloantype["loanTypeName"]."; MemberId: ".$myNameId.'; AccountType: '.$myvar["acctType"].'; myLedgerId: '.$myLedgerId.'; postAmount: '.$postAmount.'; j: '.$j.'</br>';
                                    break;
                                case 4://get interest accrued to recievables
                                    $myLedgerId=$book->createAccountName(($myvar["acctPartName"].' on '.$myloantype["loanTypeName"]),$myvar["acctType"],$model->membername,$myvar["AcNameOption"]);
                                    
                                    $postAmount= $loan->getInterestDue($myNameId,$theDate,$myloantype["loanType"],$myloantype["loanTypeName"]);
                                    $description = $myloantype["loanTypeName"]. ' interest accrued';
                                    //echo "Account Name: ".$myvar["acctPartName"].' on '.$myloantype["loanTypeName"]."; MemberId: ".$model->membername.'; AccountType: '.$myvar["acctType"].'; myLedgerId: '.$myLedgerId.'; postAmount: '.$postAmount.'; j: '.$j.'</br>';
                                    
                                    break;
                                default:
                                    $myLedgerId=$book->createAccountName($myloantype["loanTypeName"].' '.$myvar["acctPartName"],$myvar["acctType"],$model->membername);
                                    $postAmount= $loan->getPaidAmount($myNameId,$theDate,$myloantype['loanType'],"Principal"/* Principal or Interest*/);
                                    $description = 'Principal paid on '.$myloantype["loanTypeName"];
                                    //echo "Account Name: ".$myvar["acctPartName"].' on '.$myloantype["loanTypeName"]."; MemberId: ".$myNameId.'; AccountType: '.$myvar["acctType"].'; myLedgerId: '.$myLedgerId.'; postAmount: '.$postAmount.'; j: '.$j.'</br>';
                                    
                            }
                            //if(($postAmount)>0){
                            
                            //$myLedgerId=$book->createAccountName($myvar["acctPartName"],$myvar["acctType"],$model->membername);
                            switch($j){
                                case 2:
                                    //createAccountName($AcPartName,$AcTypeName/*Asset, Liability, Capital,Revenue,Expenditure*/,$memberId,$option=1){
                                    
                                    $myRecievableId=$book->createAccountName(($myvar["acctPartName"].' on '.$myloantype["loanTypeName"]),"Asset",$myNameId,2);
                                    $cashTrId=$book->postToLedger($myRecievableId,$myLedgerId,$transactionDate,$postAmount,$myvar["payin"]/*DR or CR*/,1/*Cash*/,$description);
                                   // echo "myRecievableId: " . $myRecievableId . "; cashTrId:" . $cashTrId . ";<br>";
                                    $ledgerTrId = $book->postToLedger($myLedgerId, $myRecievableId, $transactionDate, $postAmount, $this->toggle($myvar["payin"])/* CR or DR */, 1/* Cash */, $description);
                                    $book->updateLedgerRef($cashTrId, $ledgerTrId);
                                    $book->updateLedgerRef($ledgerTrId, $cashTrId);
                                //$accruedTotal+=$postAmount;
                                    echo "Used 2:="."j: ".$j."; ChooseTotal: ".$ChooseTotal."; myLedgerId: ".$myLedgerId."<br>";
                                    $somethingSaved+=(2 ^ $j);
                                break;
                                default :
                                    //echo "Used Default:="."j: ".$j."; ChooseTotal: ".$ChooseTotal."; myLedgerId: ".$myLedgerId."<br>";
                                    //$myCashId=$book->confirmAcctNo('Cash','Asset');
                                    $cashTrId=$book->postToCash($myCashId,$myLedgerId,$transactionDate,$postAmount,$myvar["payin"]/*DR or CR*/,1/*Cash*/,$description);
                                    $ledgerTrId = $book->postToLedger($myLedgerId,$myCashId,$transactionDate,$postAmount,$this->toggle($myvar["payin"])/*CR or DR*/,1/*Cash*/,$description);
                                    $book->updateCashbookRef($cashTrId,$ledgerTrId);
                                    $book->updateLedgerRef($ledgerTrId,$cashTrId);
                                    $postedTotal+=$postAmount;
                                    $somethingSaved+=(2^$j);//set bits in something saved depending on myValues
                                }
                            //}
                        }

                    }// end if
                }// end for
            //echo "Postpayments - Something Saved: ".$somethingSaved." ; theDate: ".$theDate." ; myNameId: ".$myNameId."<br>";
            return $somethingSaved;
        }
        catch(Exception $e){
            $flashmsg->setFlash('error','Unable to save MonthlyPayments!!: '.$e->getMessage().'; LineNo: '.$e->getLine().';<br>'.$e->getTraceAsString().'<br>'
                        ."ModelValue: ".$j."; Loan Type Name: ".$myloantype["loanTypeName"].'; acctPartName: '.$myvar["acctPartName"].'. acctType: '.$myvar["acctType"].'; Member No: '.$model->membername
                    );
        }
    }
    public function toggle($valuein){
        return $valuein==1?2:1;
    }
    /*
     * returns the interest amount given a memberId at a particular date after deducting principal amount
     * 
     */
    public function actionCalculateinterest($memberId,$atdate,$deductprincipal){
        $loan=Yii::$app->loan;
        if($deductprincipal>0){
            //get balance of loans 
            
            return $loan->getTotalInterest($memberId,$atdate);//to return the interest
        }
        else{
            return 0;
        }
            
        
    }
    
    
    
    /*
     *  Returns interest amount given a loantype, memeber Id and date applicable
     */
    public function getAccruedInterest($acId,$AcType,$memberId,$atdate,$amountPaid){
        $mypost=Yii::$app->postings;
        //get account id
            $myLoanAcId=$mypost->createAccountName($acId,$AcType,$memberId);
            
            //check if account has balance
            $loanbalance=($mypost->getLedgerBalance($myLoanAcId,$atdate))-$amountPaid;
            //echo 'getAccruedInterest: $myLoanAcId: '.$myLoanAcId.'; Loan Bal: '.$loanbalance.'</br>';
            if($loanbalance>0){ //balance is >0
                //if so get applicable interest rate in interesrrates table
                $interestrate=$this->getApplicableInterest($memberId,$acId,$AcType,$atdate);
                //echo " Interest: ". ($loanbalance-$amountPaid)*$interestrate."; Member ID: ".$memberId." ; At Date: ".$atdate." ; a/c Type: ".$AcType."; A". "a/c ID: ".$acId."<br>";
                return ($loanbalance*$interestrate)/100;
            }else{
                //echo "Accrued Interest: 0 ; Member ID: ".$memberId." ; At Date: ".$atdate." ; a/c Type: ".$AcType."; A". "a/c ID: ".$acId."<br>";
                return 0;
            }
    }
     
    public function actionGetMemberId($mymemberId){
        Yii::$app->session['myMemberId']=$mymemberId;
         $myarr=array();
            $myarr['memberid']= $mymemberId;
        echo Json::encode($myarr);
    }
    /*
     * returns totals for principal or Interest for a particular member for a particular date
     */
    public function getTotalPaid($memberid,$atDate,$whichValue=1/*1=principal; 2=interest*/){
        $mycon= Yii::$app->db;
        switch($whichValue){
            case 1:
                $stmt='Select sum(Principal) From loanrepaymentrecord where (MemberId=:memberid and PayDate=:paydate)';
                break;
            case 2:
                $stmt='Select sum(Interest) From loanrepaymentrecord where (MemberId=:memberid and PayDate=:paydate)';
        }
      $myvalue =$mycon->createCommand($stmt);
      $myvalue->bindParam(':memberid', $memberid);
      $myvalue->bindParam(':paydate', $atDate);
      $retval=$myvalue->queryScalar();
      if(empty($retval)){
          $retval=0;
      }
      //echo "Total Paid: ".$retval."; Member ID: ".$memberid." ; At Date: ".$atDate."<br>";
      return $retval;
    }
    /*
     * returns totals Loaned for principal or Interest for a particular member for a particular date
     */
    public function getTotalLoaned($memberid,$atDate){
        $mycon= Yii::$app->db;
        
                $stmt='Select sum(Amount) From loanstaken where (MemberId=:memberid and LoanedDate=:paydate)';
                
      $myvalue =$mycon->createCommand($stmt);
      $myvalue->bindParam(':memberid', $memberid);
      $myvalue->bindParam(':paydate', $atDate);
      $retval=$myvalue->queryScalar();
      if(empty($retval)){
          $retval=0;
      }
      //echo "Total Loaned: ".$retval."; Member ID: ".$memberid." ; At Date: ".$atDate."<br>";
      return $retval;
    }
    
    
    
    
    /**
     *  Calculates total Brought Forward for all Loans accounts for a particular member at a certain date
     */
    public function getTotalBroughtForward($memberId,$atDate){
        //getTotalBroughtForward($myMemberIds[$i]["memId"],$DBMeetingDate)
        $book=Yii::$app->postings;
        $loan = Yii::$app->loan;
        $myloantypes = $loan->getLoanTypes($atDate);
        $totalBF=0;
        for($i=0;$i<count($myloantypes);$i++){
            $totalBF +=$book->getBroughtForward($memberId,$atDate ,"Liability","loan",$myloantypes[$i]["loanTypeName"]);
                        //+$book->getBroughtForward($memberId,$atDate ,"Asset","loan",$myloantypes[$i]["loanTypeName"],2);           
        }
        //echo "Total B/F : ".$totalBF." ; memberId: ".$memberId." ; at Date: ".$atDate."<br>";
        return $totalBF;
    }
    /**
     * removes  totals from CashBook for a particular date for a particular member
     */
    public function clearDoubleEntryTotals($atDate,$memberid){
        $mysql= (new \yii\db\Query());
        //$result = $mysql->delete('id');
    }
    public function actionInterestAmount($mymemberid,$atdate){
        $loan = Yii::$app->loan;
        //$atdate = Yii::$app->session['MeetingDate'];
        $myinterest=array();
            $myinterest["amount"]=  $loan->getTotalInterest($mymemberid, $atdate) ;
        echo Json::encode($myinterest);
        
    }
}
