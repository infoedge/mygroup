<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\helpers\Url;


/* @var $this yii\web\View */
/* @var $model backend\models\Attendancestatuses */

$this->title = Yii::t('app', 'Setup Attendance Statuses');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Attendancestatuses'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="attendanceStatuses-create">
    <div class="container">
        <div class="col-lg-10">
        <h1><?= Html::encode($this->title) ?></h1>

        <?= $this->render('_form', [
            'model' => $model,
        ]) ?>
        </div>
        <div class="col-lg-2">
                <h4>Actions</h4>
                <a class="btn btn-success btn-block" href="<?= Url::toRoute(['/switchboard/index'])  ?>">Switchboard</a>
        </div>
    </div>
    <hr>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            //'id',
            'StatusName',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
</div>
