<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;

use dosamigos\datepicker\DatePicker;
use common\models\Titles;
use common\models\Gender;
use common\models\Idtypes;
use common\models\Country;

/* @var $this yii\web\View */
/* @var $model common\models\People */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="people-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'Title')->dropDownList(ArrayHelper::map(Titles::find()->all(),'id','Title'),['prompt'=>'Select Title']) ?>

    <?= $form->field($model, 'Surname')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'FirstName')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'OtherNames')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'Gender')->dropDownList(ArrayHelper::map(Gender::find()->all(),'id','Sex'),['prompt'=>'Select Sex']) ?> 

    <?php // $form->field>($model, 'DoB')->textInput() ?>
    <?= $form->field($model, 'DoB')->widget(
            DatePicker::className(), [
                // inline too, not bad
                 'inline' => FALSE, 
                 // modify template for custom rendering
                //'template' => '<div class="well well-sm" style="background-color: #fff; width:250px">{input}</div>',
                'clientOptions' => [
                    'autoclose' => true,
                    'format' => 'yyyy-mm-dd',
                    'showyear'=>true,
                ]
        ]);?>
    <?= $form->field($model, 'phone')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'IDNo')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'IDType')->dropDownList(ArrayHelper::map(Idtypes::find()->all(),'id','TypeOfID'),['prompt'=>'Select ID Type']) ?> 

    <?= $form->field($model, 'Nationality')->dropDownList(ArrayHelper::map(Country::find()->all(),'id','CountryName'),['prompt'=>'Select Country','default'=>119]) ?> 

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? Yii::t('app', 'Submit') : Yii::t('app', 'Update'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
