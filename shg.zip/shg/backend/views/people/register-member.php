<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use yii\helpers\Url;

use common\models\Titles;
use common\models\Gender;
use common\models\Idtypes;
use common\models\Country;
use dosamigos\datepicker\DatePicker;

/* @var $this yii\web\View */
/* @var $model common\models\People */
/* @var $form ActiveForm */
$this->title = Yii::t('app', 'New Member Registration');
?>
<div class="people-register-member">
    <h2>Member Registration - Details Entry</h2>
    <!--<div class="col-sm-10">-->
    <?php $form = ActiveForm::begin(); ?>
    <div class="row">
        <div class="col-sm-3">
            <?= $form->field($model, 'Title')->dropDownList(ArrayHelper::map(Titles::find()->all(),'id','Title'),['prompt'=>'Select Title']) ?>
        </div>
        <div class="col-sm-3">
            <?= $form->field($model, 'Surname')->textInput(['maxlength' => true]) ?>
        </div>
        <div class="col-sm-3">
            <?= $form->field($model, 'FirstName')->textInput(['maxlength' => true]) ?>
        </div>
        <div class="col-sm-3">
            <?= $form->field($model, 'OtherNames')->textInput(['maxlength' => true]) ?>
        </div>
    </div>
    <div class="row">
            
        <div class="col-sm-2">
            <?= $form->field($model, 'Gender')->dropDownList(ArrayHelper::map(Gender::find()->all(),'id','Sex'),['prompt'=>'Select Gender']) ?> 
        </div>
        <div class="col-sm-2">
        <?php // $form->field>($model, 'DoB')->textInput() ?>
            <?= $form->field($model, 'DoB')->widget(
                    DatePicker::className(), [
                        // inline too, not bad
                         'inline' => FALSE, 
                         // modify template for custom rendering
                        //'template' => '<div class="well well-sm" style="background-color: #fff; width:250px">{input}</div>',
                        'clientOptions' => [
                            'autoclose' => true,
                            'format' => 'yyyy-mm-dd',
                            'showyear'=>true,
                        ]
                ]);?>
        </div>
        <div class="col-sm-3">
            <?= $form->field($model, 'phone')->textInput(['maxlength' => true]) ?>
        </div>
        <div class="col-sm-5">
            <?= $form->field($model, 'email')->textInput(['maxlength' => true]) ?>
        </div>
    </div>
    <div class="row">
        
        <div class="col-sm-4">
            <?= $form->field($model, 'IDNo')->textInput(['maxlength' => true]) ?>
        </div>
        <div class="col-sm-4">
            <?= $form->field($model, 'IDType')->dropDownList(ArrayHelper::map(Idtypes::find()->all(),'id','TypeOfID'),['prompt'=>'Select ID Type']) ?> 
        </div>
        <div class="col-sm-4">
            <?= $form->field($model, 'Nationality')->dropDownList(ArrayHelper::map(Country::find()->all(),'id','CountryName'),['prompt'=>'Select Country','default'=>119]) ?> 
        </div>
    </div>
     <div class="form-group">
            <?= Html::submitButton(Yii::t('app', 'Register'), ['class' => 'btn btn-primary','name'=>'btn' ,'value'=>1]) ?>
            <a class="btn btn-primary" href="<?= Url::toRoute([$backlink])  ?>">Cancel</a>
     </div>
    <?php ActiveForm::end(); ?>
    </div>
    <!--<div class="col-sm-2">
        
    </div>-->

</div><!-- people-register-member -->
