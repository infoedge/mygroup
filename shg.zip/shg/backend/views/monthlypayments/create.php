<?php

use yii\helpers\Html;
//use yii\widgets\ActiveForm;
use yii\bootstrap\ActiveForm;
use yii\helpers\ArrayHelper;
use yii\helpers\Url;
use yii\widgets\Pjax;
use yii\bootstrap\Modal;


use \common\models\Members;
/* @var $this yii\web\View */
/* @var $model backend\models\MonthlyPayments */
/* @var $form ActiveForm */
//$this->registerJsfile("/backend/js/monthlypayments.js");
$this->title="Monthly Payments";
//$this->registerJs('js/monthlypayments.js')
?>
<h1>Monthly Payments</h1>
<h5>All payments entered here are assumed to be cash payments</h5>

<div class="row">
    <div class="col-lg-10">
        <h3>Meeting Date: <?= Yii::$app->datetimeconversion->EnglishDate($meetingDate) ?></h3>
        
        <!--<h4>No of members: <?= $memberCount ?></h4>-->
    </div>
<div class="col-lg-2">
    <h4>Actions</h4>
      <a class="btn btn-success btn-block" href="<?= Url::toRoute(['/switchboard/index'])  ?>">Switchboard</a>
</div>
</div>
<hr>
<div class="col-lg-12">
<div class="monthlyPayments-create">

    <?php $form = ActiveForm::begin(); ?>
    <?= Html::hiddenInput('memberCount',$memberCount,['id'=>'memberCount']);?>
    <?= Html::hiddenInput('repaymenturl',Url::toRoute(['finance/loanrepaymentrecord/create']),['id'=>'repaymenturl']) ?>
    <?= Html::hiddenInput('loanurl',Url::toRoute(['finance/loanstaken/create']),['id'=>'loanurl']) ?>
    <?= Html::hiddenInput('atdate',$meetingDate,['id'=>'atdate']) ?>
    <?php  
    Modal::begin([
        'header'=>'<h4>Loans</h4>',
        'id'=>'loanmodal',
        'size'=>'modal-lg'
    ]);
    echo '<div id="modalcontent"></div>';
    Modal::end();
    ?>
    <div class="table-striped table-condensed">
        <div class="row">
            <strong>
            <div class="col-sm-2">
                Member Name
            </div>
            <div class="col-sm-1">
                Brought Forward
            </div>
            <div class="col-sm-1">
                Principal
            </div>
            <div class="col-sm-1">
                Interest
            </div>
            <div class="col-sm-1">
                Total Repayment
            </div>
            <div class="col-sm-1">
                Savings Contribution
            </div>
            <div class="col-sm-1">
                Subscription
            </div>
            <div class="col-sm-1">
                Benevolent
            </div>
            <div class="col-sm-1">
                Fine
            </div>
            <div class="col-sm-1">    
                Loaned
            </div>
            <div class="col-sm-1">    
                Carried Forward
            </div>
            </strong>
            
        </div><!-- row -->
        <?php  Pjax::begin() ?>
        <?php foreach($models as $i=>$model){?>
        <div class="row">
            
            <div class="col-sm-2">
                <?= $form->field($model, '['.$i.']membername')->dropDownList(ArrayHelper::map(Members::find()->all(),'id','people.FullName'),['disabled'=>'disabled','class'=>'wider'])->label(false) ?>
            </div>
            <!--<div class="col-sm-1">
                <?= $form->field($model, '['.$i.']formdate')->hiddenInput(['id'=>'monthlypayments-'.$i.'-formdate','disabled'=>'disabled'])->label(false) ?>
            <!--</div>-->
            <div class="col-sm-1">
                <?= $form->field($model, '['.$i.']broughtForward')->textInput(['id'=>'monthlypayments-'.$i.'-broughtforward','disabled'=>'disabled','class'=>'wider'])->label(false) ?>
                <?= $form->field($model, '['.$i.']prev_broughtForward')->hiddenInput(['id'=>'monthlypayments-'.$i.'-prev_broughtforward','disabled'=>'disabled'])->label(false) ?>
            </div>
            <div class="col-sm-1">
                <?= $form->field($model, '['.$i.']principal')->textInput(['id'=>'monthlypayments-'.$i.'-principal','onBlur'=>'dototals('.$i.');'/*,'onFocus'=>'allColumnTotals('.count($models).');'*/,'onChange'=>'dograndtotals('.count($models).',1);','disabled'=>(!$allowLoansRepay)?'disabled':false,'class'=>'wider'])->label(false) ?>
                <?= $form->field($model, '['.$i.']prev_principal')->hiddenInput(['id'=>'monthlypayments-'.$i.'-prev_principal','onBlur'=>'dototals('.$i.');'/*,'onFocus'=>'allColumnTotals('.count($models).');'*/,'onChange'=>'dograndtotals('.count($models).',1);','disabled'=>(!$allowLoansRepay)?'disabled':false])->label(false) ?>
            </div>
            <div class="col-sm-1">
               <!-- <?php // $form->field($model,'['.$i.']interest',['onBlur'=>'dototals('.$i.');doGrandTotals('.count($models).',2);doGrandTotals('.count($models).',3);'])->label(false) ?> -->
                <?= $form->field($model,'['.$i.']interest')->textInput(['id'=>'monthlypayments-'.$i.'-interest',/*'onBlur'=>'dototals('.$i.','.count($models).');',*/'onChange'=>'dograndtotals('.count($models).',2);','onFocus'=>'dograndtotals('.count($models).',8);','disabled'=>'disabled','class'=>'wider' ])->label(false) ?>
               <?= $form->field($model,'['.$i.']prev_interest')->hiddenInput(['id'=>'monthlypayments-'.$i.'-prev_interest',/*'onBlur'=>'dototals('.$i.','.count($models).');',*/'onChange'=>'dograndtotals('.count($models).',2);','onFocus'=>'dograndtotals('.count($models).',8);','disabled'=>(!$allowLoansRepay)?'disabled':false ])->label(false) ?>
            </div>
            <div class="col-sm-1">
                <?= $form->field($model, '['.$i.']totalRepayment')->textInput(['id'=>'monthlypayments-'.$i.'-totalrepayment','disabled'=>'disabled','class'=>'wider'])->label(false) ?>
                <?= $form->field($model, '['.$i.']prev_totalRepayment')->hiddenInput(['id'=>'monthlypayments-'.$i.'-prev_totalrepayment','disabled'=>'disabled'])->label(false) ?>
            </div>
            <div class="col-sm-1">
                <?= $form->field($model, '['.$i.']contribution')->textInput(['id'=>'monthlypayments-'.$i.'-contribution','onBlur'=>'dototals('.$i.')','onFocus'=>'dograndtotals('.count($models).',3);','class'=>'wider' ])->label(false) ?>
                <?= $form->field($model, '['.$i.']prev_contribution')->hiddenInput(['id'=>'monthlypayments-'.$i.'-prev_contribution','onBlur'=>'dototals('.$i.')','onFocus'=>'dograndtotals('.count($models).',3);','class'=>'wider' ])->label(false) ?>
            </div>
            <div class="col-sm-1">
                <?= $form->field($model, '['.$i.']subscription')->textInput(['id'=>'monthlypayments-'.$i.'-subscription','class'=>'wider'])->label(false) ?>
                <?= $form->field($model, '['.$i.']prev_subscription')->hiddenInput(['id'=>'monthlypayments-'.$i.'-prev_subscription'])->label(false) ?>
            </div>
            <div class="col-sm-1">
                <?= $form->field($model, '['.$i.']benevolent')->textInput(['id'=>'monthlypayments-'.$i.'-benevolent','class'=>'wider'])->label(false) ?>
                <?= $form->field($model, '['.$i.']prev_benevolent')->hiddenInput(['id'=>'monthlypayments-'.$i.'-prev_benevolent'])->label(false) ?>
            </div>
            <div class="col-sm-1">
                <?= $form->field($model, '['.$i.']fine')->textInput(['id'=>'monthlypayments-'.$i.'-fine','class'=>'wider'])->label(false) ?>
                <?= $form->field($model, '['.$i.']prev_fine')->hiddenInput(['id'=>'monthlypayments-'.$i.'-prev_fine'])->label(false) ?>
            </div>
            <div class="col-sm-1">    
                <?= $form->field($model, '['.$i.']loaned')->textInput(['id'=>'monthlypayments-'.$i.'-loaned','disabled'=>(!$allowLoansDisbursement)?'disabled':false,'class'=>'wider'])->label(false) ?>
                <?= $form->field($model, '['.$i.']prev_loaned')->hiddenInput(['id'=>'monthlypayments-'.$i.'-prev_loaned','disabled'=>(!$allowLoansDisbursement)?'disabled':false])->label(false) ?>
            </div>
            <div class="col-sm-1">
                <!--<?= $form->field($model, '['.$i.']accruedInterest')->hiddenInput(['id'=>'monthlypayments-'.$i.'-accruedInterest','disabled'=>(!$allowLoansDisbursement)?'disabled':false,'size'=>20])->label(false) ?>
                <?= $form->field($model, '['.$i.']prev_accruedInterest')->hiddenInput(['id'=>'monthlypayments-'.$i.'-prev_accruedInterest','disabled'=>'disabled','size'=>20])->label(false) ?>-->
                <?= $form->field($model, '['.$i.']carriedForward')->textInput(['id'=>'monthlypayments-'.$i.'-carriedforward','disabled'=>(!$allowLoansDisbursement)?'disabled':false,'class'=>'wider'])->label(false) ?>
                <?= $form->field($model, '['.$i.']prev_carriedForward')->hiddenInput(['id'=>'monthlypayments-'.$i.'-prev_carriedforward','disabled'=>'disabled','size'=>20])->label(false) ?>
            </div> 
            
        </div><!--row-->
        <?php }?>
        <?php   Pjax::end()?>
        <div class="row"><!-- Totals -->
            <strong>
            <div class="col-sm-2">
                Totals 
            </div>
            <div class="col-sm-1">
               <?= Html::input("text", 'gt_BroughtForward', "0",["size"=>5,'id'=>'gt-broughtforward','disabled'=>'disabled']) ?>
            </div>
            <div class="col-sm-1">
               <?= Html::input("text", 'gt_Principal', "0",["size"=>5,'id'=>'gt-principal','disabled'=>'disabled']) ?>
            </div>
            <div class="col-sm-1">
               <?= Html::input("text", 'gt_Interest', "0",["size"=>5,'id'=>'gt-interest','disabled'=>'disabled']) ?>
            </div>
            <div class="col-sm-1">
               <?= Html::input("text", 'gt_TotalRepayment', "0",["size"=>5,'id'=>'gt-totalrepayment','disabled'=>'disabled']) ?>
            </div>
            <div class="col-sm-1">
               <?= Html::input("text", 'gt_Contribution', "0",["size"=>5,'id'=>'gt-contribution','disabled'=>'disabled']) ?>
            </div>
            <div class="col-sm-1">
               <?= Html::input("text", 'gt_Subscription', "0",["size"=>5,'id'=>'gt-subscription','disabled'=>'disabled']) ?>
            </div>
            <div class="col-sm-1">
               <?= Html::input("text", 'gt_Benevolent', "0",["size"=>5,'id'=>'gt-benevolent','disabled'=>'disabled']) ?>
            </div>
            <div class="col-sm-1">
               <?= Html::input("text", 'gt_Fine', "0",["size"=>5,'id'=>'gt-fine','disabled'=>'disabled']) ?>
            </div>
            <div class="col-sm-1">    
               <?= Html::input("text", 'gt_Loaned', "0",["size"=>5,'id'=>'gt-loaned','disabled'=>'disabled']) ?>
            </div>
            <div class="col-sm-1">
               <?= Html::input("text", 'gt_CarriedForward', "0",["size"=>5,'id'=>'gt-carriedforward','disabled'=>'disabled']) ?>
            </div> 
          </strong>
        </div><!--row-->
    </div><!-- Table -->
        <div class="form-group">
            
            <?= Html::submitButton(Yii::t('app', 'Submit'), ['class' => 'btn btn-primary']) ?>
        </div>
        
    <?php ActiveForm::end(); ?>
    
    
</div><!-- monthlyPayments-create -->
<?php 
$script = <<< JS
 $(function (){
    var memCnt=$('#memberCount').val();
        allColumnTotals(memCnt);
    
    $('[id$=principal]').focus( function(){
        var myidx= ($(this).attr('id')).split('-');
        var mymemberId = $('#monthlypayments-'+myidx[1]+'-membername').val();
        var mybalance = $('#monthlypayments-'+myidx[1]+'-broughtforward').val();
        //alert('My Index: '+ myidx[1]+ ' ; Member No: '+ mymemberId);
        if(mybalance>0){
            $.get('index.php?r=monthlypayments/get-member-id',{mymemberId:mymemberId},function(data){
                //alert('My data is '+data);
            });
            $('#loanmodal').modal('show')
                    .find('#modalcontent')
                    .load(($('#repaymenturl').attr('value')).replace('%2F','/').replace('%2F','/'));
            //alert("here I am. My route: " + ($("#repaymenturl").attr('value')).replace('%2F','/').replace('%2F','/'));
        }else{
            alert('No outstanding loan');
        }
    });
    $('[id$=loaned]').focus( function(){
        var myidx= ($(this).attr('id')).split('-');
        var mymemberId = $('#monthlypayments-'+myidx[1]+'-membername').val();
        //var mybalance = $('#monthlypayments-'+myidx[1]+'-broughtforward').val();
        //alert('My Index: '+ myidx[1]+ ' ; Member No: '+ mymemberId);
        //if(mybalance>0){
            $.get('index.php?r=monthlypayments/get-member-id',{mymemberId:mymemberId},function(data){
                //alert('My data is '+data);
            });
            $('#loanmodal').modal('show')
                    .find('#modalcontent')
                    .load(($('#loanurl').attr('value')).replace('%2F','/').replace('%2F','/'));
            //alert("here I am. My route: " + ($("#loanurl").attr('value')).replace('%2F','/').replace('%2F','/'));
        /*}else{
            alert('No outstanding loan');
        }*/
    });   
    $('[id$=loaned]').blur( function(){
        //alert("member-count: " + memCnt);
        dograndtotals(memCnt,7);
    });
    $('[id$=fine]').blur( function(){
        //alert("member-count: " + memCnt);
        dograndtotals(memCnt,9);
    });
    $('[id$=benevolent]').blur( function(){
        //alert("member-count: " + memCnt);
        dograndtotals(memCnt,6);
    });
    $('[id$=subscription]').blur( function(){
        //alert("member-count: " + memCnt);
        dograndtotals(memCnt,5);
    });
    $('[id$=contribution]').blur( function(){
        //alert("member-count: " + memCnt);
        dograndtotals(memCnt,4);
    });
    $('[id$=contribution]').focus( function(){
        //alert("member-count: " + memCnt);
        dograndtotals(memCnt,3);
    });
    $('[id$=interest]').blur( function(){
        //alert("member-count: " + memCnt);
        dograndtotals(memCnt,2);
        var myidx= ($(this).attr('id')).split('-');
        dototals(myidx[1]);
    });
});
 $('[id$=carriedforward]').focus( function(){
        //alert("Exited loans!!!");
        var myidx= ($(this).attr('id')).split('-');
        var mymemberid = $('#monthlypayments-'+myidx[1]+'-membername').val();
        var atdate = $('#atdate').val();
        //alert("MemberId: "+mymemberid+"; atDate: "+atdate);
        
            $.get('index.php?r=monthlypayments/interest-amount',  {mymemberid :mymemberid, atdate :atdate} , function(data) {
                //alert('Got to get function: Member ID: '+mymemberid+'; At Date: ' + atdate );
                var data = $.parseJSON(data);
                //alert('My loan data is ' + data.amount);
                $(this).val($('#monthlypayments-'+myidx[1]+'-broughtForward').val()-$('#monthlypayments-'+myidx[1]+'-principal').val()+data.amount);
            });
        
 });
    function dototals(cnt)
{
    //alert('Member No '+(cnt+1));
    var ans = Number(document.getElementById('monthlypayments-'+ cnt +'-principal').value) + Number(document.getElementById('monthlypayments-'+ cnt +'-interest').value);
    document.getElementById('monthlypayments-'+ cnt +'-totalrepayment').value =ans.toString();
    var cf = Number(document.getElementById('monthlypayments-'+ cnt +'-broughtforward').value)-Number(document.getElementById('monthlypayments-'+ cnt +'-principal').value);
    document.getElementById('monthlypayments-'+ cnt +'-carriedforward').value =cf.toString();
}
function dograndtotals(loopCnt,colName)
{
    var columnNames=['broughtforward','principal','interest','totalrepayment','contribution','subscription','benevolent','loaned','carriedforward','fine']
    var result=0;
    //alert('Got here '+(loopCnt));
    
    for(i=0; i<loopCnt; i++)
    {
        //alert('Column '+colName+' = "'+columnNames[Number(colName)]+'"<br> MonthlyPayments_'+i.toString()+'_'+columnNames[Number(colName)]);
        result +=Number(document.getElementById('monthlypayments-'+i.toString()+'-'+columnNames[Number(colName)]).value);
    }
    //alert('Got here. Result = '+(result.toString()));
   document.getElementById('gt-'+columnNames[Number(colName)]).value=result.toString();
}
function allColumnTotals(loopCnt)
{
    var columnNames=['broughtforward','principal','interest','totalrepayment','contribution','subscription','benevolent','loaned','carriedforward','fine']
    var result=0;
    for(j=0;j<10;j++){
        
        //alert('Got here '+(loopCnt));
        result=0;
        for(i=0; i<loopCnt; i++)
        {
            //alert('Column '+colName+' = "'+columnNames[Number(colName)]+'"<br> MonthlyPayments_'+i.toString()+'_'+columnNames[Number(colName)]);
            result +=Number(document.getElementById('monthlypayments-'+i.toString()+'-'+columnNames[j]).value);
        }
        //alert('Got here. Result = '+(result.toString()));
       document.getElementById('gt-'+columnNames[j]).value=result.toString();
    }
}

JS;
$this->registerJs($script);
?>
        
</div>
