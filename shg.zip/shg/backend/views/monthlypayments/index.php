<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model backend\models\MonthlyPayments */
/* @var $form ActiveForm */
?>
<div class="index">
    <h1>Monthly Payment</h1>
    <!--<h4><?= 'Account Type No = ',$myAcctType ?></h4>-->
    <?php $form = ActiveForm::begin(); ?>

        <?= $form->field($model, 'membername') ?>
        <?= $form->field($model, 'formdate') ?>
        <?= $form->field($model, 'broughtForward') ?>
        <?= $form->field($model, 'principal') ?>
        <?= $form->field($model, 'interest') ?>
        <?= $form->field($model, 'totalRepayment') ?>
        <?= $form->field($model, 'contribution') ?>
        <?= $form->field($model, 'subscription') ?>
        <?= $form->field($model, 'benevolent') ?>
        <?= $form->field($model, 'loaned') ?>
        <?= $form->field($model, 'carriedForward') ?>
        <?= $form->field($model, 'fine') ?>
        
    
        <div class="form-group">
            <?= Html::submitButton(Yii::t('app', 'Submit'), ['class' => 'btn btn-primary']) ?>
        </div>
    <?php ActiveForm::end(); ?>

</div><!-- index -->
