<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model common\models\Nextofkin */

$this->title = Yii::t('app', 'Create Nextofkin');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Nextofkins'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="nextofkin-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
<?php
 $script = <<< JS
 $(function (){
         
    $('#addFamilyMember').click( function(){
         $.get('index.php?r=members/create-next-of-kin');
         alert('Clicked addFamilyMember Button');
    });
 });
JS;
$this->registerJs($script);
?>
</div>
