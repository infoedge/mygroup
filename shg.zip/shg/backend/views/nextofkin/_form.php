<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;

use \common\models\People;


/* @var $this yii\web\View */
/* @var $model common\models\Nextofkin */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="nextofkin-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'PeopleId')->dropDownList(ArrayHelper::map(People::find()->all(),'id','FullName'),['prompt'=>'-Select Name-']) ?>
    
    <?= Html::Button('Add Person to List',['url'=>'people/nextOfKin','id'=>'addFamilyMember','value'=>'1'])  ?>

    <?= $form->field($model, 'Relationship')->textInput() ?>

    <?= $form->field($model, 'RecordBy')->textInput() ?>

    <?= $form->field($model, 'RecordDate')->textInput() ?>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? Yii::t('app', 'Create') : Yii::t('app', 'Update'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
