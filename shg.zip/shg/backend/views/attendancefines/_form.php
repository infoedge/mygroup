<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;

use \backend\models\Attendancestatuses;
use \backend\models\Meetingtypes;
use dosamigos\datepicker\DatePicker;

/* @var $this yii\web\View */
/* @var $model backend\models\Attendancefines */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="attendancefines-form">
            <?php $form = ActiveForm::begin(); ?>

        <?= $form->field($model, 'AttendanceStatus')->dropDownList(ArrayHelper::map(Attendancestatuses::find()->all(),'id','StatusName'))?>

        <?= $form->field($model, 'MeetingType')->dropDownList(ArrayHelper::map(Meetingtypes::find()->all(),'id','TypeName'))?>
    
        <?= $form->field($model, 'Amount')->textInput() ?>

        <!--<?php //$form->field($model, 'StartDate')->textInput() ?>-->
        <?= $form->field($model, 'StartDate')->widget(
            DatePicker::className(), [
                // inline too, not bad
                 'inline' => FALSE, 
                 // modify template for custom rendering
                //'template' => '<div class="well well-sm" style="background-color: #fff; width:250px">{input}</div>',
                'clientOptions' => [
                    'autoclose' => true,
                    'format' => 'yyyy-mm-dd',
                    'showyear'=>true,
                ]
        ]);?>

        <?php // $form->field($model, 'EndDate')->textInput() ?>
        <?= $form->field($model, 'EndDate')->widget(
            DatePicker::className(), [
                // inline too, not bad
                 'inline' => FALSE, 
                 // modify template for custom rendering
                //'template' => '<div class="well well-sm" style="background-color: #fff; width:250px">{input}</div>',
                'clientOptions' => [
                    'autoclose' => true,
                    'format' => 'yyyy-mm-dd',
                    'showyear'=>true,
                ]
        ]);?>

        <div class="form-group">
            <?= Html::submitButton($model->isNewRecord ? Yii::t('app', 'Create') : Yii::t('app', 'Update'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
        </div>

        <?php ActiveForm::end(); ?>
    
</div>
