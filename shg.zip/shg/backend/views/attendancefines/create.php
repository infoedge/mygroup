<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\helpers\Url;



/* @var $this yii\web\View */
/* @var $model backend\models\Attendancefines */

$this->title = Yii::t('app', 'Set Attendance Fines');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Attendancefines'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="attendancefines-create">
<div class="col-lg-10">
    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
    <h3>Fines Already Imposed</h3>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            //'id',
            [   
                'label'=>'Attendance Status',
                'value'=>'attendanceStatus.StatusName',
            ],
            [
                'label'=>'Meeting Type',
                'value'=>'meetingType.TypeName',
            ],
            'Amount',
            'StartDate',
            'EndDate',

            ['class' => 'yii\grid\ActionColumn',
                'template' => '{update}',],
        ],
    ]); ?>
    </div>
    <div class="col-lg-2">
            <h4>Actions</h4>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['/switchboard/index'])  ?>">Switchboard</a>
    </div>
</div>
