<?php
/* @var $this yii\web\View */
use yii\helpers\Url;
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use yii\widgets\Pjax;

use backend\models\Meetings;
//use backend\models\Switchboard;

$this->title = 'Admin Switchboard';
 
?>
<div class="jumbotron">
        <h1><?= $welcomeMsg?></h1>
        <div class="col-sm-6" style="text-align: center">
            <h4><?= "Current User: <spsn style='color:#f00' text-align='center'>" .$currentUser."</span>" ?></h4>
            <h5><strong>Roles: </strong><?= Yii::$app->authorize->listRoles(Yii::$app->user->id) ?></h5>
            <p class="lead"><?= $secondLine?>.<!--<?= $myimg; ?>----></p>
        </div>
        <div class="col-sm-6">
            <?php echo "<img src='".$myimg."' height='150px' width='150px' style='padding:10px; align:right' class='img-circle'>"; ?>
        </div>
        
        
</div>    
    <div class="row"> <!-- comment -->
        <?php $form = ActiveForm::begin(); ?>
        <?php Pjax::begin(); ?>
        <div class="col-lg-3">
            <h3>Date</h3>
            

            <?php // $form->field($model, 'MeetingDate')->textInput() ?>

            <?= $form->field($model, 'meetingdate')->dropDownList(ArrayHelper::map(Meetings::find()->orderBy(['MeetingDate'=>SORT_DESC])->all(),'MeetingDate','EngDate'),['prompt'=>'-- Select a Date --']) ?>

        </div>
        <div class="col-lg-3">
            <h3>Payments</h3>
            <!--<a class="btn btn-success btn-block" href="<?php // Url::toRoute(['/monthlypayments/create'])  ?>">Monthly Payments</a>-->
            
                <?= Html::submitButton('Monthly Payments',['class' => 'btn btn-success btn-block','name'=>'Btn','value'=>'1']) ?>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['/finance/loans/index'])  ?>">Set Default Loan Parameters</a>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['/finance/default/index'])  ?>">Finance</a>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['/finance/cashbook/expenditure'])  ?>">Expenditure</a>
        </div>
        <div class="col-lg-3">
            <h3>Meetings</h3>
            
                <?= Html::submitButton('Meeting Attendance Record' ,['class' => 'btn btn-success btn-block','name'=>'Btn','value'=>'2']) ?>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['/meetings/create'])  ?>">Set Meeting Dates</a>
			<a class="btn btn-success btn-block" href="<?= Url::toRoute(['/attendancefines/create'])  ?>">Set Attendance Fines</a>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['/attendancestatuses/create'])  ?>">Set Attendance Statuses</a>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['/meetingtypes/create'])  ?>">Define Meeting Types</a>
            
        </div>
        <div class="col-lg-3">
            <h3>System Setup</h3>
            <a class="btn btn-success btn-block" href="<?= str_replace('backend', 'frontend',  Url::toRoute(['/switchboard/index']));?>">Go to Frontend</a>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['/allowedusers/create'])  ?>">Allowed Users ID Entry</a>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['switchboard/members'])  ?>">Register a New Member</a>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['/rbam/default/index'])  ?>">User Roles Management</a>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['/basic/default/index'])  ?>">Basic Settings</a>
        </div>
        <?php Pjax::end(); ?>
        <?php ActiveForm::end(); ?>
    </div>

