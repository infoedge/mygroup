<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\helpers\Url;

/* @var $this yii\web\View */
/* @var $model common\models\Allowedusers */

$this->title = Yii::t('app', 'Add Allowed User IDs');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Allowedusers'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="allowedusers-create">

    <h1>Add Allowed User ID No</h1>

    <?= $this->render('_form', [
        'model' => $model,
        
        ]) ?>
    <hr>
    <div class="row">
        <div class="col-lg-10">
            <h2>ID Nos Already In List</h2>
             <?= GridView::widget([
                'dataProvider' => $dataProvider,
                'filterModel' => $searchModel,
                'columns' => [
                    ['class' => 'yii\grid\SerialColumn'],

                    //'id',
                    'IDNo',

                    ['class' => 'yii\grid\ActionColumn'],
                ],
            ]); ?>
        </div><!-- col-lg-10 -->
        <div class="col-lg-2">
            <h2>Operations</h2>
            <a class="btn btn-success" href="<?= Url::toRoute(['/switchboard/index'])?>" >Back to Switchboard</a>
        </div>
    </div>
</div>
