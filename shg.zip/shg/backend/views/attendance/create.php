<?php

use yii\helpers\Html;
use yii\helpers\Url;
use yii\grid\GridView;


/* @var $this yii\web\View */
/* @var $model backend\models\Attendance */

$this->title = Yii::t('app', 'Meeting Attendance Record');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Attendances'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="attendance-create">
    <div class="col-lg-10">
        
        
            <h1><?= Html::encode($this->title).' on '.Yii::$app->datetimeconversion->EnglishDate(Yii::$app->session['MeetingDate']) ?></h1>
            <h3><strong>Meeting Type: </strong><?= $meetingType ?> </h3>

                <?= $this->render('_form', [
                    'models' => $models,
                    'meetingdateId' => $meetingdateId,
                ]) ?>
      <!--<?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            //'id',
            //'meeting.MeetingDate',
            [ 'label'=>'Member Name',
                'value'=>'member.people.FullName',
                ],
            [
                'label'=>'Status',
                'value'=>'status.StatusName',
                ],
            'fine',
            'fineBal',
            //'RecordBy',
            // 'RecordDate',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?> -->  
    </div>
    <div class="col-lg-2">
            <h4>Actions</h4>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['/switchboard/index'])  ?>">Switchboard</a>
            
    </div>
<?php 
$script = <<< JS
    $(function (){
        $('[id$=status]').change( function(){
            var myidx= ($(this).attr('id')).split('-');
            var mymemberid = $('#attendance-'+myidx[1]+'-memberId').val();
            var mystatus = $('#attendance-'+myidx[1]+'-status').val();
            var mymeetingdateid = $('#mymeetingdateid').val();
            
            //alert('My Index: '+ myidx[1]+ ' ; Member No: '+ mymemberid + ' ; Status: ' + mystatus + '; Meetingdateid: ' + mymeetingdateid);
            $.get('index.php?r=attendance/get-fine-amount',{mymemberid: mymemberid, mystatus: mystatus, mymeetingdateid: mymeetingdateid} , function(data){
                //alert('Got to Get function');
                var data = $.parseJSON(data);
                //alert('My data is ' + data);
                $('#attendance-' + myidx + '-fine').attr('value',data.amount);
                $.pjax.reload({container:'#attendancedetails'});
            });
        });
    });

JS;
$this->registerJs($script);
?>
</div>
