<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use \yii\helpers\ArrayHelper;
use yii\widgets\Pjax;

use common\models\Members;
use backend\models\Attendancestatuses;
/* @var $this yii\web\View */
/* @var $model backend\models\Attendance */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="attendance-form">

    <?php $form = ActiveForm::begin( );  ?>
    
    <div class="row"> 
        <?= Html::hiddenInput('meetingdate',$meetingdateId,['id'=>'mymeetingdateid']) ?>
        <div class="col-sm-3" style="text-align: center">
            <!--<strong>Member Name</strong>-->
            <?= $form->field($models[0], 'MemberId',[])->hiddenInput()->label() ?>
        </div>    
        <div class="col-sm-5" style="text-align: center">
            <!--<strong>Attendance Status</strong>-->
            <?= $form->field($models[0], 'Status', [])->hiddenInput()->label() ?>
        </div>    
        <div class="col-sm-2" style="text-align: center">
            <!--<strong>Current Fine (KShs)</strong>-->
            <?= $form->field($models[0], 'fine',[])->hiddenInput()->label() ?>
        </div>    
        <div class="col-sm-2" style="text-align: center">
            <!--<strong>Outstanding Fines (KShs)</strong>-->
            <?= $form->field($models[0], 'fineBal',[])->hiddenInput()->label() ?>
        </div>
    </div>
    
    <?php Pjax::begin(['id'=>'attendancedetails']); ?>
    <div class="row">
    <?php foreach($models as $i=>$model){ ?>
        <div class="col-sm-3">
        <?= $form->field($model, 'MemberId')->dropDownList(ArrayHelper::map(Members::find()->all(),'id','people.FullName'),['id'=>'attendance-'.$i.'-memberId','disabled'=>'disabled'])->label(false) ?>
        </div>    
        <div class="col-sm-5">  
        <?= $form->field($model, 'Status')->dropDownList(ArrayHelper::map(Attendancestatuses::find()->all(),'id','StatusName'),['id'=>'attendance-'.$i.'-status'])->label(false) ?>
        </div>    
        <div class="col-sm-2">
        <?= $form->field($model, 'fine')->textInput(['id'=>'attendance-'.$i.'-fine','disabled'=>'disabled'])->label(false) ?> 
        </div>    
        <div class="col-sm-2">
            <?= $form->field($model, 'fineBal')->textInput(['id'=>'attendance-'.$i.'-fineBal','disabled'=>'disabled'])->label(false) ?> 
        </div>
    <?php }?>
    </div>
    <?php Pjax::end(); ?>
    <div class="form-group">
        <?= Html::submitButton(Yii::t('app', 'Save')  , ['btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
