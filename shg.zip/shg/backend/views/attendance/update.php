<?php

use yii\helpers\Html;
use yii\helpers\Url;

/* @var $this yii\web\View */
/* @var $model backend\models\Attendance */

$this->title = Yii::t('app', 'Update {modelClass} for '.$model->member->people->getInitialsAndSurname(), [
    'modelClass' => 'Attendance',
]) /*. ' ' . $model->id*/;
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Attendances'), 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->id, 'url' => ['view', 'id' => $model->id]];
$this->params['breadcrumbs'][] = Yii::t('app', 'Update');
?>
<div class="attendance-update">

    <h1><?= Html::encode($this->title) ?></h1>
<div class="col-lg-10">
    <?= $this->render('_updform', [
        'model' => $model,
    ]) ?>
</div>
    <div class="col-lg-2">
            <h4>Actions</h4>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['attendance/create'])  ?>">Attendance</a>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['/switchboard/index'])  ?>">Switchboard</a>
    </div>
</div>
