<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\helpers\Url;

/* @var $this yii\web\View */
/* @var $model backend\models\Meetingtypes */

$this->title = Yii::t('app', 'Define Meeting Types');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Meetingtypes'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="meetingtypes-create">
    <div class="container">
        <div class="col-lg-10">
        <h1><?= Html::encode($this->title) ?></h1>

        <?= $this->render('_form', [
            'model' => $model,
        ]) ?>
        </div>
        <div class="col-lg-2">
            <h4>Actions</h4>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['/switchboard/index'])  ?>">Switchboard</a>
        </div>
    </div>
    <hr>
    <div class="container">
    <h3>Meeting Types Already Defined</h3>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            //'id',
            'TypeName',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
    </div>
</div>
