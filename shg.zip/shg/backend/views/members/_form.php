<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use \dosamigos\datepicker\DatePicker;
use yii\helpers\Url;
//use yii\jui\DatePicker;

use common\models\People;

/* @var $this yii\web\View */
/* @var $model common\models\Members */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="members-form">

    <?php $form = ActiveForm::begin(); ?>
    <div class="row">
        <div class="col-sm-7">
        <?= $form->field($model, 'peopleid')->dropDownList(ArrayHelper::map($model->getUnlistedPeople('peopleid'), 'id', 'FullName'),['prompt'=>'-Select Persons Name-','value'=>$focususer])?>
            </div>
         <div class="col-sm-2">
            
            <?= Html::img('images/common/plussign.png',['url'=>'people/create','id'=>'addPerson','value'=>'1','data-toggle'=>"popover", 'title'=>"Click to add Member Details"])  ?>
          </div>
        </div><!--row-->
        <?= $form->field($model, 'memberNo')->textInput(['maxlength' => true]) ?>
        
    
    <!--<?php //$form->field($model, 'JoiningDate')->textInput() ;?>-->
    <?= ''//$form->field($model,'JoiningDate')->widget(DatePicker::className()) ?>
    <?= $form->field($model, 'JoiningDate')->widget(
            DatePicker::className(), [
                // inline too, not bad
                 'inline' => FALSE, 
                 // modify template for custom rendering
                //'template' => '<div class="well well-sm" style="background-color: #fff; width:250px">{input}</div>',
                'clientOptions' => [
                    'autoclose' => true,
                    'format' => 'yyyy-mm-dd',
                    'showyear'=>true,
                ]
        ]);?>

    

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? Yii::t('app', 'Register') : Yii::t('app', 'Update'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
        <?= $model->isNewRecord ? '' : ( Html::a('Cancel', Url::toRoute([$backlink]),['class'=>$model->isNewRecord ? 'btn btn-success' : 'btn btn-primary'])) ?>
        <!--<a class= "<?= $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary' ?>" href= "<?= Url::toRoute([$backlink])  ?>">Cancel</a> -->
    </div>

    <?php ActiveForm::end(); ?>

</div>