<?php

use yii\helpers\Html;
use yii\helpers\Url;

/* @var $this yii\web\View */
/* @var $model common\models\Members */

$this->title = Yii::t('app', 'Update Member Details for ') . $model->people->getPersonsName();
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Members'), 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->id, 'url' => ['view', 'id' => $model->id]];
$this->params['breadcrumbs'][] = Yii::t('app', 'Update');
?>
<div class="members-update">
    
    <h1><?= Html::encode($this->title) ?></h1>
    <div class="col-sm-10">
    <?= $this->render('_form', [
        'model' => $model,
        'currentMembers'=>$currentMembers,
        'focususer'=>$focususer,
        'backlink'=>$backlink,
    ]) ?>
    </div>
    <div class="col-lg-2">
        <h3>Actions</h3>
        <p>
            <a class="btn btn-success" href="<?= Url::toRoute(['/switchboard/index'])?>" >Back to Switchboard</a>
        </p>
    </div>
</div>
