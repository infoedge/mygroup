<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\helpers\Url;

/* @var $this yii\web\View */
/* @var $model common\models\Members */

$this->title = Yii::t('app', 'Register A New Member');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Members'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="members-create">

    <h1><?= Html::encode($this->title) ?></h1>
    <div class="container">
    <div class="col-lg-10">
    <?= $this->render('_form', [
        'model' => $model,
        'currentMembers' => $currentMembers,
        'focususer'=>$focususer,
        'backlink' => $backlink,
    ]) ?>
    </div>
    <div class="col-lg-2">
        <h3>Actions</h3>
        <p>
            <a class="btn btn-success" href="<?= Url::toRoute(['/switchboard/index'])?>" >Back to Switchboard</a>
            <!--<br><br>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['members/pdf-report'])?>" >Print List</a>-->
        </p>
    </div>
    </div>
    <hr>
    <h3>Members Already Registered</h3>
     <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            //'id',
            'people.FullName',
            'memberNo',
            'JoiningDate',
            //'TerminationDate',
            // 'RecordBy',
            // 'RecordDate',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
<?php
 $script = <<< JS
 $(function (){
         
    $('#addPerson').click( function(){
         $.get('index.php?r=members/create-person');
         //alert('Clicked AddPerson Button');
    });
 });
JS;
$this->registerJs($script);
?>
</div>
