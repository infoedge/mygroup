<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model backend\modules\finance\models\Loantypes */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="loantypes-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'loanTypeName')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'RecordDate')->textInput() ?>

    <?= $form->field($model, 'RecordBy')->textInput() ?>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? Yii::t('app', 'Create') : Yii::t('app', 'Update'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
