<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use yii\helpers\Url;

use dosamigos\datepicker\DatePicker;
use backend\models\Meetingtypes;


/* @var $this yii\web\View */
/* @var $model backend\models\Meetings */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="meetings-form">

    <?php $form = ActiveForm::begin(); ?>

    <?php // $form->field($model, 'MeetingDate')->textInput() ?>
    <?= $form->field($model, 'MeetingDate')->widget(
            DatePicker::className(), [
                // inline too, not bad
                 'inline' => FALSE, 
                 // modify template for custom rendering
                //'template' => '<div class="well well-sm" style="background-color: #fff; width:250px">{input}</div>',
                'clientOptions' => [
                    'autoclose' => true,
                    'format' => 'yyyy-mm-dd',
                    'showyear'=>true,
                ]
        ]);?>
    <?= $form->field($model, 'MeetingType')->dropDownList(ArrayHelper::map(Meetingtypes::find()->all(),'id','TypeName')) ?>

   
    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? Yii::t('app', 'Create') : Yii::t('app', 'Update'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
        <?= $model->isNewRecord?'':Html::a('Cancel', url::to(['meetings/create']),['class'=>'btn btn-primary'])  ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
