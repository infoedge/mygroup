<?php

use yii\helpers\Html;
use yii\helpers\Url;

/* @var $this yii\web\View */
/* @var $model backend\models\Meetings */

$this->title = Yii::t('app', 'Update Meeting Details') ;
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Meetings'), 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->id, 'url' => ['view', 'id' => $model->id]];
$this->params['breadcrumbs'][] = Yii::t('app', 'Update');
?>
<div class="meetings-update">

    <h1><?= Html::encode($this->title) ?></h1>
    <div class="col-lg-10">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
    </div>
        <div class="col-lg-2">
            <h4>Actions</h4>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['/switchboard/index'])  ?>">Switchboard</a>
        </div>
</div>
