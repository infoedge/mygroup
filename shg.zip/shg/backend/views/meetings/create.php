<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\helpers\Url;

/* @var $this yii\web\View */
/* @var $model backend\models\Meetings */

$this->title = Yii::t('app', 'Set Meeting Dates');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Meetings'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="meetings-create">
    <div class="container">
        <div class="col-lg-10">
        <h1><?= Html::encode($this->title) ?></h1>

        <?= $this->render('_form', [
            'model' => $model,
        ]) ?>
        </div>
        <div class="col-lg-2">
            <h4>Actions</h4>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['/switchboard/index'])  ?>">Switchboard</a>
        </div>
    </div>
    <hr>
    <div class="container">
        <h4> Meeting Dates Already Set</h4>
        <?= GridView::widget([
            'dataProvider' => $dataProvider,
            'filterModel' => $searchModel,
            'columns' => [
                ['class' => 'yii\grid\SerialColumn'],

                //'id',
                'MeetingDate',
                'meetingType.TypeName',
                //'RecordBy',
                //'RecordDate',

                [
                    'class' => 'yii\grid\ActionColumn',
                    'template' => '{update}',
                    ],
            ],
        ]); ?>
    </div>
</div>
