<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "meetingtypes".
 *
 * @property integer $id
 * @property string $TypeName
 *
 * @property Attendancefines $attendancefines
 * @property Meetings[] $meetings
 */
class Meetingtypes extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'meetingtypes';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['TypeName'], 'required'],
            [['TypeName'], 'string', 'max' => 45]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'TypeName' => Yii::t('app', 'Type Name'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getAttendancefines()
    {
        return $this->hasOne(Attendancefines::className(), ['id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getMeetings()
    {
        return $this->hasMany(Meetings::className(), ['MeetingType' => 'id']);
    }
}
