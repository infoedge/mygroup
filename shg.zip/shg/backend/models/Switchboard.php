<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
namespace backend\models;

use Yii;
use \yii\base\Model;
/**
 * Description of Switchboard
 *
 * @author apache
 */

class Switchboard extends Model{
    public $meetingdate;
    public function rules()
    {
        return [
            // 
            ['meetingdate', 'required'],
            
            
        ];
    }
    public function attributeLabels()
    {
        return [
            'meetingdate' => Yii::t('app', 'Meeting Date'),
        ];
    }
    
}
