<?php

namespace backend\models;

use Yii;
use common\models\Members;

/**
 * This is the model class for table "attendance".
 *
 * @property integer $id
 * @property integer $MeetingDate
 * @property integer $MemberId
 * @property integer $Status
 * @property integer $RecordBy
 * @property string $RecordDate
 *
 * @property Attendancestatuses $status
 * @property Meetings $meetingDate
 * @property Members $member
 * @property User $recordBy
 */
class Attendance extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public $fineBal=0;
    //public $fine=0;
    
    public static function tableName()
    {
        return 'attendance';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['MeetingDate', 'MemberId', 'Status', 'RecordBy'], 'required'],
            [['MeetingDate', 'MemberId', 'Status', 'RecordBy'], 'integer'],
            [['fine'],'number'],
            [['RecordDate'], 'safe']
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'MeetingDate' => Yii::t('app', 'Meeting Date'),
            'MemberId' => Yii::t('app', 'Member Name'),
            'Status' => Yii::t('app', 'Attendance Status'),
            'fineBal' => Yii::t('app', 'Outstanding Fines (KShs)'),
            'fine' => Yii::t('app', 'Current Fine (KShs)'),
            'RecordBy' => Yii::t('app', 'Record By'),
            'RecordDate' => Yii::t('app', 'Record Date'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getStatus()
    {
        return $this->hasOne(Attendancestatuses::className(), ['id' => 'Status']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getMeetingDate()
    {
        return $this->hasOne(Meetings::className(), ['id' => 'MeetingDate']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getMember()
    {
        return $this->hasOne(Members::className(), ['id' => 'MemberId']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getRecordBy()
    {
        return $this->hasOne(User::className(), ['id' => 'RecordBy']);
    }
    
}
