<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "attendancestatuses".
 *
 * @property integer $id
 * @property string $StatusName
 *
 * @property Attendance[] $attendances
 * @property Attendancefines[] $attendancefines
 */
class Attendancestatuses extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'attendancestatuses';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['StatusName'], 'required'],
            [['StatusName'], 'string', 'max' => 45]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'StatusName' => Yii::t('app', 'Status Name'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getAttendances()
    {
        return $this->hasMany(Attendance::className(), ['Status' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getAttendancefines()
    {
        return $this->hasMany(Attendancefines::className(), ['AttendanceStatus' => 'id']);
    }
}
