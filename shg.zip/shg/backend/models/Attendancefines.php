<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "attendancefines".
 *
 * @property integer $id
 * @property integer $AttendanceStatus
 * @property integer $MeetingType
 * @property double $Amount
 * @property string $StartDate
 * @property string $EndDate
 *
 * @property Attendancestatuses $attendanceStatus
 * @property Meetingtypes $meetingType
 */
class Attendancefines extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'attendancefines';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['AttendanceStatus', 'MeetingType', 'Amount', 'StartDate'], 'required'],
            [['AttendanceStatus', 'MeetingType'], 'integer'],
            [['Amount'], 'number'],
            [['StartDate', 'EndDate'], 'safe']
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'AttendanceStatus' => Yii::t('app', 'Attendance Status'),
            'MeetingType' => Yii::t('app', 'Meeting Type'),
            'Amount' => Yii::t('app', 'Amount'),
            'StartDate' => Yii::t('app', 'Start Date'),
            'EndDate' => Yii::t('app', 'End Date'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getAttendanceStatus()
    {
        return $this->hasOne(Attendancestatuses::className(), ['id' => 'AttendanceStatus']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getMeetingType()
    {
        return $this->hasOne(Meetingtypes::className(), ['id' => 'MeetingType']);
    }
    public function getMyFine($mystatus,$mydate,$myMeetingType){
        
    }
}
