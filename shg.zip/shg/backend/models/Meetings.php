<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "meetings".
 *
 * @property integer $id
 * @property string $MeetingDate
 * @property integer $MeetingType
 * @property integer $RecordBy
 * @property string $RecordDate
 *
 * @property Attendance[] $attendances
 * @property Meetingtypes $meetingType
 */
class Meetings extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    
    public static function tableName()
    {
        return 'meetings';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['MeetingDate', 'MeetingType', 'RecordBy'], 'required'],
            [['MeetingDate', 'RecordDate'], 'safe'],
            [['MeetingType', 'RecordBy'], 'integer'],
            [['MeetingDate'], 'unique']
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'MeetingDate' => Yii::t('app', 'Meeting Date'),
            'MeetingType' => Yii::t('app', 'Meeting Type'),
            
            'RecordBy' => Yii::t('app', 'Record By'),
            'RecordDate' => Yii::t('app', 'Record Date'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getAttendances()
    {
        return $this->hasMany(Attendance::className(), ['MeetingDate' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getMeetingType()
    {
        return $this->hasOne(Meetingtypes::className(), ['id' => 'MeetingType']);
    }
    public function getEngDate(){
        return Yii::$app->datetimeconversion->EnglishDate($this->MeetingDate);
    }
}
