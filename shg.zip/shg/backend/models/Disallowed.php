<?php

namespace backend\models;

use Yii;
use yii\base\Model;

class Disallowed extends Model{
    public $backlink;
    public $page;
}
?>