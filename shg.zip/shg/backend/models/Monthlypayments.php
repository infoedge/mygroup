<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace backend\models;

use yii\base\Model;
use Yii;
/**
 * Description of MonthlyPayments
 *
 * @author apache
 */
class Monthlypayments extends model {
    public $formdate;
    public $membername;
    public $broughtForward=0.0;
    public $principal=0.0;
    public $interest=0.0;
    public $totalRepayment=0.0;
    public $loaned=0.0;
    public $carriedForward=0.0;
    public $contribution=0.0;
    public $subscription=0.0;
    public $benevolent=0.0;
    public $fine=0.0;
    public $accruedInterest=0.0;
    
    
    public $prev_broughtForward=0.0;
    public $prev_principal=0.0;
    public $prev_interest=0.0;
    public $prev_totalRepayment=0.0;
    public $prev_loaned=0.0;
    public $prev_carriedForward=0.0;
    public $prev_contribution=0.0;
    public $prev_subscription=0.0;
    public $prev_benevolent=0.0;
    public $prev_fine=0.0;
    public $prev_accruedInterest=0.0;
    
    public function rules(){
        return [
           [['broughtForward', 'principal', 'interest', 'totalRepayment', 'contribution', 'subscription', 'benevolent', 'loaned', 'carriedForward','fine'],'double'], 
           [[ 'principal', 'interest',  'contribution', 'subscription', 'benevolent', 'loaned', 'fine'],'required'], 
           ['membername','integer'],
           //['formdate','date'],
        ];
    }
    public function attributeLabels(){
        return [
            'formdate' => 'Date',
            'membername' => 'Member Name',
            'broughtForward' => 'Brought Forward',
            'principal'=>'Principal',
            'interest' => 'Interest',
            'totalRepayment' => 'Total Repayment',
            'carriedForward' => 'Carried Forward',
            'loaned'=>'Loaned',
            'contribution' => 'Savings', 
            'subscription' => 'Subs-<br>cription', 
            'benevolent' => 'Benevolent',
            
        ];
    }
    
}
