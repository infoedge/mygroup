<?php

use yii\helpers\Html;
use yii\helpers\Url;

/* @var $this yii\web\View */
/* @var $model common\models\AuthItemChild */

$this->title = Yii::t('app', 'Create Auth Item Child');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Auth Item Children'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="auth-item-child-create">

    <h1><?= Html::encode($this->title) ?></h1>
    <div class="col-sm-10">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
    </div>
    <div class="col-sm-2">
    <h4>Actions</h4>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['default/index'])  ?>">User Management Switchboard</a>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['/switchboard/index'])  ?>">Application Switchboard</a>
     </div>
</div>
