<?php

use yii\helpers\Html;
use yii\helpers\Url;

/* @var $this yii\web\View */
/* @var $model common\models\AuthItemChild */

$this->title = Yii::t('app', 'Authorization Hierarchy');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Authorization Hierarchy'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="auth-item-child-create">

    <h1><?= Html::encode($this->title) ?></h1>
    <div class="col-sm-9">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
    </div>
    <div class="col-sm-3">
    <h4>Actions</h4>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['default/index'])  ?>">User Management Switchboard</a>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['/switchboard/index'])  ?>">Application Switchboard</a>
     </div>
</div>
