<?php
use \yii\helpers\Url;

$this->title = 'User Roles Management';
?>
<div class="rbam-default-index">
   <!-- <h1><?= $this->context->action->uniqueId ?></h1>-->
    <h1><?= $this->title?></h1>
    <div class="container-fluid">
        <div class="col-sm-3"><!-- column1 -->
            <h2>Functions</h2>
            
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['authitem/index-roles'])  ?>">Define Roles</a>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['authitem/index-permissions'])  ?>">Define Permissions</a>
            <!--<a class="btn btn-success btn-block" href="<?= Url::toRoute(['authitem/index'])  ?>">Assign Permissions or Roles</a>-->
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['auth-item-child/index'])  ?>">Authorization Hierarchy</a>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['auth-assignment/index'])  ?>">Assign User Roles</a>
        </div>
        <div class="col-sm-3"><!-- column2 -->
        </div>
        <div class="col-sm-3"><!-- column3 -->
        </div>
        <div class="col-sm-3"><!-- column4 -->
            <h2>Actions</h2>
      <a class="btn btn-success btn-block" href="<?= Url::toRoute(['/switchboard/index'])  ?>">Switchboard</a>
      
        </div>
     </div>
</div>
