<?php

namespace backend\modules\rbam\controllers;

use yii\web\Controller;
use Yii;

class DefaultController extends Controller
{
    public function actionIndex()
    {
        $myuser=Yii::$app->user;
        if($myuser->can('manage-users')){
            return $this->render('index');
        }else{//user not allowed to view page
            Yii::$app->session['MyPage']="'User Roles Management'";
            $this->redirect(['/disallowed/error']);
        }
    }
}
