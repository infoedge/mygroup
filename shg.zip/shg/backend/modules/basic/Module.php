<?php

namespace backend\modules\basic;

class Module extends \yii\base\Module
{
    public $controllerNamespace = 'backend\modules\basic\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
