<?php
//use Yii;
use yii\helpers\Url;
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use yii\widgets\Pjax;

use common\models\Members;

$this->title = Yii::t('app','Basic Settings');
?>
<div class="basic-default-index">
    <h1><?= Html::encode($this->title) ?></h1>
    <div class="container-fluid">
        <?php $form = ActiveForm::begin(); ?>
        <?php Pjax::begin(); ?>
        <div class="col-sm-3"><!-- column1 -->
            <h2>Functions</h2>
            
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['titles/index'])  ?>">Titles</a>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['country/index'])  ?>">Country List</a>
            <!--<a class="btn btn-success btn-block" href="<?= Url::toRoute(['authitem/index'])  ?>">Assign Permissions or Roles</a>-->
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['idtypes/index'])  ?>">Identification Types</a>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['relationships/create'])  ?>">Family Relationships</a>
            
        </div>
        <div class="col-sm-3"><!-- column2 -->
            <h2>Members</h2>
            <?= $form->field($model, 'membername')->dropDownList(ArrayHelper::map(Members::find()->all(),'peopleid','people.FullName'),['prompt'=>'-- Select a Member --']) ?>
            <?= Html::submitButton('Profiles',['class' => 'btn btn-success btn-block']) ?>
            <!--<a class="btn btn-success btn-block" href="<?= Url::toRoute(['profile/create'])  ?>">Profiles</a>-->
        </div>
        <div class="col-sm-3"><!-- column3 -->
        </div>
        <div class="col-sm-3"><!-- column4 -->
            <h2>Actions</h2>
      <a class="btn btn-success btn-block" href="<?= Url::toRoute(['/switchboard/index'])  ?>">Switchboard</a>
      
        </div>
        <?php Pjax::end(); ?>
        <?php ActiveForm::end(); ?>
     </div>
</div>
