<?php

use yii\helpers\Html;
use yii\helpers\Url;

/* @var $this yii\web\View */
/* @var $model common\models\Profile */

$this->title = Yii::t('app', 'Member Profile');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Profiles'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="profile-create">

    <h1><?= Html::encode($this->title) ?></h1>
    <div class="col-sm-10">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
    </div>
    <div class="col-sm-2">
        <h2 style="text-align: center">Actions</h2>
        <p><a class="btn btn-success btn-block" href="<?= Url::toRoute(['default/index'])?>">Switchboard &raquo;</a></p>
        <!--<p><a class="btn btn-warning btn-block" href="<?= str_replace('backend','frontend', Url::toRoute(['basic/index']));?>">Backend &raquo;</a></p>-->
    </div>
</div>
