<?php

use yii\helpers\Html;
use yii\helpers\Url;

/* @var $this yii\web\View */
/* @var $model common\models\Profile */

$this->title = Yii::t('app', 'Update {modelClass} ', [
    'modelClass' => 'Profile',
]) /*. 'for ' . Yii::$app->authorize->getProfileShortName($personid)$model->id*/;
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Profiles'), 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->id, 'url' => ['view', 'id' => $model->id]];
$this->params['breadcrumbs'][] = Yii::t('app', 'Update');
?>
<div class="profile-update">
    <div class="col-sm-10">
        <h1><?= Html::encode($this->title) ?></h1>

        <?= $this->render('_form', [
            'model' => $model,
        ]) ?>
    </div>
    <div class="col-sm-2">
        <h2 style="text-align: center">Actions</h2>
        <p><a class="btn btn-success btn-block" href="<?= Url::toRoute(['default/index'])?>">Switchboard &raquo;</a></p>
        <!--<p><a class="btn btn-warning btn-block" href="<?= str_replace('frontend', 'backend', Url::toRoute(['/switchboard/index']));?>">Backend &raquo;</a></p>-->
    </div>
</div>
