<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\helpers\Url;

/* @var $this yii\web\View */
/* @var $model common\models\Relationships */

$this->title = Yii::t('app', 'Add Relationships');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Relationships'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="relationships-create">

    <h1><?= Html::encode($this->title) ?></h1>
	<div class="col-sm-9">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
	<?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            //'id',
            'RelationName',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
	</div>
	<div class="col-sm-3">
    <h4>Actions</h4>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['default/index'])  ?>">Basic Switchboard</a>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['/switchboard/index'])  ?>">Application Switchboard</a>
     </div>
</div>
