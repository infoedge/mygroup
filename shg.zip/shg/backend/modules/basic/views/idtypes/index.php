<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\helpers\Url;

/* @var $this yii\web\View */
/* @var $searchModel common\models\IdtypesSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'Idtypes');
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="idtypes-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>
    <div class="col-sm-9">
    <p>
        <?= Html::a(Yii::t('app', 'Create Idtypes'), ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            //'id',
            'TypeOfID',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
    </div>
    
    <div class="col-sm-3">
    <h4>Actions</h4>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['default/index'])  ?>">Basic Switchboard</a>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['/switchboard/index'])  ?>">Application Switchboard</a>
     </div>
</div>
