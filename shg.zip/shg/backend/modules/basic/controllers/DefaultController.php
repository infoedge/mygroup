<?php

namespace backend\modules\basic\controllers;

use Yii;
use yii\web\Controller;
//use yii\db\ActiveQuery;
use backend\modules\basic\models\Basicswitchboard;

use \common\models\People;

class DefaultController extends Controller
{
    public function actionIndex()
    {
        if(Yii::$app->user->can('manage-basic-settings')){
         $model= new Basicswitchboard();
         
         if ($model->load(Yii::$app->request->post()) ) {
             if(($model->membername!==null) ){
                 Yii::$app->session['MemberName']=$model->membername;
                 if($this->profileExists($model->membername)){
                     $id = $this->getProfileId($model->membername);
                     $personid= $model->membername;
                    $this->redirect(['profile/update','id'=>$id]);
                    
                 }else{
                    $this->redirect(['profile/create']);
                 }
             }
         }
        return $this->render('index',[
            'model'=> $model,
            
        ]);
        }else{
            Yii::$app->session['MyPage']="'Basic Settings'";
            $this->redirect(['/disallowed/error']);
        }
    }
    public function profileExists($personId){
        $model = People::find()->where(['id'=>$personId])->one();
        if(!$model==null){
            return $model->profileExists();
        }else{
            return false;
        }
    }
    public function getProfileID($personId){
        $model = People::find()->where(['id'=>$personId])->one();
        if(!$model==null){
            $theProfile =  $model->getProfileID();
            return $theProfile;
        }
    }
}
