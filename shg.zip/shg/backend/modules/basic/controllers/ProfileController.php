<?php

namespace backend\modules\basic\controllers;

use Yii;
use common\models\Profile;
use common\models\ProfileSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

use yii\base\Exception;
use yii\web\UploadedFile;

 

/**
 * ProfileController implements the CRUD actions for Profile model.
 */
class ProfileController extends Controller
{
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['post'],
                ],
            ],
        ];
    }

    /**
     * Lists all Profile models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new ProfileSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Profile model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Profile model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $peopleid= Yii::$app->session['MemberName'];
        $model = new Profile();
        $model->peopleId= $peopleid;
        if ($model->load(Yii::$app->request->post()) ) {
            try{
                $imageName= $this->noSpaces(Yii::$app->authorize->getCurrentShortName());
                $model->file= UploadedFile::getInstance($model,'file');
                $model->file->saveAs('images/'.$imageName.'.'.$model->file->extension);
                $model->portrait= 'images/'.$imageName.'.'.$model->file->extension;
                $model->peopleId=Yii::$app->authorize->getPeopleId(Yii::$app->user->id);
                $model->RecordDate=date('Y-m-d');
                $model->RecordBy = Yii::$app->user->id;
                $model->UpdatedBy= Yii::$app->user->id;
                $model->UpdateDate=date('Y-m-d');
                $model->save();
            Yii::$app->session->setFlash("success", "Profile saved successfully!");
            }
            catch(Exception $ex){
                Yii::$app->session->setFlash("error","unable to save profile: ".$ex->getMessage());
            }
            //return $this->redirect(['create'/*, 'id' => $model->id*/]);
        } //else {
            return $this->render('create', [
                'model' => $model,
            ]);
        //}
    }

    /**
     * Updates an existing Profile model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $peopleId= Yii::$app->session['MemberName'];
        $imageName= $this->noSpaces(Yii::$app->authorize->getProfileShortName($peopleId));
        $personid=''; 
        $model = $this->findProfileModel($peopleId);
        if($model->portrait!==NULL){
            $model->file=$model->portrait;
        }
        if ($model->load(Yii::$app->request->post()) ) {
            $model->file= UploadedFile::getInstance($model,'file');
            if($model->file!== null){
                $model->file->saveAs('images/'.$imageName.'.'.$model->file->extension);
                $model->portrait= 'images/'.$imageName.'.'.$model->file->extension;
            }
            $model->UpdatedBy= Yii::$app->user->id;
            $model->UpdateDate=date('Y-m-d');
            $model->save();
            return $this->redirect(['/switchboard/index'/*, 'id' => $model->id*/]);
        } else {
            return $this->render('update', [
                'model' => $model,
                'personid' => $personid,
            ]);
        }
    }

    /**
     * Deletes an existing Profile model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Profile model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Profile the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Profile::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested profile does not exist.');
        }
    }
    protected function findProfileModel($peopleid)
    {
        if (($model = Profile::find()->where(['peopleId'=>$peopleid])->one() ) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested profile does not exist.');
        }
    }
   
    /*
     * removes all white space from $stringIn 
     */
    public function noSpaces($stringIn){
        $strout='';
        for($i=0;$i< strlen($stringIn);$i++){
            if(substr($stringIn,$i,1)!==' '){
                $strout.=substr($stringIn,$i,1);
            }
        }
        return $strout;
    }
}
