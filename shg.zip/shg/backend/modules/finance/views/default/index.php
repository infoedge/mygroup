<?php 
use \yii\helpers\Url;
//use yii\helpers\Html;


$this->title="Finance"
?>
<div class="finance-default-index">>
   <!-- <h1><?= $this->context->action->uniqueId ?></h1>-->
    <p>
        <!--This is the view content for action "<?= $this->context->action->id ?>".
        
        The action belongs to the controller "<?= get_class($this->context) ?>"
        in the "<?= ''//.$this->context->module->id ?>" module.-->
    </p>
    <p>
       <!-- You may customize this page by editing the following file:<br>
        <code><?= __FILE__ ?></code> -->
    </p>
    <h1>Finance Switchboard</h1>
    <div class="container-fluid">
        <div class="col-sm-3">
            <h2>Accounts</h2>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['cashbook/index'])  ?>">Cashbook Entries</a>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['accountnames/create'])  ?>">Account Names</a>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['accounttypes/create'])  ?>">Account Types</a>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['transactiontypes/create'])  ?>">Transaction Types</a>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['paymenttypes/create'])  ?>">Payment Types</a>
        </div>
        <div class="col-sm-3">
            <h2>Loans</h2>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['loantypes/index'])  ?>">Loan Types</a>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['loans/index'])  ?>">Set Default Loan Parameters</a>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['loaninterest/index'])  ?>">Set Individual Loan Parameters</a>
            
        </div>
        <div class="col-sm-3">
            
        </div>
        <div class="col-sm-3">
            <h2>Actions</h2>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['default/index'])  ?>">User Management Switchboard</a>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['/switchboard/index'])  ?>">Application Switchboard</a>
        </div>
    </div>
</div>
