<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;


//use common\models\Members;
use \backend\modules\Finance\models\Loantypes;

/* @var $this yii\web\View */
/* @var $model backend\modules\finance\models\Loanstaken */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="loanstaken-form">

    <?php $form = ActiveForm::begin(); ?>
    <div class="row">
        <div class="col-sm-2">
            Loan Type
        </div>
        <div class="col-sm-2">
            Amount
         </div>
        <div class="col-sm-2">
            Loan Duration(Months)
        </div>
        <div class="col-sm-2">
            Interest(%)
        </div>
        <div class="col-sm-2">
            Due Date
        </div>  
     </div>
    <?php    foreach($models as $i=>$model){ ?>
    <div class="row">
        <div class="col-sm-2">
    <?= $form->field($model, '['.$i.']loanType')->dropDownList(ArrayHelper::map(Loantypes::find()->all(),'id','loanTypeName'),['disabled'=>'disabled','class'=>'wider'])->label(false) ?>
        </div>
        <div class="col-sm-2">
    <?= $form->field($model, '['.$i.']Amount')->textInput()->label(false) ?>
        </div>
        <div class="col-sm-2">
    <?= $form->field($model, '['.$i.']Duration')->textInput()->label(false) ?>
        </div>
        <div class="col-sm-2">
    <?= $form->field($model, '['.$i.']interest')->textInput()->label(false) ?>
        </div>
        <div class="col-sm-2">
    <?= $form->field($model, '['.$i.']dueDate')->textInput()->label(false) ?>
        </div>
    </div>
    <?php } ?>
    <div class="form-group">
        <?= Html::submitButton( 'Save', ['class' => 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
