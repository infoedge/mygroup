<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model backend\modules\finance\models\Loanstaken */

$this->title = Yii::t('app', 'Loans Disbursement');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Loanstakens'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="loanstaken-create">

    <h1><?= Html::encode($this->title) ?> For <?= $memberName ?> On <?= $models[0]->LoanedDate ?></h1>
    <!--<h3>Loan type count:<?php // count($myloantypes) ?>; loan Type 1 : <?php //foreach($myloantypes as $k=>$myloantype){echo "Loan Type ".($k+1)." : ". $myloantypes[$k]["lid"]."; ";} ?></h3>-->
    <?= $this->render('_form', [
        'models' => $models,
    ]) ?>

</div>
