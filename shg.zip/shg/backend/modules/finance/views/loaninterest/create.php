<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\helpers\Url;


/* @var $this yii\web\View */
/* @var $model backend\modules\finance\models\Loaninterest */

$this->title = Yii::t('app', 'Set Individual Loan Parameters');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Loaninterests'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="loaninterest-create">
    <div class="col-sm-10">
    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
    <hr>
    <h2>Listed Interest Rates</h2>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            //'id',
            [
                'attribute'=>'memberId',
                'value'=>('memberParticulars.PersonsName'),
                ],
            [
                'attribute'=>'loanType',
                'value'=> 'loanType0.loanTypeName',
             ],
            'Interest',
            'Duration',
            'DateStart',
            // 'DateEnd',
            // 'RecordBy',
            // 'RecordDate',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
    </div>
    <div class="col-sm-2">
        <h4>Actions</h4>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['/switchboard/index'])  ?>">Main Switchboard</a>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['default/index'])  ?>">Finance Switchboard</a>

    </div>
<?php 
$script = <<< JS
    $('#loaninterest-loantype').change(function(){
        var myloantype = $(this).val();
        //alert("There is a change in loan type!" + myloantype);
        $.get('index.php?r=finance/loaninterest/get-loan-defaults',{ myloantype : myloantype },function(data){
            //alert(data);
            var data = $.parseJSON(data);
            $('#loaninterest-amount').attr('value',data.Amount);
            $('#loaninterest-interest').attr('value',data.interest);
            $('#loaninterest-datestart').attr('value',data.DateStart);
            $('#loaninterest-duration').attr('value',data.Duration);
        });
    });
JS;
$this->registerJs($script);
?>
</div>