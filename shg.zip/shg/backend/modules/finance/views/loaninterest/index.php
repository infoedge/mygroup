<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\helpers\Url;
use yii\widgets\Pjax;

/* @var $this yii\web\View */
/* @var $searchModel backend\modules\finance\models\LoaninterestSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'Individual Loan Settings');
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="loaninterest-index">
	
    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>
	<div class="col-sm-10">
    <p>
        <?= Html::a(Yii::t('app', 'Create Loaninterest'), ['create'], ['class' => 'btn btn-success']) ?>
    </p>
    <?php Pjax::begin()?>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn',],

            //'id',
            [
                'attribute'=>'memberId',
                'value'=>'PersonsName',
            ],
            [
                'attribute'=>'loanType',
                'value'=> 'loanType0.loanTypeName',
             ],
            'Amount',
            'Interest',
            'Duration',
            'DateStart',
            //'DateEnd',
            // 'RecordBy',
            // 'RecordDate',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
    <?php Pjax::end() ?>
	</div>
	<div class="col-sm-2">
            <h4>Actions</h4>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['/switchboard/index'])  ?>">Main Switchboard</a>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['default/index'])  ?>">Finance Switchboard</a>

        </div>
</div>
