<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use \yii\helpers\ArrayHelper;
use common\models\Members;
use backend\modules\finance\models\Loantypes;
use dosamigos\datepicker\DatePicker;

/* @var $this yii\web\View */
/* @var $model backend\modules\finance\models\Loaninterest */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="loaninterest-form">

    <?php $form = ActiveForm::begin(); ?>
    <div class="col-sm-2">
        <?= $form->field($model, 'memberId')->dropDownList(ArrayHelper::map(Members::find()->all(),'id','people.FullName'),['prompt'=>'-Select a Member-']) ?>
    </div>
    
    <div class="col-sm-2">
        <?= $form->field($model, 'loanType')->dropDownList(ArrayHelper::map(Loantypes::find()->all(),'id','loanTypeName'),['prompt'=>'-Select Loan Type-']) ?>
    </div>
    
    <div class="col-sm-2">
        <?= $form->field($model, 'Amount')->textInput() ?>
    </div>
    
    <div class="col-sm-1">
        <?= $form->field($model, 'Interest')->textInput() ?>
    </div>
    
     <div class="col-sm-1">
        <?= $form->field($model, 'Duration')->textInput() ?>
    </div>
    <div class="col-sm-2">
        
        <?= $form->field($model, 'DateStart')->widget(
            DatePicker::className(), [
                // inline too, not bad
                 'inline' => FALSE, 
                 // modify template for custom rendering
                //'template' => '<div class="well well-sm" style="background-color: #fff; width:250px">{input}</div>',
                'clientOptions' => [
                    'autoclose' => true,
                    'format' => 'yyyy-mm-dd',
                    'showyear'=>true,
                ]
        ]);?>
    </div>
    <div class="col-sm-2">
        
        <?= $form->field($model, 'DateEnd')->widget(
            DatePicker::className(), [
                // inline too, not bad
                 'inline' => FALSE, 
                 // modify template for custom rendering
                //'template' => '<div class="well well-sm" style="background-color: #fff; width:250px">{input}</div>',
                'clientOptions' => [
                    'autoclose' => true,
                    'format' => 'yyyy-mm-dd',
                    'showyear'=>true,
                ]
        ]);?>
    </div>
   <div class="row">
    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? Yii::t('app', 'Create') : Yii::t('app', 'Update'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>
   </div>
    <?php ActiveForm::end(); ?>

</div>        