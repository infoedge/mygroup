<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\helpers\Url;

/* @var $this yii\web\View */
/* @var $model backend\modules\finance\models\Paymenttypes */

$this->title = Yii::t('app', 'Payment Types Entry');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Paymenttypes'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="paymenttypes-create">

    <h1><?= Html::encode($this->title) ?></h1>
    <hr>
    <div class="col-sm-10">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
    <hr>
    <h3>Listed Payment Types</h3>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            //'id',
            'PmtType',
            'PmtTypeSymbol',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
    </div>
    <div class="col-sm-2">
        <h4>Actions</h4>
			<a class="btn btn-success btn-block" href="<?= Url::toRoute(['default/index'])  ?>">Finance Switchboard</a>
			<a class="btn btn-success btn-block" href="<?= Url::toRoute(['/switchboard/index'])  ?>">Switchboard</a>
    </div>
</div>
