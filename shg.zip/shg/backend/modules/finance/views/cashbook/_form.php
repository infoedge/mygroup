<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;

use dosamigos\datepicker\DatePicker;
use backend\modules\finance\models\Accountnames;
use backend\modules\finance\models\Transactiontypes;
use backend\modules\finance\models\Paymenttypes;
/* @var $this yii\web\View */
/* @var $model common\models\Cashbook */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="cashbook-form">
	
    <?php $form = ActiveForm::begin(); ?>
	<div class="row">
		<div class="col-sm-2">
		<?= $form->field($model, 'TrDate')->widget(
				DatePicker::className(), [
					// inline too, not bad
					 'inline' => FALSE, 
					 // modify template for custom rendering
					//'template' => '<div class="well well-sm" style="background-color: #fff; width:250px">{input}</div>',
					'clientOptions' => [
						'autoclose' => true,
						'format' => 'yyyy-mm-dd',
						'showYear'=>true,
					],
				]); ?>
		</div>
		<div class="col-sm-2">
		<?= $form->field($model, 'Accountid')->dropDownList(ArrayHelper::map(Accountnames::find()->all(),'id','AcName'),['prompt'=>'--Select A/C --']) ?>
		</div>
		<div class="col-sm-2">
		<?= $form->field($model, 'RefAcctId')->dropDownList(ArrayHelper::map(Accountnames::find()->all(),'id','AcName'),['prompt'=>'--Select A/C --']) ?>
		</div>
		<div class="col-sm-2">
		<?= $form->field($model, 'RefTrId')->textInput() ?>
		</div>
		<div class="col-sm-4">
		<?= $form->field($model, 'Description')->textInput(['maxlength' => true]) ?>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-2">
		<?= $form->field($model, 'Trtype')->dropDownList(ArrayHelper::map(Transactiontypes::find()->all(),'id','TrtypeName'),['prompt'=>'--Choose Tr Type --'])?>
		</div>
		<div class="col-sm-2">
		<?= $form->field($model, 'PaymentTypeId')->dropDownList(ArrayHelper::map(Paymenttypes::find()->all(),'id','PmtType'),['prompt'=>'--Choose Payment Type --']) ?>
		</div>
		<div class="col-sm-2">
		<?= $form->field($model, 'Amount')->textInput() ?>
		</div>
    </div>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? Yii::t('app', 'Submit') : Yii::t('app', 'Update'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
