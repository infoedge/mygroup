<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\Url;


/* @var $this yii\web\View */
/* @var $model \common\models\Cashbook */
/* @var $form ActiveForm */
$this->title='Expenditure'
?>
<div class="cashbook-expenditure">
    <h1><?= Html::encode($this->title). " Entry" ?></h1>
    <div class="col-sm-10">
        
        <hr>
        <?php $form = ActiveForm::begin(); ?>



                <?= $this->render('_form2', [
                    'model' => $model,
                ]) ?>



        <?php ActiveForm::end(); ?>
    </div>
    <div class="col-sm-2">
        <h4>Actions</h4>
       <a class="btn btn-success btn-block" href="<?= Url::toRoute(['/switchboard/index'])  ?>">Main Switchboard</a>
       <a class="btn btn-success btn-block" href="<?= Url::toRoute(['default/index'])  ?>">Finance Switchboard</a>

    </div>
    
</div><!-- cashbook-expenditure -->
<?php
 $script = <<< JS
 $(function (){
         
    $('#addAccount').click( function(){
         $.get('index.php?r=finance/cashbook/create-account');
         alert('Clicked addAccount Button');
    });
 });
JS;
$this->registerJs($script);
?>