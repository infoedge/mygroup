<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;

use common\models\Accounttypes;

/* @var $this yii\web\View */
/* @var $model common\models\Accountnames */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="accountnames-form">

    <?php $form = ActiveForm::begin(); ?>
   
    <?= $form->field($model, 'AcType')->dropDownList(ArrayHelper::map(Accounttypes::find()->all(),'id','actypename'),['prompt'=>'--Select Account Type--','disabled'=>Yii::$app->session['expenditure']?'disabled':false]) ?>

    <?= $form->field($model, 'AcName')->textInput(['maxlength' => true]) ?>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? Yii::t('app', 'Create') : Yii::t('app', 'Update'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
