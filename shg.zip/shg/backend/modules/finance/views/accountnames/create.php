<?php

use yii\helpers\Html;
use yii\helpers\Url;
use yii\grid\GridView;


/* @var $this yii\web\View */
/* @var $model common\models\Accountnames */

$this->title = Yii::t('app', 'Create Account Names');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Accountnames'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="accountnames-create">
    <div class="col-sm-10">
    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
    </hr>
    <h3>Listed Account Names </h3>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            //'id',
            'acType.actypename',
            'AcName',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
    </div>
    <div class="col-sm-2">
        <h4>Actions</h4>
      <a class="btn btn-success btn-block" href="<?= Url::toRoute(['default/index'])  ?>">Finance Switchboard</a>
    </div>
</div>
