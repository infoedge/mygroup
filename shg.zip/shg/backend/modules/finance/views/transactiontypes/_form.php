<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model backend\modules\finance\models\Transactiontypes */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="transactiontypes-form">

    <?php $form = ActiveForm::begin(); ?>
    <div class="row">
        <div class="col-sm-3">
        <?= $form->field($model, 'TrtypeName')->textInput(['maxlength' => true]) ?>
        </div>
        <div class="col-sm-3">
        <?= $form->field($model, 'TrTypeSymbol')->textInput(['maxlength' => true]) ?>
        </div>
    </div>
    <div class="row">
        <div class="form-group">
            <?= Html::submitButton($model->isNewRecord ? Yii::t('app', 'Create') : Yii::t('app', 'Update'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
        </div>
    </div>
    <?php ActiveForm::end(); ?>

</div>
