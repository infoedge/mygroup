<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\helpers\Url;


/* @var $this yii\web\View */
/* @var $model backend\modules\finance\models\Transactiontypes */

$this->title = Yii::t('app', 'Create Transaction Types');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Transactiontypes'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="transactiontypes-create">

    <h1><?= Html::encode($this->title) ?></h1>
    <div class="col-sm-10">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
    <hr>
    <h2>Listed Transaction Types</h2>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            //'id',
            'TrtypeName',
            'TrTypeSymbol',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
    </div>
    <div class="col-sm-2">
        <h4>Actions</h4>
			<a class="btn btn-success btn-block" href="<?= Url::toRoute(['default/index'])  ?>">Finance Switchboard</a>
			<a class="btn btn-success btn-block" href="<?= Url::toRoute(['/switchboard/index'])  ?>">Switchboard</a>
    </div>
</div>
