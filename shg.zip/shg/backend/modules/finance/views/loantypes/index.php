<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\helpers\Url;
use yii\bootstrap\Modal;

/* @var $this yii\web\View */
/* @var $searchModel backend\modules\finance\models\LoantypesSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'Loan Types');
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="loantypes-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php Modal::begin([
            'header'=>'<h4>Name Loan Types</h4>',
            'id' => 'modal',
            'size' => 'modal-lg',
            ]);
         echo "<div id='modalcontent'></div>";
         Modal::end();?>
    <hr>
    <div class="row">
        <div class="col-sm-10">
            <p>
                <?= Html::button(Yii::t('app', 'Add Loan Types'), ['value'=>Url::to('index.php?r=finance/loantypes/create'),'id'=>'crateloantypebtn','class' => 'btn btn-success']) ?>
            </p>

            <?= GridView::widget([
                'dataProvider' => $dataProvider,
                'filterModel' => $searchModel,
                'columns' => [
                    ['class' => 'yii\grid\SerialColumn'],

                    //'id',
                    'loanTypeName',
                    //'RecordDate',
                    //'RecordBy',

                    ['class' => 'yii\grid\ActionColumn'],
                ],
            ]); ?>
        </div>
        <div class="col-sm-2">
            <h4>Actions</h4>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['/switchboard/index'])  ?>">Main Switchboard</a>
            <a class="btn btn-success btn-block" href="<?= Url::toRoute(['default/index'])  ?>">Finance Switchboard</a>

        </div>
    </div>
    
</div>
<?php 
$script= <<< JS
    $(function(){
        $('#crateloantypebtn').click(function(){
            var myurl= $(this).attr('value')
           // alert("How are you "+myurl);
            $('#modal').modal('show')
                    .find('#modalcontent')
                    .load(myurl);
        });
    });
JS;
$this->registerJs($script);
?>
