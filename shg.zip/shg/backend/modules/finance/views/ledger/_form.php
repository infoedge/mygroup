<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model common\models\Ledger */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="ledger-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'TrDate')->textInput() ?>

    <?= $form->field($model, 'AccountId')->textInput() ?>

    <?= $form->field($model, 'RefAcId')->textInput() ?>

    <?= $form->field($model, 'RefTrId')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'Description')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'TrType')->textInput() ?>

    <?= $form->field($model, 'Amount')->textInput() ?>

    <?= $form->field($model, 'RecordDate')->textInput() ?>

    <?= $form->field($model, 'RecordBy')->textInput() ?>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? Yii::t('app', 'Create') : Yii::t('app', 'Update'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
