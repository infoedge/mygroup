<?php
/* @var $this yii\web\View */
use yii\helpers\Url;
use yii\helpers\Html;

$this->title = 'Error';
?>
<h1><?= Html::encode($this->title) ?></h1>
<div class="col-sm-10">
<p style="text-align: center">
<h2>Sorry! Your login credentials do not allow you to view <?= $page ?> </h2>
</p>
</div>
<div class="col-sm-2">
        <h4>Actions</h4>
      <a class="btn btn-success btn-block" href="<?= Url::toRoute([$backlink])  ?>">Switchboard</a>
    
</div>