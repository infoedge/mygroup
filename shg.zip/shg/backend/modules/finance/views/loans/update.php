<?php

use yii\helpers\Html;
use yii\helpers\Url;

/* @var $this yii\web\View */
/* @var $model backend\modules\finance\models\Loans */

$this->title = Yii::t('app', 'Update Loan Details', [
    'modelClass' => 'Loans',
])/* . ' ' . $model->id*/;
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Loans'), 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->id, 'url' => ['view', 'id' => $model->id]];
$this->params['breadcrumbs'][] = Yii::t('app', 'Update');
?>
<div class="loans-update">
    <div class="col-sm-9">
    <h1><?= Html::encode($this->title) ?></h1>
    <!--<?= $this->context->getViewPath() ?>-->
    <?= $this->render('_form', [
        'model' => $model,
        'loanchange' => false,//cant change the loan type
    ]) ?>
    </div>
    <div class="col-sm-3">
    <h4>Actions</h4>
        <a class="btn btn-success btn-block" href="<?= Url::toRoute(['/switchboard/index'])  ?>">Main Switchboard</a>
        <a class="btn btn-success btn-block" href="<?= Url::toRoute(['default/index'])  ?>">Finance Switchboard</a>

    </div>
</div>
