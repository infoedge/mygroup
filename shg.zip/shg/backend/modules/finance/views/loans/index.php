<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\helpers\Url;

/* @var $this yii\web\View */
/* @var $searchModel backend\modules\finance\models\LoansSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'Loans');
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="loans-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>
    <div class="col-sm-10">
    <p>
        <?= Html::a(Yii::t('app', 'Create Loans'), ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            //['class' => 'yii\grid\SerialColumn'],

            //'id',
            [
                'attribute' => 'loanType',
                'value'=>'loanType0.loanTypeName',
                ],
            'Amount',
            'Duration',
            'interest',
            'DateStart',
            'DateEnd',
            // 'RecordDate',
            // 'RecordBy',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
    </div>
    <div class="col-sm-2">
        <h4>Actions</h4>
        <a class="btn btn-success btn-block" href="<?= Url::toRoute(['/switchboard/index'])  ?>">Main Switchboard</a>
      <a class="btn btn-success btn-block" href="<?= Url::toRoute(['default/index'])  ?>">Finance Switchboard</a>
    
    </div>
</div>
