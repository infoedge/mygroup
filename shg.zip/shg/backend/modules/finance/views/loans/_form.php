<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use dosamigos\datepicker\DatePicker;

use backend\modules\finance\models\Loantypes;

/* @var $this yii\web\View */
/* @var $model backend\modules\finance\models\Loans */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="loans-form">

    <?php $form = ActiveForm::begin(); ?>
    <div class="row">
        <div class="col-sm-3">
            </br>
    <?= $form->field($model, 'loanType')->dropDownList(ArrayHelper::map(Loantypes::find()->all(),'id','loanTypeName'),['disabled'=>($loanchange?false:'disabled')]) ?>
        </div>
        <div class="col-sm-2">
    <?= $form->field($model, 'Amount')->textInput() ?>
        </div>
        <div class="col-sm-1">
    <?= $form->field($model, 'Duration')->textInput() ?>
        </div>
        <div class="col-sm-1">
    <?= $form->field($model, 'interest')->textInput() ?>
        </div>
        <div class="col-sm-2">
            </br>
    <?= $form->field($model, 'DateStart')->widget(
            DatePicker::className(), [
                // inline too, not bad
                 'inline' => FALSE, 
                 // modify template for custom rendering
                //'template' => '<div class="well well-sm" style="background-color: #fff; width:250px">{input}</div>',
                'clientOptions' => [
                    'autoclose' => true,
                    'format' => 'yyyy-mm-dd',
                    'showYear'=>true,
                ],
            ]); ?>
    
        </div>
        <div class="col-sm-2">
            </br>
    <?= $form->field($model, 'DateEnd')->widget(
            DatePicker::className(), [
                // inline too, not bad
                 'inline' => FALSE, 
                 // modify template for custom rendering
                //'template' => '<div class="well well-sm" style="background-color: #fff; width:250px">{input}</div>',
                'clientOptions' => [
                    'autoclose' => true,
                    'format' => 'yyyy-mm-dd',
                    'showYear'=>true,
                ],
            ]); ?>
        </div>
    </div><!-- row -->
    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? Yii::t('app', 'Create') : Yii::t('app', 'Update'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
