<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model backend\modules\finance\models\Loanrepaymentrecord */

$this->title = Yii::t('app', 'Loan Repayment Record');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Loanrepaymentrecords'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="loanrepaymentrecord-create">

    <h1><?= Html::encode($this->title). ' for '. $memberName.' paid on '.$atDate ?></h1>
    <!--<h2> <?php foreach($models as $model){echo 'MemberId : '.$model['MemberId'].'; Loan Type: '.$model['LoanType'].'<br>';} ?> </h2>-->
    
    <?= $this->render('_form', [
        'models' => $models,
        'atDate' => $atDate,
        //'mymemberid' => $mymemberid,
    ]) ?>

</div>
