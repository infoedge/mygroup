<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use \yii\helpers\ArrayHelper;
use \backend\modules\Finance\models\Loantypes;
use common\models\Members;

/* @var $this yii\web\View */
/* @var $model backend\modules\finance\models\Loanrepaymentrecord */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="loanrepaymentrecord-form">

    <?php $form = ActiveForm::begin(); ?>
    <div class="row">
        <div class="col-sm-3">
            <h3>Loan Type</h3>
        </div>
        <div class="col-sm-3">
            <h3>Principal (KShs)</h3>
        </div>
        <div class="col-sm-3">
            <h3>Interest (KShs)</h3>
        </div>
        <div class="col-sm-3">
            
        </div>
    </div>
    <?php    foreach ($models as $i=>$model){ ?>
    <div class="row">
    <!--    <div class="col-sm-3">
    <?= $form->field($model,  'MemberId')->dropDownList(ArrayHelper::map(Members::find()->all(),'id','PersonsName')) ?>
   
        </div>-->
        <div class="col-sm-3">
    <?= $form->field($model,  'LoanType')->dropDownList(ArrayHelper::map(Loantypes::find()->all(),'id','loanTypeName'),['disabled'=>'disabled'])->label(false) ?>
        </div>
        <div class="col-sm-3">
    <?= $form->field($model,  'Principal')->textInput()->label(false) ?>
        </div>
        <div class="col-sm-3">
    <?= $form->field($model,  'Interest')->textInput()->label(false) ?>
        </div>
        <div class="col-sm-3">
    <?= $form->field($model,  'PayDate')->hiddenInput()->label(false) ?>

    <!--<?= $form->field($model,  'RecordBy')->textInput() ?>

    <?= $form->field($model,  'RecordDate')->textInput() ?>-->
        </div>
    </div>
    <?php }?>
    <div class="form-group">
        <?= Html::submitButton( 'Save', ['class' => 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
