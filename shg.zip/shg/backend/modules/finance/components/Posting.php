<?php
namespace backend\modules\finance\components;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Posting
 *
 * @author apache
 */
use Yii;
use \yii\base\Component;
use common\models\Members;
use \backend\modules\finance\models\Accountnames;
use common\models\Cashbook;
use common\models\Ledger;
use common\models\Actomember;
//use \backend\modules\finance\models\Loanstaken;
use \backend\modules\finance\models\Paymenttypes;
use yii\db\Exception;
use \backend\modules\finance\models\Transactiontypes;

//use common\models\

class Posting extends Component {
    public $membername;
    public $AcName;
    public $AcNo;
    public $Actype;
    
    /*
     * returns balance B/F at a certain date 'atDate'
     */
    public function getMemberName($memberId) {
        $myMember=Members::findOne($memberId);
        $this->membername=  $myMember->getPersonsName();
        return $this->membername;
    }
    public function getBroughtForward($memberId,$atDate,$acTypeName,$AcPartName,$loanTypeName,$acNameOptn=1){
        //get loanTypes
        
        $this->AcNo=  $this->createAccountName($loanTypeName.' '.$AcPartName,$acTypeName,$memberId,$acNameOptn );
        //echo 'AcNo: '.$this->AcNo.'; AcPartName: '.$loanTypeName.' '.$AcPartName.'; AcTypeName: '.$acTypeName.'; MemberId: '.$memberId.'<br>';
        $retval=0;
        //search loan entries from ledger for member before 'atDate' and get o/s amount
        if($this->AcNo){// Account No is Found
            $retval=$this->getLedgerBalance($this->AcNo,$atDate);
            if(empty($retval))
            {
                $retval=0;
            }
        }else{
            $this->createAccount($this->AcName, $acTypeName);
            $retval=0;
        }
        //Return o/s amount
       // echo "Posting-getBroughtForward: ".$retval." ; memberId: ".$memberId." ; At Date: ".$atDate." ; acTypeName : ".$acTypeName." ; AcPartName: ".$AcPartName."<br>";
            return $retval;
    }
    /**
     * Returns AcctNo if acName Exists in AcNames Table
     * Else Returns 0
     * @param type $AcName
     * @param type $AcTypeName
     * @return type
     */
    
    public function confirmAcctNo($AcName,$AcTypeName){
        $retval=0;
        $model=  Accountnames::find()->where(['AcName'=>$AcName,'AcType'=>$this->getAcTypeNo($AcTypeName)])->one();
        if(!$model== Null){
            $retval=$model->id;
        }
        //echo "Confirm A/C no: ".$retval." ; ".$AcName."<br>";
        return $retval;
    }
    
    public function confirmPaymentTypeNo($payenttype){
         $retval=0;
        $model= Paymenttypes::find()->where(['PmtType'=>$payenttype])->one();
        if(!$model== Null){
            $retval=$model->id;
        }
        //echo "Confirm A/C no: ".$retval." ; ".$AcName."<br>";
        return $retval;
    }
    /**
     * 
     * @param string $AcPartName
     * @param string $AcTypeName {Asset, Liability, Capital,Revenue,Expenditure}
     * @param int $memberId
     * @param int $option
     * @return int
     */
    public function getAccountNo($AcPartName,$AcTypeName/*Asset, Liability, Capital,Revenue,Expenditure*/,$memberId,$option=1){
        $retval=0;
        $acname = $this->setAccountName($AcPartName, $AcTypeName, $memberId,$option);
        $retval=$this->getAcctNo($acname, $AcTypeName);
        return $retval;
    }
     /*
    * Returns AcctNo in AcNames Table
    * If AcNames doesnt exist it is created
    */
    public function getAcctNo($AcName,$acTypeName){
        $retval=0;
        $model=  Accountnames::findOne(['AcName'=>$AcName]);
        if($model!==Null){
            $retval=$model->id;
        }else{//create the account
            $retval=$this->createAccount($AcName,$acTypeName);
        }
        return $retval;
    }
    
    /**
     * Inserts Acct Name into AcNames Table
     * @param string $AcName
     * @param string $AcTypeName
     * @return int
     */ 
    public function createAccount($AcName,$AcTypeName){
        $connection = Yii::$app->db;
        $transaction=$connection->beginTransaction();
        try{
        /*$model=new Accountnames();
        $model->AcName=trim($AcName);
        $model->AcType=$this->getAcTypeNo(trim($AcTypeName));
        $model->save();*/
            
        $row= $connection->createCommand()
                ->insert('accountnames',[
                    'AcType'=>$this->getAcTypeNo($AcTypeName),
                    'AcName'=>$AcName,
                ])
                ->execute();
        $transaction->commit();
        $this->AcNo=$connection->getLastInsertID();
        //echo "Account Created: ",$this->AcNo;
        }
        catch(Exception $ex){
            echo "Unable to save: ".$ex->getMessage();
        }
        return $this->AcNo;
    }
    /*
     * Returns account No if a/c does not exist creates it in account Names table
     */
    public function createAccountName($AcPartName,$AcTypeName/*Asset, Liability, Capital,Revenue,Expenditure*/,$memberId,$option=1){
        $acname=$this->setAccountName($AcPartName,$AcTypeName/*Asset, Liability, Capital,Revenue,Expenditure*/,$memberId,$option);
        $this->AcName=$acname;
        $this->AcNo=$this->confirmAcctNo($acname,$AcTypeName);
        if(($this->AcNo==0 )|| (!($this->AcNo)) ||(empty($this->AcNo))||($this->AcNo==null)){
            $this->AcNo = $this->createAccount($acname,$AcTypeName);
            if($this->AcNo){
            $this->relateAccountToMember($this->AcNo,$memberId);
            }
        }
        //echo "Create a/c Name: ".$acname." ; AcPartName : ".$AcPartName." ; AcTypeName: ".  $AcTypeName." ; ".$memberId."<br>";
        return $this->AcNo;
   }
   
   /**
    * Creates and returns an account name
    * @param string $AcPartName
    * @param string $AcTypeName
    * @param int $memberId
    * @param int $option
    * @return string
    */
   public function setAccountName($AcPartName,$AcTypeName/*Asset, Liability, Capital,Revenue,Expenditure*/,$memberId,$option=1){
       $acname="";
       switch ($option){
            case 2://Recievables
                $acname=  ucfirst(strtolower(trim($AcPartName))).' - '.$this->getMemberName($memberId).' A/C';
                break;
            default:
                $acname=  $this->getMemberName($memberId).' - '.ucfirst(strtolower(trim($AcPartName))).' A/C';       
        }
        return $acname;
   }
   
   /*
    * Saves the relation between member and Account
    */
   private function relateAccountToMember($AccountId,$MemberId) {
       $model=new Actomember();
       $model->AcNameId=$AccountId;
       $model->MemberId=$MemberId;
       $model->save();
       //echo "a/c ID: ".$AccountId." Relates to Member ID: ".$MemberId."<br>";
   }
    /**
     
         * Returns the A/CTypeNo Given the AcTypeName
         * Else returns 0
         */
        public function getAcTypeNo($AcTypeName){
           
            $mysql= (new \yii\db\Query());
            $result = $mysql->select('id')
                    ->from('accounttypes')
                    ->where('actypename=:AcTypeName',[':AcTypeName'=>$AcTypeName])
                    ->scalar();
            //echo $AcTypeName.' Account Type ID: '.$result.'<br>';
            return $result;
        }
        
        public function getAcTypeNoFromNo($AcNo){
           
            $mysql= (new \yii\db\Query());
            $result = $mysql->select('AcType')
                    ->from('accountnames')
                    ->where('id=:AcNo',[':AcNo'=>$AcNo])
                    ->scalar();
            //echo $AcTypeName.' Account Type ID: '.$result.'<br>';
            return $result;
        }
        /**
         * 
         * @param double $amount
         * @param int $acTypeNo
         * @return double
         */
        public function getLedgerBalWrtUs( $amount, $acTypeNo){
            switch ($acTypeNo){
                case 2://liability    
                case 3://capital
                //case 5:// expenditure
                    $retval = -1*$amount;
                    
                    break;
                default:
                    $retval= $amount;
            }
            //echo "getLedgerBalWrtUs:- acTypeNo: ".$acTypeNo."; Returned Value; ".$retval."</br>";
            return $retval;
        }

        /**
         * 
         * @param int $AcNo
         * @param string $TrDate
         * @return double balance  trial balance for a particular a/c
         */
        public function getLedgerBalance($AcNo,$TrDate){
            $data=(new \yii\db\Query());
            $debitBalance=$data
                    ->Select('SUM(Amount)')
                    ->From('ledger')
                    ->Where('AccountId=:refac AND TrDate< :trdate AND TrType= :trtype',array(
                            ':refac'=>$AcNo,
                            ':trdate'=>$TrDate,
                            ':trtype'=>1,
                            ))
                    ->scalar();
            if(!$debitBalance){
                $debitBalance=0;
            }
            $creditBalance=$data
                    ->Select('sum(Amount)')
                    ->From('ledger')
                    ->Where('(AccountId=:refac) AND (TrDate< :trdate) AND (TrType= :trtype)',array(
                            ':refac'=>$AcNo,
                            ':trdate'=>$TrDate,
                            ':trtype'=>2,
                            ))
                    ->scalar();
            if(!$creditBalance){
                $creditBalance=0;
            }
            //echo "Ledger Balance: ".$debitBalance-$creditBalance." ; a/c No: ".$AcNo." ; Tr Date: ".$TrDate."<br>";
            return $debitBalance-$creditBalance;
        }
        public function postToCash($AcId,$RefId,$TrDate/*'format: yyyy-mm-dd'*/,$amount,$trType/* c/f TrTypes */,$TrMode/* Cash, Cheque, Card, Mpesa */,$TrDescription){
            $flashmsg = Yii::$app->session;
            $datacon= \yii::$app->db;
            $query=(new \yii\db\Query());
            //$id=$datacon->getLastInsertId();
            $datenow=date('Y-m-d h:i:s');
            //$retval=0;
            try{
                $theTransaction=$query->select('*')->from('cashbook')->where(['TrDate'=>$TrDate,'Accountid'=>$AcId,'RefAcctId'=>$RefId,'Trtype'=>$trType])->one();
                if($theTransaction) {//update
                    //need to negate previous entry and put a comment why it is changing;
                    $datacon->createCommand()->update('cashbook',['Amount'=>$amount,'Description'=>$TrDescription,'PaymentTypeId'=>$TrMode,'RecordDate'=>$datenow,'RecordBy'=>\Yii::$app->user->id],['TrDate'=>$TrDate,'Accountid'=>$AcId,'RefAcctId'=>$RefId,'Trtype'=>$trType])->execute();
                    $transactionId=$theTransaction['id'];
                } else{//insert
                    $datacon->createCommand()->insert('cashbook',['Amount'=>$amount,'TrDate'=>$TrDate,'Accountid'=>$AcId,'RefAcctId'=>$RefId,'Trtype'=>$trType,'Description'=>$TrDescription,'PaymentTypeId'=>$TrMode,'RecordDate'=>$datenow,'RecordBy'=>\Yii::$app->user->id])->execute();
                    $transactionId=$datacon->getLastInsertId();
                }      
               //echo "Posted to Cash Transaction Id: ".$transactionId."; Tr Date: ".$TrDate. " ; a/c ID: ".$AcId." ; Amount: ".$amount." ; Tr Type: ".$trType."<br>";
                return $transactionId;
            }   
            catch (Exception $e){
                $flashmsg->setFlash('error','unable to Update cashbook: '.$e->getMessage());
                return 0;
            }
            
        }
        /**/
        public function getCashbookModel($AcId,$RefId,$TrDate,$trType){
            $cashbookModel =  Cashbook::findOne(['TrDate'=>$TrDate,'Accountid'=>$AcId,'TrType'=>$trType,'RefAcctId'=>$RefId,]);
                if($cashbookModel==null){//record not found
                    $cashbookModel=new Cashbook();
                    $cashbookModel->Accountid=$AcId;
                    $cashbookModel->RefAcctId=$RefId;
                    $cashbookModel->TrDate=$TrDate;
                    $cashbookModel->Trtype=$trType;
                    $cashbookModel->Amount=0;
                    //$cashbookModel->save();
                }
              return $cashbookModel;
        }
        public function getCashbookValue($AcId,$RefId,$TrDate,$trType,$value){
            //$retval;
            $model=$this->getCashbookModel($AcId,$RefId,$TrDate,$trType);
            return $model->$value;
            
        }
        /**/
        public function postToLedger($AcId,$RefId,$TrDate/*'format: yyyy-mm-dd'*/,$amount,$trType/* c/f TrTypes */,$TrMode/* Cash, Cheque, Card, Mpesa */,$TrDescription){
            $flashmsg = Yii::$app->session;
            $datacon= \yii::$app->db;
            $query=(new \yii\db\Query());
            //$id=$datacon->getLastInsertId();
            $datenow=date('Y-m-d h:i:s');
            //$retval=0;
            try{
                $theTransaction=$query->select('*')->from('ledger')->where(['TrDate'=>$TrDate,'Accountid'=>$AcId,'RefAcId'=>$RefId,'Trtype'=>$trType])->one();
                if($theTransaction) {//update
                    //need to negate previous entry and put a comment why it is changing;
                    $datacon->createCommand()->update('ledger',['Amount'=>$amount,'Description'=>$TrDescription,/*'PaymentTypeId'=>$TrMode,*/'RecordDate'=>$datenow,'RecordBy'=>\Yii::$app->user->id],['TrDate'=>$TrDate,'Accountid'=>$AcId,'RefAcId'=>$RefId,'Trtype'=>$trType])->execute();
                    $transactionId=$theTransaction['id'];
                } else{//insert
                    $datacon->createCommand()->insert('ledger',['Amount'=>$amount,'TrDate'=>$TrDate,'Accountid'=>$AcId,'RefAcId'=>$RefId,'Trtype'=>$trType,'Description'=>$TrDescription,/*'PaymentTypeId'=>$TrMode,*/'RecordDate'=>$datenow,'RecordBy'=>\Yii::$app->user->id])->execute();
                    $transactionId=$datacon->getLastInsertId();
                }      
               //echo "Posted to Ledger Transaction Id: ".$transactionId."; Tr Date: ".$TrDate. " ; a/c ID: ".$AcId." ; Amount: ".$amount." ; Tr Type: ".$trType."<br>";
                return $transactionId;
            }   
            catch (Exception $e){
                $flashmsg->setFlash('error','unable to Update Ledger: '.$e->getMessage().'; LineNo: '.$e->getLine());
                return 0;
            }
           
        }
        /*
         * 
         */
        public function getLedgerModel($AcId,$RefId,$TrDate,$trType){
            $ledgerModel=  Ledger::findOne(['TrDate'=>$TrDate,'AccountId'=>$AcId,'TrType'=>$trType,'RefAcId'=>$RefId]);
                if($ledgerModel==null){//record not found
                    $ledgerModel=new Ledger();
                    $ledgerModel->AccountId=$AcId;
                    $ledgerModel->RefAcId=$RefId;
                    $ledgerModel->TrDate=$TrDate;
                    $ledgerModel->TrType=$trType;
                    //$ledgerModel->Amount=0;
                    //$ledgerModel->save();
                }
              return $ledgerModel;
        }
        /*
         * updates refTrId in Ledger
         */
        public function updateLedgerRef($TrId,$RefTrId){
            $flashmsg = Yii::$app->session;
            
            try{
                $data=  Ledger::findOne($RefTrId );
                if(!$data==null){
                    $data->RefTrId=$TrId;
                    $data->save();
                }
                      
            } catch (Exception $ex) {
                $flashmsg->setFlash('error','Update of ReferenceID '.$RefTrId.' NoT successful!: '.$ex->getMessage());
            }
        }
        /*
         * updates refTrId in Cashbook
         */
        public function updateCashbookRef($TrId,$RefTrId){
            $flashmsg = Yii::$app->session;
            try{
                $data=  Cashbook::findOne($TrId);
                if(!$data==null){
                    $data->RefTrId=$RefTrId;
                    $data->save();
                }
            /*$data=(new \yii\db\Query());
            
                $data->update('cashbook',array(
                                    'RefTrId'=>$RefTrId,
                                ),
                              'id=:id',array(
                                  ':id'=>$TrId,
                              ));*/
                      
            } catch (Exception $ex) {
                $flashmsg->setFlash('error','Update of ReferenceID '.$RefTrId.' NoT successful!: '.$ex->getMessage());
            }
        }
        public function doubleEntry($cashAcId/*int*/,$acctPartName/*String*/,$acctType/*string*/,$memberName/*int*/,$transactionDate/*String format yyyy-mm-dd*/,$amount,$payin/*1 or 2*/,$description){
            $myLedgerId=$this->createAccountName($acctPartName,$acctType,$memberName);
                        //echo "MyLedgerId: ".$myLedgerId.'<br>';
                        $cashTrId=$this->postToCash($cashAcId,$myLedgerId,$transactionDate,$amount,$payin/*DR or CR*/,1/*Cash*/,$description);
                        $ledgerTrId = $this->postToLedger($myLedgerId,$cashAcId,$transactionDate,$amount,$this->toggle($payin)/*CR or DR*/,1/*Cash*/,$description);
                        $this->updateCashbookRef($cashTrId,$ledgerTrId);
                        $this->updateLedgerRef($ledgerTrId,$cashTrId);
        }
    public function toggle($valuein){
        return $valuein==1?2:1;
    }
    public function postTransaction($myCashId,$myLedgerId,$transactionDate,$postAmount,$payin,$description,$pmtType=1 /*1=Cash*/){
        $cashTrId=$this->postToCash($myCashId,$myLedgerId,$transactionDate,$postAmount,$payin/*DR or CR*/,$pmtType,$description);
        $ledgerTrId = $this->postToLedger($myLedgerId,$myCashId,$transactionDate,$postAmount,$this->toggle($payin)/*CR or DR*/,$pmtType/*Cash*/,$description);
        $this->updateCashbookRef($cashTrId,$ledgerTrId);
        $this->updateLedgerRef($ledgerTrId,$cashTrId);
    }
    public function getTranactionType($TrTypeName){
        return Transactiontypes::find()->where(['TrtypeName'=>$TrTypeName])->scalar();
    }
}
