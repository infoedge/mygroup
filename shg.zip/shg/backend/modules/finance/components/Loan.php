<?php

namespace backend\modules\finance\components;

use Yii;
use yii\base\Component;
use \backend\modules\finance\models\Loanstaken;
use \backend\modules\finance\models\Loaninterest;
use \backend\modules\finance\models\Loans;
use backend\modules\finance\models\Loanrepaymentrecord;


class Loan extends Component{
    public function getLoanModels($myloantypes,$memberId,$atDate){
        $models= Loanstaken::find()->where(['MemberId'=>$memberId,'LoanedDate'=>$atDate])->all();
        //$stmt="SELECT * FROM `loantypes` `lt` LEFT JOIN `loans` `lo` on `lt`.`id`= `lo`.`loanType` WHERE `lo`.`DateStart` <= '2013-10-10' AND ((`lo`.`DateEnd` IS NULL) OR (`lo`.`DateEnd` > '2013-10-10' ))";
        if($models==null){
            $loantypecnt = count($myloantypes);
            if($loantypecnt==0){
                $models[]= (new Loanstaken());
                 $models[0]->MemberId=$memberId;
                    //$models[0]->loanType = $myloantypes[$i]["lid"];
                    $models[0]->LoanedDate=$atDate;
                    $models[0]->Amount=0;
                    $models[0]->interest=0;
                    $models[0]->Duration=0;
                    
            }else{
                for($i=0;$i< $loantypecnt; $i++){
                    //if($myloantype->StartDate <= $atDate AND (($myloantype->EndDate > $atDate) OR (empty($myloantype->EndDate))) ){

                    $models[]= (new Loanstaken());
                    $models[$i]->MemberId=$memberId;
                    $models[$i]->loanType = $myloantypes[$i]["lid"];
                    $models[$i]->LoanedDate=$atDate;
                    $models[$i]->Amount=0;
                    $models[$i]->interest=$this->getIndividualInterest($memberId,$myloantypes[$i]["lid"],1,$atDate);
                    $models[$i]->Duration = $this->getIndividualInterest($memberId,$myloantypes[$i]["lid"],2,$atDate);
                    $date=new DateTime($models[$i]->LoanedDate);
                    $date->add(new DateInterval('P'.(string)($models[$i]->Duration).'M') );
                    $models[$i]->dueDate = $date->format('M, Y');
                    //$models[$i]->RecordDate = date('Y-m-d');
                    //$models[$i]->RecordBy = Yii::$app->user->id;
                }
            }
        }
        return $models;
    }
    protected function getIndividualInterest($memberId,$loantype,$interestOrDuration/*interest= 1; Duration =2*/,$atDate){
        $con= Yii::$app->db;
        $mysql = 'select * from loaninterest where(loanType = :loanType And memberId = :memberId And DateStart <= :atDate And ((DateEnd > :atDate) OR (DateEnd IS NULL)))';
        $myrec =$con->createCommand($mysql)
                ->bindParam(':loanType',$loantype)
                ->bindParam(':memberId',$memberId)
                ->bindParam(':atDate',$atDate)
                ->queryOne();
        $myloan= $this->getLoanParameters($loantype,$atDate);
        if($myrec){
            //return the values
            switch($interestOrDuration){
                case 1://interest
                    return empty($myrec['Interest'])?(!empty($myloan['interest'])?$myloan['interest']:0):$myrec['Interest'];
                    
                case 2://Duration
                    return empty($myrec['Duration'])?(!empty($myloan['Duration'])?$myloan['Duration']:0):$myrec['Duration'];
                default:
                    return 0;
            }
        }else{//no value in interestrates table
            //check in loans table
            
            if($myloan!==Null){
                //update loansinterest table
                $mymodel= new Loaninterest();
                $mymodel->memberId=$memberId;
                $mymodel->loanType=$loantype;
                $mymodel->Amount = $myloan['Amount'];
                $mymodel->Duration = $myloan['Duration'];
                $mymodel->Interest = $myloan['interest'];
                $mymodel->DateStart=$myloan['DateStart'];
                $mymodel->DateEnd=$myloan['DateEnd'];
                $mymodel->RecordBy = Yii::$app->user->id;
                $mymodel->RecordDate = date('Y-m-d h:i:s');
                $mymodel->save(); 
                switch($interestOrDuration){
                case 1://interest
                    return !empty($myloan->interest)?$myloan->interest:0;
                    
                case 2://Duration
                    return !empty($myloan->Duration)?$myloan->Duration:0;
                default:
                    return 0;
                }//end switch
            }else{
                Yii::$app->session->setFlash('error','No loan Parameters found. Please set default parameters!');
            }
        }
    }
    /*
     * Returns an array with the loantypes model in Desc Order
     */
    public function getLoanTypes($atDate,$order=1){
        $query= (new \yii\db\Query());
        $myloantypes= $query->select('*')
                ->from('loans ln')
                ->leftJoin('loantypes lo','ln.loanType=lo.id')
                ->Where(['<=','DateStart',$atDate])
                ->andWhere(['or','DateEnd IS NULL','DateEnd > :atDate']);
                
        $myloantypes->addParams([':atDate'=>$atDate]);
        return $myloantypes->all();
    }
    /*
     * checks loaninterest table for loan interest applicable for a particular member
     * if it doesnt exist creates it for a particular member
     */
    public function getApplicableInterest($memberid,$loantype,$atDate){
        $query= (new \yii\db\Query());
        $myloaninterest= $query->select('*')
                ->from('loaninterest')
                ->where(['memberId'=>$memberid,'loantype'=>$loantype])
                ->andWhere('DateStart <:atDate',[':atDate'=>$atDate])
                ->andWhere('(DateEnd > :dateEnd) or (DateEnd is null)',[':dateEnd' => $atDate]);
                //->asArray();
                //->one();
        //$myloaninterest->addParams([':atDate'=>$atDate]);
        //$myquery=$myloaninterest->all();
        if(($myloaninterest->count())>0){
            $myobj=$myloaninterest->one();
            $retLoanInterest= $myobj["Interest"];
        }else{
            $datacon= \yii::$app->db->createCommand();
            try{
                //Get default loan interest particulars from loans
                //$defaultLoanParticulars=$query->select('*')->from('loans')->where('loanType = :loanType',[':loanType'=>$loantype])->andWhere('DateStart < :dateStart',[':dateStart' => $atDate])->andWhere('((DateEnd > :dateEnd) OR (DateEnd IS Null))',[':dateEnd'=> $atDate])->one();
                $myLoansDefault= Loans::find()->where(['loanType'=>$loantype])->andWhere('DateStart < :dateStart',[':dateStart' => $atDate])->andWhere('((DateEnd > :dateEnd) OR (DateEnd IS Null))',[':dateEnd'=> $atDate])->one();
                //Update LoanInterest
                $datacon->insert('loaninterest',['memberId'=>$memberid,'loanType'=>$loantype,'Interest'=>$myLoansDefault->interest,'DateStart'=>$atDate,'RecordBy'=>Yii::$app->user->id,'RecordDate'=> date('Y-m-d')])->execute();
            }catch(Exception $ex){
                //echo "error @ line #: ".$ex->getLine();
                throw  $ex;
            }
            
            $retLoanInterest=$myLoansDefault->interest;
        }
        //echo "getApplicableInterest;  Applicable Interest: ".$retLoanInterest." ; memberid: ".$memberid." ; loantype: ".$loantype." ; at Date: ".$atDate." <br>";
        return $retLoanInterest;
    }
    /**
     * 
     * @param int $memberId
     * @param string $atDate
     * @return double
     */
    public function getTotalInterest($memberId,$atDate){
        //getTotalBroughtForward($myMemberIds[$i]["memId"],$DBMeetingDate)
        $book=Yii::$app->postings;
        //$loan = Yii::$app->loan;
        $myloantypes = $this->getLoanTypes($atDate);
        $retval=0;
        for($i=0;$i<count($myloantypes);$i++){
            $interest=$this->getInterestDue($memberId,$atDate,$myloantypes[$i]["loanType"],$myloantypes[$i]["loanTypeName"]);
            //echo "Function getTotalInterest; AmountPaid: ".$amountPaid."; Interest Rate applied: ".$interestRate."; Interest: ".$interest."; Loan Type: ".$myloantypes[$i]["loanType"]."</br>";
            //Save accrued Interest in Loan Repayment Record
            $this->setLoanRepaymentRecord($atDate, $memberId, $myloantypes[$i]["loanType"], $interest);
            $retval+=$interest;
        }
        //echo "Total B/F : ".$totalBF." ; memberId: ".$memberId." ; at Date: ".$atDate."<br>";
        return $retval;
    }
    
    /**
     * @abstract saves accrued interest amount in Loanrepaymentrecord
     * @param int $atdate
     * @param int $memberId
     * @param int $loanType
     * @param double $amount
     */
    public function setLoanRepaymentRecord($atdate,$memberId,$loanType, $amount){
        $myrec=  Loanrepaymentrecord::find()
                ->where(['PayDate'=>$atdate,'MemberId'=>$memberId,'LoanType'=>$loanType])->one();
        if($myrec==null){
            $myrec = new Loanrepaymentrecord();
            $myrec->PayDate = $atdate;
            $myrec->MemberId = $memberId;
            $myrec->LoanType = $loanType;
            $myrec->RecordBy = Yii::$app->user->id;
            $myrec->RecordDate = date('Y-m-d');
        }
        $myrec->accruedInterest=$amount;
        $myrec->save();
    }
            
    /*
     * returns Loaned amount for a particular loan type for principal or Interest for a particular member for a particular date
     */
    public function getPaidAmount($memberid,$atDate,$loantype,$whichValue/* Principal or Interest*/){
        $mycon= Yii::$app->db;
        $retval=0;
        $stmt='Select * From loanrepaymentrecord where (MemberId=:memberid and PayDate=:paydate and LoanType=:loantype)';
                
      $myvalue =$mycon->createCommand($stmt) 
              ->bindParam(':memberid', $memberid) 
              ->bindParam(':paydate', $atDate)
              ->bindParam(':loantype', $loantype)
              ->queryOne();
      if($myvalue[$whichValue]){$retval+=$myvalue[$whichValue];}
      //echo "Paid Amount: ".$retval." ; memberId: ".$memberid." ; at Date: ".$atDate." ; loantype: ".$loantype." ; which Value: ".$whichValue."<br>";
      return $retval;
    }
    /*
     * returns Loaned amount for a particular loan type for principal or Interest for a particular member for a particular date
     */
    public function getLoanedAmount($memberid,$atDate,$loantype){
        /*$mycon= Yii::$app->db;
        $retval=0;
        $stmt='Select Amount From loanstaken where (MemberId=:memberid and LoanedDate=:paydate and loanType=:loantype)';
                
      $myvalue =$mycon->createCommand($stmt) 
              ->bindParam(':memberid', $memberid) 
              ->bindParam(':paydate', $atDate)
              ->bindParam(':loantype', $loantype);
      $retval+=$myvalue->queryScalar();*/
      //echo "Loaned Amount: ".$retval."; Member ID: ".$memberid." ; At Date: ".$atDate."; Loan Type: ".$loantype."<br>";
        $myloan=Loanstaken::find()->where(['MemberId'=>$memberid,'LoanedDate'=>$atDate,'loanType'=>$loantype])->one();
        $retval=(!$myloan==null)? $myloan->Amount:0;
        
      return $retval;
    }
    /**
     * 
     * @param type $memberId
     * @param type $atDate
     * @param type $loanType
     * @param type $loanTpeName
     * @return type $interest amount(double)
     */
    public function getInterestDue($memberId,$atDate,$loanType,$loanTpeName){
        $book=Yii::$app->postings;
        
        $totalBF =$book->getBroughtForward($memberId,$atDate ,"Liability","loan",$loanTpeName);
            //Get amount paid from loanRepaymentRecord
            $amountPaid = $this->getPaidAmount($memberId,$atDate,$loanType,"Principal"/* Principal or Interest*/);
            //$loanAmt=$this->getLoanedAmount($memberId, $atDate, $loanType);
            //get accountNo
            $acNo=$book->getAccountNo('recievable on '.$loanTpeName,"Asset",$memberId,2);
            $interestBF=$this->getInterestBal($acNo,$atDate);
            $bal=$totalBF-$amountPaid;
            $interestRate= $this->getApplicableInterest($memberId, $loanType, $atDate);
            $interest=(($bal-$interestBF)*$interestRate/100);//interestBF is -ve
            //echo "getInterestDue:- memberId: ".$memberId."; atDate: ".$atDate."; loanType: ".$loanType."; Balance: ".$bal."; loanTypeName: ".$loanTpeName."; acNo: ".$acNo."; amountPaid: ".$amountPaid."; Interest BF: ".$interestBF."; interest: ".$interest."</br>";
            return $interest;
    }
    /**
     * 
     * @param type $acNo
     * @param type $acName
     * @param type $acTypeName
     * @param type $atDate
     * @return double
     */
    public function getInterestBal($acNo,$atDate){
        $book=Yii::$app->postings;
        $retval=0.0;
        //search loan entries from ledger for member before 'atDate' and get o/s amount
        if($acNo){// Account No is Found
            $retval=$book->getLedgerBalWrtUs($book->getLedgerBalance($acNo,$atDate),$book->getAcTypeNoFromNo($acNo));
            if(empty($retval))
            {
                $retval=0.0;
            }
        }/*else{
            $book->createAccount($acName, $acTypeName);
            $retval=0.0;
        }*/
        //Return o/s amount
       // echo "Posting-getBroughtForward: ".$retval." ; memberId: ".$memberId." ; At Date: ".$atDate." ; acTypeName : ".$acTypeName." ; AcPartName: ".$AcPartName."<br>";
            return $retval;
    }
    
    
    public function getAccountType($AcNo){
        $qry=(new yii\db\Query());
        $row= $qry->select('*')->from('accountnames')->where(['id'=>$AcNo])->one();
        return $row['AcType'] ;
    }
    
    /**
     * 
     * @param type $memeberId
     * @param type $atDate
     */
    public function getTotalInterestBal($memberId,$atDate){
        $book=Yii::$app->postings;
        $totalBF=0.0;
        $loanTypes=  $this->getLoanTypes($atDate) ;
        foreach($loanTypes as $loantype){
            $acNo=$book->getAccountNo('recievable on '.$loantype["loanTypeName"],'Asset',$memberId,2); 
            $totalBF+=$this->getInterestBal($acNo,  $atDate);
            
        }
        //echo "getTotalInterestBal:- memberId: ".$memberId."; atDate: ".$atDate,"; acNo: ".$acNo."; totalBF: ".$totalBF.";</br>";
        return -$totalBF;
    }
    public function getAccountName($AcNo){
        $qry=(new yii\db\Query());
        $row= $qry->select('*')->from('accountnames')->where(['id'=>$AcNo])->one();
        return $row['AcName'] ;            
    }
}
