<?php

namespace backend\modules\finance;

class Module extends \yii\base\Module
{
    public $controllerNamespace = 'backend\modules\finance\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
