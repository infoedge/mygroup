<?php

namespace backend\modules\finance\models;

use Yii;

/**
 * This is the model class for table "loans".
 *
 * @property integer $id
 * @property integer $loanType
 * @property double $Amount
 * @property double $Duration
 * @property double $interest
 * @property string $DateStart
 * @property string $DateEnd
 * @property string $RecordDate
 * @property integer $RecordBy
 *
 * @property Loantypes $loanType0
 */
class Loans extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'loans';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['loanType', 'Amount', 'Duration', 'interest', 'DateStart', 'RecordBy'], 'required'],
            [['loanType', 'RecordBy'], 'integer'],
            [['Amount', 'Duration', 'interest'], 'number'],
            [['DateStart', 'DateEnd', 'RecordDate'], 'safe']
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'loanType' => Yii::t('app', 'Loan Type'),
            'Amount' => Yii::t('app', 'Max Amount(KShs)'),
            'Duration' => Yii::t('app', 'Duration (Months)'),
            'interest' => Yii::t('app', 'Interest Rate(%)'),
            'DateStart' => Yii::t('app', 'Start Date'),
            'DateEnd' => Yii::t('app', 'End Date'),
            'RecordDate' => Yii::t('app', 'Record Date'),
            'RecordBy' => Yii::t('app', 'Record By'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getLoanType0()
    {
        return $this->hasOne(Loantypes::className(), ['id' => 'loanType']);
    }
}
