<?php

namespace backend\modules\Finance\models;

use Yii;
use backend\modules\finance\models\Loaninterest;

/**
 * This is the model class for table "loanrepaymentrecord".
 *
 * @property integer $id
 * @property integer $MemberId
 * @property integer $LoanType
 * @property double $Principal
 * @property double $Interest
 * @property string $PayDate
 * @property double $accruedInterest
 * @property string $CashbookTrId
 * @property integer $RecordBy
 * @property string $RecordDate
 *
 * @property Loantypes $loanType
 * @property Members $member
 * @property User $recordBy
 */
class Loanrepaymentrecord extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public $osAmount;
    public $exPrincipal;
    public $exInterest;
    public $dueDate;
    public static function tableName()
    {
        return 'loanrepaymentrecord';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['MemberId', 'LoanType', 'PayDate'], 'required'],
            [['MemberId', 'LoanType'], 'integer'],
            [['Principal', 'Interest','accruedInterest'], 'number'],
            [['Principal', 'Interest'], 'default','value'=>'0'],
            [['PayDate'], 'safe']
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'MemberId' => Yii::t('app', 'Members Name'),
            'LoanType' => Yii::t('app', 'Loan Type'),
            'Principal' => Yii::t('app', 'Principal (KShs)'),
            'Interest' => Yii::t('app', 'Interest (KShs)'),
            'PayDate' => Yii::t('app', 'Pay Date'),
            'accruedInterest' => Yii::t('app', 'Accrued Interest'),
            'CashbookTrId' => Yii::t('app', 'Cashbook Transaction No'),
            'RecordBy' => Yii::t('app', 'Record By'),
            'RecordDate' => Yii::t('app', 'Record Date'),
            'osAmount' =>Yii::t('app', 'Outstanding Amount'),
            'dueDate' =>Yii::t('app', 'Due Date'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getLoanType()
    {
        return $this->hasOne(Loantypes::className(), ['id' => 'LoanType']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getMember()
    {
        return $this->hasOne(Members::className(), ['id' => 'MemberId']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getRecordBy()
    {
        return $this->hasOne(User::className(), ['id' => 'RecordBy']);
    }
    public function getOsBal(){
        //getTotalBroughtForward($myMemberIds[$i]["memId"],$DBMeetingDate)
        $book=Yii::$app->postings;
        //$myloantypes = $this->getLoanTypes($atDate);
        $totalBF=0;
        //for($i=0;$i<count($myloantypes);$i++){
            $totalBF +=$book->getBroughtForward($this->MemberId,$this->PayDate ,"Liability","loan",$this->getLoanTypeName()); 
            $this->osAmount=$totalBF;
        //}
        //echo "Total B/F : ".$totalBF." ; memberId: ".$memberId." ; at Date: ".$atDate."<br>";
        /*if($this->osAmount>0){$this->getDueDate();}
        else{$this->dueDate='';}
        */return $totalBF;
    }
    /*
     * Returns an array with the loantypes model in Desc Order
     */
    public function getLoanTypeName(){
        $query= (new \yii\db\Query());
        $myloantypes= $query->select('*')
                ->from('loantypes ')
                
                ->where('id=:id',[':id'=>$this->LoanType])->one();
                //echo "getLoanTypeName: ".$myloantypes["loanTypeName"]." ; loanTypeNo:".$loanTypeNo."<br>";
        return $myloantypes["loanTypeName"];
    }
    /**
     * returns due date from loanrepaymentrecord
     */
    public function getDueDate(){
        $query= (new \yii\db\Query());
        $myqry = $query->select('max(LoanedDate) as myLoanedDate,Duration, Interest')
                ->from('loantaken')
                ->where('MemberId=:memberid and loanType=:loanType',[':memberid'=>$this->MemberId,':loanType'=>$this->LoanType])
                ->one();
        /**
         * $date = date_create('2000-01-01');
            date_add($date, date_interval_create_from_date_string('10 days'));
            echo date_format($date, 'Y-m-d');
         */
        $date= date_create($myqry['myLoanedDate']);
        date_add($date, date_interval_create_from_date_string($myqry['Duration'].' months'));
        $this->dueDate = date_format($date, 'M Y');
    }
    /*
     * return due_date for a loantype for a particular member at a given date from loanstaken table
     */
    public function getLoanDueDate($payDate){
        /*$myquery = (new yii\db\Query())
                    ->select('LoanedDate, dueDate')
                    ->from('loanstaken')
                    ->where('MemberId=:MemberId AND loanType =:loanType',[':MemberId'=>$this->MemberId, ':loanType'=>$this->loanType])
                    ->andWhere(['<','LoanedDate',$payDate])
                    ->orderBy(['LoanedDate'=>SORT_DESC])
                    ->one();
        if(!($myquery->dueDate)==null){
            return $myquery->dueDate;
        } 
        return '';*/
        $mymodel=  Loanstaken::find()
                ->where(['MemberId'=>$this->MemberId,'loanType'=>$this->LoanType])
                ->andWhere(['<','LoanedDate',$payDate])
                ->orderBy(['LoanedDate'=>SORT_DESC])
                ->one();
        return $mymodel['dueDate'];
    }
}
