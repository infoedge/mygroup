<?php

namespace backend\modules\finance\models;

use Yii;

/**
 * This is the model class for table "transactiontypes".
 *
 * @property integer $id
 * @property string $TrtypeName
 * @property string $TrTypeSymbol
 *
 * @property Cashbook[] $cashbooks
 * @property Ledger[] $ledgers
 */
class Transactiontypes extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'transactiontypes';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['TrtypeName', 'TrTypeSymbol'], 'required'],
            [['TrtypeName'], 'string', 'max' => 45],
            [['TrTypeSymbol'], 'string', 'max' => 2]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'TrtypeName' => Yii::t('app', 'Transaction Type Name'),
            'TrTypeSymbol' => Yii::t('app', 'Transaction Type Symbol'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCashbooks()
    {
        return $this->hasMany(Cashbook::className(), ['Trtype' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getLedgers()
    {
        return $this->hasMany(Ledger::className(), ['TrType' => 'id']);
    }
}
