<?php

namespace backend\modules\Finance\models;

use Yii;

/**
 * This is the model class for table "loanstaken".
 *
 * @property integer $id
 * @property integer $MemberId
 * @property integer $loanType
 * @property double $Amount
 * @property string $LoanedDate
 * @property double $Duration
 * @property double $interest
 * @property double dueDate
 * @property string $RecordDate
 * @property integer $RecordBy
 *
 * @property Loantypes $loanType0
 * @property Members $member
 */
class Loanstaken extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'loanstaken';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['loanType', 'Amount',  'Duration', 'interest','dueDate'], 'required'],
            [[ 'loanType'], 'integer'],
            [['Amount', 'Duration', 'interest'], 'number'],
            //[['LoanedDate'], 'safe']
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'MemberId' => Yii::t('app', 'Member ID'),
            'loanType' => Yii::t('app', 'Loan Type'),
            'Amount' => Yii::t('app', 'Amount'),
            'LoanedDate' => Yii::t('app', 'Loaned Date'),
            'Duration' => Yii::t('app', 'Duration'),
            'interest' => Yii::t('app', 'Interest'),
            'dueDate' => Yii::t('app', 'Due Date'),
            'RecordDate' => Yii::t('app', 'Record Date'),
            'RecordBy' => Yii::t('app', 'Record By'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getLoanType0()
    {
        return $this->hasOne(Loantypes::className(), ['id' => 'loanType']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getMember()
    {
        return $this->hasOne(Members::className(), ['id' => 'MemberId']);
    }
}
