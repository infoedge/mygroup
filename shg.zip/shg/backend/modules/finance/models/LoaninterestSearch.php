<?php

namespace backend\modules\finance\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use backend\modules\finance\models\Loaninterest;

//use backend\modules\finance\models\Loantypes;
//use common\models\Members;

/**
 * LoaninterestSearch represents the model behind the search form about `\backend\modules\finance\models\Loaninterest`.
 */
class LoaninterestSearch extends Loaninterest
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id'], 'integer'],
            [['Interest','Duration','Amount'], 'number'],
            [['DateStart', 'DateEnd', 'memberId', 'loanType'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Loaninterest::find();

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }
        $query->joinWith('memberParticulars');
        $query->joinWith('loanType0');
        $query->andFilterWhere([
            'id' => $this->id,
            
            'Amount' => $this->Amount,
            'Interest' => $this->Interest,
            'Duration' => $this->Duration,
            'DateStart' => $this->DateStart,
            'DateEnd' => $this->DateEnd,
            'RecordBy' => $this->RecordBy,
            'RecordDate' => $this->RecordDate,
        ]);
        $query->andFilterWhere(['like','memberparticulars.PersonsName', $this->memberId])
                ->andFilterWhere(['like','loantypes.loanTypeName', $this->loanType,]);
        return $dataProvider;
    }
}
