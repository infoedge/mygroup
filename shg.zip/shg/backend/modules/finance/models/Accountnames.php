<?php

namespace backend\modules\finance\models;

use Yii;

/**
 * This is the model class for table "accountnames".
 *
 * @property integer $id
 * @property integer $AcType
 * @property string $AcName
 *
 * @property Accounttypes $acType
 * @property Actomember[] $actomembers
 * @property Cashbook[] $cashbooks
 * @property Cashbook[] $cashbooks0
 * @property Ledger[] $ledgers
 * @property Ledger[] $ledgers0
 */
class Accountnames extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'accountnames';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['AcType', 'AcName'], 'required'],
            [['AcType'], 'integer'],
            [['AcName'], 'string', 'max' => 45],
            [['AcName'], 'unique']
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'AcType' => Yii::t('app', 'Account Type'),
            'AcName' => Yii::t('app', 'Account Name'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getAcType()
    {
        return $this->hasOne(Accounttypes::className(), ['id' => 'AcType']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getActomembers()
    {
        return $this->hasMany(Actomember::className(), ['AcNameId' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCashbooks()
    {
        return $this->hasMany(Cashbook::className(), ['Accountid' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCashbooks0()
    {
        return $this->hasMany(Cashbook::className(), ['RefAcctId' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getLedgers()
    {
        return $this->hasMany(Ledger::className(), ['RefAcId' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getLedgers0()
    {
        return $this->hasMany(Ledger::className(), ['AccountId' => 'id']);
    }
}
