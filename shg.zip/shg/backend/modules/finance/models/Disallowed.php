<?php

namespace backend\modules\finance\models;

use Yii;
use yii\base\Model;

class Disallowed extends Model{
    public $backlink;
    public $page;
}
?>