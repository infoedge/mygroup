<?php

namespace backend\modules\Finance\models;

use Yii;

/**
 * This is the model class for table "loantypes".
 *
 * @property integer $id
 * @property string $loanTypeName
 * @property string $RecordDate
 * @property integer $RecordBy
 *
 * @property Loaninterest[] $loaninterests
 * @property Loanrepaymentrecord[] $loanrepaymentrecords
 * @property Loans[] $loans
 * @property Loanstaken[] $loanstakens
 */
class Loantypes extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'loantypes';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['loanTypeName', 'RecordDate', 'RecordBy'], 'required'],
            [['RecordDate'], 'safe'],
            [['RecordBy'], 'integer'],
            [['loanTypeName'], 'string', 'max' => 45]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'loanTypeName' => Yii::t('app', 'Loan Type Name'),
            'RecordDate' => Yii::t('app', 'Record Date'),
            'RecordBy' => Yii::t('app', 'Record By'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getLoaninterests()
    {
        return $this->hasMany(Loaninterest::className(), ['loanType' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getLoanrepaymentrecords()
    {
        return $this->hasMany(Loanrepaymentrecord::className(), ['LoanType' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getLoans()
    {
        return $this->hasMany(Loans::className(), ['loanType' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getLoanstakens()
    {
        return $this->hasMany(Loanstaken::className(), ['loanType' => 'id']);
    }
}
