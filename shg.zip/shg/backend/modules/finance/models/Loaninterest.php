<?php

namespace backend\modules\finance\models;

use Yii;
use \common\models\Members;
use \common\models\Memberparticulars;

/**
 * This is the model class for table "loaninterest".
 *
 * @property integer $id
 * @property integer $loanType
 * @property integer $memberId
 * @property integer $Amount
 * @property double $Interest
 * @property string $DateStart
 * @property string $DateEnd
 * @property integer $RecordBy
 * @property string $RecordDate
 *
 * @property Loantypes $loanType0
 * @property Members $member
 * @property User $recordBy
 */
class Loaninterest extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'loaninterest';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['loanType', 'memberId','Amount','Interest','Duration', 'DateStart'], 'required'],
            [['loanType', 'memberId','Duration'], 'integer'],
            [['Interest','Amount'], 'number'],
            [['DateStart', 'DateEnd' ], 'safe']
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'loanType' => Yii::t('app', 'Loan Type'),
            'memberId' => Yii::t('app', 'Member Name'),
            'Amount' => Yii::t('app', 'Max Loan Amount (KShs)'),
            'Interest' => Yii::t('app', 'Interest (%)'),
            'Duration' => Yii::t('app', 'Loan Duration (Months)'),
            'DateStart' => Yii::t('app', 'Date Start'),
            'DateEnd' => Yii::t('app', 'Date End'),
            'RecordBy' => Yii::t('app', 'Record By'),
            'RecordDate' => Yii::t('app', 'Record Date'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getLoanType0()
    {
        return $this->hasOne(Loantypes::className(), ['id' => 'loanType']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getMember()
    {
        return $this->hasOne(Members::className(), ['id' => 'memberId']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getMemberParticulars()
    {
        return $this->hasOne(Memberparticulars::className(), ['id' => 'memberId']);
    }
    /**
     * @return \yii\db\ActiveQuery
     */
    public function getRecordBy()
    {
        return $this->hasOne(User::className(), ['id' => 'RecordBy']);
    }
    public function getPersonsName(){
        return $this->memberParticulars->PersonsName;      
    }
            
}
