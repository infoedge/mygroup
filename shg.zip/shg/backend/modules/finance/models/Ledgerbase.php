<?php

namespace backend\modules\finance\models;

use Yii;

/**
 * This is the model class for table "ledgerbase".
 *
 * @property integer $id
 * @property string $TrDate
 * @property string $AcName
 * @property string $actypename
 * @property integer $RefAcId
 * @property string $Description
 * @property string $TrTypeSymbol
 * @property double $Amount
 * @property integer $AccountId
 * @property string $MembersName
 * @property integer $mid
 * @property integer $pid
 */
class Ledgerbase extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'ledgerbase';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'RefAcId', 'AccountId', 'mid', 'pid'], 'integer'],
            [['TrDate', 'RefAcId', 'Description', 'AccountId'], 'required'],
            [['TrDate'], 'safe'],
            [['Amount'], 'number'],
            [['AcName'], 'string', 'max' => 80],
            [['actypename'], 'string', 'max' => 45],
            [['Description'], 'string', 'max' => 100],
            [['TrTypeSymbol'], 'string', 'max' => 2],
            [['MembersName'], 'string', 'max' => 91]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'TrDate' => Yii::t('app', 'Tr Date'),
            'AcName' => Yii::t('app', 'Ac Name'),
            'actypename' => Yii::t('app', 'Actypename'),
            'RefAcId' => Yii::t('app', 'Ref Ac ID'),
            'Description' => Yii::t('app', 'Description'),
            'TrTypeSymbol' => Yii::t('app', 'Tr Type Symbol'),
            'Amount' => Yii::t('app', 'Amount'),
            'AccountId' => Yii::t('app', 'Account ID'),
            'MembersName' => Yii::t('app', 'Members Name'),
            'mid' => Yii::t('app', 'Mid'),
            'pid' => Yii::t('app', 'Pid'),
        ];
    }
}
