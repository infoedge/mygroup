<?php

namespace backend\modules\finance\models;

use Yii;

/**
 * This is the model class for table "paymenttypes".
 *
 * @property integer $id
 * @property string $PmtType
 * @property string $PmtTypeSymbol
 *
 * @property Cashbook[] $cashbooks
 */
class Paymenttypes extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'paymenttypes';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['PmtType', 'PmtTypeSymbol'], 'required'],
            [['PmtType'], 'string', 'max' => 45],
            [['PmtTypeSymbol'], 'string', 'max' => 3]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'PmtType' => Yii::t('app', 'Payment Type'),
            'PmtTypeSymbol' => Yii::t('app', 'Payment Type Symbol'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCashbooks()
    {
        return $this->hasMany(Cashbook::className(), ['PaymentTypeId' => 'id']);
    }
}
