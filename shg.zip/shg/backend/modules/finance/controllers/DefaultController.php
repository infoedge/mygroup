<?php

namespace backend\modules\finance\controllers;

use yii\web\Controller;
use yii\filters\AccessControl;
use yii\filters\VerbFilter;

class DefaultController extends Controller
{   
    public function behaviors()
    {
        return [
            'access'=>[
                'class'=>  AccessControl::className(),
                'only'=>['index'],
                'rules'=>[
                    [
                        'allow'=>TRUE,
                        'roles'=>['@'],
                    ],
                    
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['post'],
                ],
            ],
        ];
    }
    public function actionIndex()
    {
        return $this->render('index');
    }
}
