<?php

namespace backend\modules\finance\controllers;

use Yii;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\base\Model;
use yii\db\Exception;
//use yii\web\ForbiddenHttpException;

use \backend\modules\finance\models\Loanrepaymentrecord;
use \backend\modules\finance\models\LoanrepaymentrecordSearch;
//use backend\modules\Finance\models\Loantypes;
use common\models\Members;

/**
 * LoanrepaymentrecordController implements the CRUD actions for Loanrepaymentrecord model.
 */
class LoanrepaymentrecordController extends Controller
{
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['post'],
                ],
            ],
        ];
    }

    /**
     * Lists all Loanrepaymentrecord models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new LoanrepaymentrecordSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Loanrepaymentrecord model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Loanrepaymentrecord model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        //$model = new Loanrepaymentrecord();
        /*$model->Principal=0;
        $model->interest=0;*/
        $myuser=Yii::$app->user;
        if($myuser->can('checkoff-loans')){
            $atDate = Yii::$app->session['MeetingDate'];
            $mymemberid = Yii::$app->session['myMemberId'];
            $myloantypes = $this->getLoanTypesList($atDate);
            $models= $this->findModels($myloantypes, $mymemberid, $atDate);
            if (Model::loadMultiple($models,Yii::$app->request->post()) /*&& (Model::validateMultiple($models)) */) {
                try{
                    foreach($models as $model){
                //if($model->load(Yii::$app->request->post())){
                        $model->RecordBy=Yii::$app->user->id;
                        $model->RecordDate=Date("Y-m-d");
                        $model->PayDate = $atDate;
                        $model->MemberId = $mymemberid;
                        $model->save();
                    }

                }
                catch(Exception $ex){
                    Yii::$app->session->setFlash('error','An error has occured while saving monthly payments: '.$ex->getMessage());
                }
                return $this->redirect(['/monthlypayments/create']);
            } //else {
                return $this->renderAjax('create', [
                    //'model' => $model,
                    'atDate' => $atDate,
                    'models' => $models,
                    'memberName' => $this->getMemberName($mymemberid),
                ]);
        }else{
            //throw new ForbiddenHttpException;
            Yii::$app->session['MyPage']="'Loan Repayment Record'";
            $this->redirect(['/disallowed/error']);
        }
        //}
    }

    /**
     * Updates an existing Loanrepaymentrecord model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('update', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Deletes an existing Loanrepaymentrecord model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Loanrepaymentrecord model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Loanrepaymentrecord the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Loanrepaymentrecord::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
    public function findModels($myloantypes,$memberId,$atDate){
        $models= Loanrepaymentrecord::find()
                ->where(['MemberId'=>$memberId,'PayDate'=>$atDate])
                ->all();
        
        if($models==null){
            //$models=array();
            
             
            $loantypecnt = count($myloantypes);
            if($loantypecnt==0){
                $models=[new Loanrepaymentrecord()];
            }else{
                for($i=0;$i< $loantypecnt; $i++){
                    //if($myloantype->StartDate <= $atDate AND (($myloantype->EndDate > $atDate) OR (empty($myloantype->EndDate))) ){

                    $models[]= (new Loanrepaymentrecord());
                    $models[$i]->MemberId=$memberId;
                    $models[$i]->LoanType = $myloantypes[$i]["loanType"];
                    $models[$i]->PayDate=$atDate;
                    $models[$i]->Principal=0;
                    $models[$i]->Interest=0;
                    $models[$i]->getOsBal();
                    $models[$i]->dueDate = $models[$i]->getLoanDueDate($atDate);
                }
            }
        }else{
                foreach($models as $model){
                    $model->getOsBal();
                    //update due date
                    $model->dueDate = $model->getLoanDueDate($atDate);
                }
            }
        return $models;
    }
    /*
     * returns an array with loantypes objects
     * 
     */
    public function getLoanTypesList($atDate){
        $con=\Yii::$app->db;
        $mysql_count='Select count(*) FROM loans WHERE (DateStart<=:atdate) AND ((DateEnd > :atdate) OR(DateEnd IS NULL))';
        $mysql = 'Select id AS lid,loanType FROM loans WHERE (DateStart<=:atdate) AND ((DateEnd > :atdate) OR(DateEnd IS NULL))';
        $myLoanTypeCount=$con->createCommand($mysql_count);
        $myLoanTypeCount->bindParam(':atdate', $atDate);
        $recCnt=$myLoanTypeCount->queryScalar();
        $myloantype=array();
        if($recCnt>0){
            $myloantypes=$con->createCommand($mysql);
            $myloantypes->bindParam(':atdate', $atDate);
            return $myloantypes->queryAll();
        }else{
            Yii::$app->session->setFlash('error','No Loan Types Available!!');
            return $myloantype;
        }
    }
    public function getMemberName($memberid) {
        $mymember= Members::findOne($memberid);
        return $mymember->getPersonsName();
    }
}
