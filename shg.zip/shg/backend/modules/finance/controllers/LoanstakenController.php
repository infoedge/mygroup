<?php

namespace backend\modules\finance\controllers;

use Yii;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\base\Model;
use yii\db\Exception;
//use yii\web\ForbiddenHttpException;
use DateTime;
use DateInterval;

use common\models\Members;
use backend\modules\finance\models\Loanstaken;
use backend\modules\finance\models\LoanstakenSearch;
use \backend\modules\finance\models\Loaninterest;

/**
 * LoanstakenController implements the CRUD actions for Loanstaken model.
 */
class LoanstakenController extends Controller
{
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['post'],
                ],
            ],
        ];
    }

    /**
     * Lists all Loanstaken models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new LoanstakenSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Loanstaken model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Loanstaken model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $myuser=Yii::$app->user;
        if($myuser->can('disburse-loans')){
            $mysession=Yii::$app->session;
            $atDate = $mysession["MeetingDate"];
            $memberid = $mysession["myMemberId"];
            $myloantypes = $this->getLoanTypesList($atDate);
            $models= $this->findModels($myloantypes, $memberid, $atDate);

            if (Model::loadMultiple($models,Yii::$app->request->post()) /*&& (Model::validateMultiple($models))*/ ) {
                if(Model::validateMultiple($models)) {
                    $this->saveLoansTaken($models,$memberid,$atDate);
                }
                else{
                    $mysession->setFlash('error', 'Unable to save due to invalid Data');
                }
                return $this->redirect(['/monthlypayments/create']);

            }
            return $this->renderAjax('create', [
                'models' => $models,
                'memberName' => $this->getMemberName($memberid),

                //'myloantypes' => $myloantypes,
            ]);
        }else{
            //throw new ForbiddenHttpException;
            Yii::$app->session['MyPage']="'Loan Disbursement Details'";
            $this->redirect(['/disallowed/error']);
        }
    }

    /**
     * Updates an existing Loanstaken model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('update', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Deletes an existing Loanstaken model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Loanstaken model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Loanstaken the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Loanstaken::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
    public function findModels($myloantypes,$memberId,$atDate){
        $models= Loanstaken::find()
                ->where(['MemberId'=>$memberId,'LoanedDate'=>$atDate])
                ->all();
        //$stmt="SELECT * FROM `loantypes` `lt` LEFT JOIN `loans` `lo` on `lt`.`id`= `lo`.`loanType` WHERE `lo`.`DateStart` <= '2013-10-10' AND ((`lo`.`DateEnd` IS NULL) OR (`lo`.`DateEnd` > '2013-10-10' ))";
        if($models==null){
            //$models=array();
            
             
            $loantypecnt = count($myloantypes);
            if($loantypecnt==0){
                $models[]= (new Loanstaken());
                 $models[0]->MemberId=$memberId;
                    //$models[0]->loanType = $myloantypes[$i]["lid"];
                    $models[0]->LoanedDate=$atDate;
                    $models[0]->Amount=0;
                    $models[0]->interest=0;
                    $models[0]->Duration=0;
                    
            }else{
                for($i=0;$i< $loantypecnt; $i++){
                    //if($myloantype->StartDate <= $atDate AND (($myloantype->EndDate > $atDate) OR (empty($myloantype->EndDate))) ){

                    $models[]= (new Loanstaken());
                    $models[$i]->MemberId=$memberId;
                    $models[$i]->loanType = $myloantypes[$i]["lid"];
                    $models[$i]->LoanedDate=$atDate;
                    $models[$i]->Amount=0;
                    $models[$i]->interest=$this->getIndividualInterest($memberId,$myloantypes[$i]["lid"],1,$atDate);
                    $models[$i]->Duration = $this->getIndividualInterest($memberId,$myloantypes[$i]["lid"],2,$atDate);
                    $date=new DateTime($models[$i]->LoanedDate);
                    $date->add(new DateInterval('P'.(string)($models[$i]->Duration).'M') );
                    $models[$i]->dueDate = $date->format('M, Y');
                    //$models[$i]->RecordDate = date('Y-m-d');
                    //$models[$i]->RecordBy = Yii::$app->user->id;
                }
            }
        }
        return $models;
    }
    /*
     * returns an array with loantypes objects
     * 
     */
    public function getLoanTypesList($atDate){
        $con=\Yii::$app->db;
        $mysql_count="SELECT count(*) FROM `loantypes` `lt` LEFT JOIN `loans` `lo` on `lt`.`id`= `lo`.`loanType` WHERE `lo`.`DateStart` <= :atDate AND ((`lo`.`DateEnd` IS NULL) OR (`lo`.`DateEnd` > :atDate ))";
        $mysql = "SELECT `lt`.`id` as lid  FROM `loantypes` `lt` LEFT JOIN `loans` `lo` on `lt`.`id`= `lo`.`loanType` WHERE `lo`.`DateStart` <= :atDate AND ((`lo`.`DateEnd` IS NULL) OR (`lo`.`DateEnd` > :atDate ))";
        $myLoanTypeCount=$con->createCommand($mysql_count);
        $myLoanTypeCount->bindParam(':atDate', $atDate);
        $recCnt=$myLoanTypeCount->queryScalar();
        $myloantype=array();
        if($recCnt>0){
            $myloantypes=$con->createCommand($mysql);
            $myloantypes->bindParam(':atDate', $atDate);
            return $myloantypes->queryAll();
        }else{
            Yii::$app->session->setFlash('error','No Loan Types Available!!');
            return $myloantype;
        }
    }
    public function getMemberName($memberid) {
        $mymember= Members::findOne($memberid);
        return $mymember->getPersonsName();
    }
    /*
     * confirms the individual interest or duration from interest rates table
     * if not found it creates a record and puts default interest rates and duration from 
     */
    public function getIndividualInterest($memberId,$loantype,$interestOrDuration/*interest= 1; Duration =2*/,$atDate){
        $con= Yii::$app->db;
        $mysql = 'select * from loaninterest where(loanType = :loanType And memberId = :memberId And DateStart <= :atDate And ((DateEnd > :atDate) OR (DateEnd IS NULL)))';
        $myrec =$con->createCommand($mysql)
                ->bindParam(':loanType',$loantype)
                ->bindParam(':memberId',$memberId)
                ->bindParam(':atDate',$atDate)
                ->queryOne();
        $myloan= $this->getLoanParameters($loantype,$atDate);
        if($myrec){
            //return the values
            switch($interestOrDuration){
                case 1://interest
                    return empty($myrec['Interest'])?(!empty($myloan['interest'])?$myloan['interest']:0):$myrec['Interest'];
                    
                case 2://Duration
                    return empty($myrec['Duration'])?(!empty($myloan['Duration'])?$myloan['Duration']:0):$myrec['Duration'];
                default:
                    return 0;
            }
        }else{//no value in interestrates table
            //check in loans table
            
            if($myloan!==Null){
                //update loansinterest table
                $mymodel= new Loaninterest();
                $mymodel->memberId=$memberId;
                $mymodel->loanType=$loantype;
                $mymodel->Amount = $myloan['Amount'];
                $mymodel->Duration = $myloan['Duration'];
                $mymodel->Interest = $myloan['interest'];
                $mymodel->DateStart=$myloan['DateStart'];
                $mymodel->DateEnd=$myloan['DateEnd'];
                $mymodel->RecordBy = Yii::$app->user->id;
                $mymodel->RecordDate = date('Y-m-d h:i:s');
                $mymodel->save(); 
                switch($interestOrDuration){
                case 1://interest
                    return !empty($myloan->interest)?$myloan->interest:0;
                    
                case 2://Duration
                    return !empty($myloan->Duration)?$myloan->Duration:0;
                default:
                    return 0;
                }//end switch
            }else{
                Yii::$app->session->setFlash('error','No loan Parameters found. Please set default parameters!');
            }
        }
    }
    public function getLoanParameters($loantype,$atDate){
        //
        $con= Yii::$app->db;
        $mysql = 'select * from loans where(loanType = :loanType  And DateStart <= :atDate And ((DateEnd > :atDate) OR (DateEnd IS NULL)))';
        
        return $con->createCommand($mysql)
                ->bindParam(':loanType', $loantype) 
                ->bindParam(':atDate', $atDate)
                ->queryOne();
    }
    public function saveLoansTaken($models,$memberid,$atDate){
        $mysession=Yii::$app->session;
        try{
                foreach($models as $model){
                $model->MemberId=$memberid;
                $model->LoanedDate = $atDate;
                
                $model->RecordDate = date('Y-m-d');
                $model->RecordBy = Yii::$app->user->id;
                $model->save();
                 
                }//return $this->redirect(['create']);
                $mysession->setFlash('success','Loans Taken Saved Successfully');
                 //return 1;
            }catch(Exception $ex){
                $mysession->setFlash('error','Unable to save '.$ex->getMessage());
                //return 0;
            }
    }
    
}
