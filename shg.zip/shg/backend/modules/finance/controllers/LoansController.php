<?php

namespace backend\modules\finance\controllers;

use Yii;
use backend\modules\finance\models\Loans;
use backend\modules\finance\models\LoansSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * LoansController implements the CRUD actions for Loans model.
 */
class LoansController extends Controller
{
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['post'],
                ],
            ],
        ];
    }

    /**
     * Lists all Loans models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new LoansSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Loans model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Loans model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        if(Yii::$app->user->can('SetDefaultLoanParameters')){
            $model = new Loans();
            empty($model->Amount)?$model->Amount=0:$model->Amount;
            empty($model->interest)?$model->interest=0:$model->interest;
            empty($model->Duration)?$model->Duration=0:$model->Duration;
            if ($model->load(Yii::$app->request->post()) ) {
                if($this->closePrevLoanParticulars($model->loanType, $model->DateStart)){
                    Yii::$app->session->setFlash('success','Previous particulars successfully closed!!');
                }else{
                    Yii::$app->session->setFlash('warning','No previous loan particulars to close!!');
                }
                $model->RecordBy=Yii::$app->user->id;
                $model->RecordDate = date('Y-m-d');
                $model->save();
                return $this->redirect(['index']);
            } else {
                return $this->render('create', [
                    'model' => $model,
                ]);
            }
        }else{
            //throw new ForbiddenHttpException;
            Yii::$app->session['MyPage']="'Set Default Loan Parameters'";
            $this->redirect(['/disallowed/error']);
        }
    }

    /**
     * Updates an existing Loans model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['index']);
        } else {
            return $this->render('update', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Deletes an existing Loans model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Loans model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Loans the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Loans::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
    private function closePrevLoanParticulars($loanType,$closeDate){
        $retval=false;
        $oldLoanModel=  Loans::find()->where(['loantype'=>$loanType,'DateEnd'=>null])
                        ->andWhere(['<','DateStart',$closeDate])->one();
        if(!$oldLoanModel==null){
            $oldLoanModel->DateEnd=$closeDate;
            $oldLoanModel->save();
            $retval=true;//success
        }
        return $retval;
    } 
}
