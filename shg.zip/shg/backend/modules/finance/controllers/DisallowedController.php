<?php

namespace backend\modules\finance\controllers;
use backend\modules\finance\models\Disallowed;
use yii\web\Controller;
use Yii;

class DisallowedController extends Controller
{
    public function actionError()
    {
        $model= new Disallowed;
        $model->backlink="/switchboard/index";
        $model->page=Yii::$app->session['MyPage'];
        return $this->render('error',[
            'backlink'=>$model->backlink,
            'page'=>$model->page,
        ]);
    }
    public function actionError1()
    {
        $model= new Disallowed;
        $model->backlink="/switchboard/index";
        $model->page=Yii::$app->session['MyPage'];
        return $this->renderAjax('error',[
            'backlink'=>$model->backlink,
            'page'=>$model->page,
        ]);
    }
    public function actionIndex()
    {
        return $this->render('index');
    }

}
