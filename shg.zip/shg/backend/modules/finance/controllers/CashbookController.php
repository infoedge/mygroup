<?php

namespace backend\modules\finance\controllers;

use Yii;
use common\models\Cashbook;
use common\models\CashbookSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;

/**
 * CashbookController implements the CRUD actions for Cashbook model.
 */
class CashbookController extends Controller
{
    public function behaviors()
    {
        return [
            'access'=>[
                'class'=>  AccessControl::className(),
                'only'=>['index'],
                'rules'=>[
                    [
                        'allow'=>TRUE,
                        'roles'=>['@'],
                    ],
                    
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['post'],
                ],
            ],
        ];
    }

    /**
     * Lists all Cashbook models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new CashbookSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Cashbook model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Cashbook model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new Cashbook();

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('create', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Updates an existing Cashbook model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('update', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Deletes an existing Cashbook model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    public function actionExpenditure()
    {
        if(Yii::$app->user->can('Post-Expenditure')){
        $book = Yii::$app->postings;
        $model = new \common\models\Cashbook(['scenario' => 'expenditure']);

        if ($model->load(Yii::$app->request->post())) {
            
            try{
                $model->validate();
                $model->Accountid=$book->confirmAcctNo('Cash','Asset');
                $model->PaymentTypeId= $book->confirmPaymentTypeNo('Cash');
                $model->RecordBy=Yii::$app->user->id;
                $model->RecordDate= date("Y-m-d");
                $book->postTransaction($model->Accountid,$model->RefAcctId,$model->TrDate,$model->Amount,$book->getTranactionType('Credit'),$model->Description,$pmtType=1 /*1=Cash*/);
                //return;
                Yii::$app->session->setFlash('success','Tansaction of '.$model->Amount.' successfully saved');
                $model = new \common\models\Cashbook(['scenario' => 'expenditure']);
            }
            catch(yii\base\Exception $ex){
                Yii::$app->session->setFlash('error','Unable to save Tansaction of '.$model->Amount);
            }
            
        }

        return $this->render('expenditure', [
            'model' => $model,
        ]);
        }else{
            Yii::$app->session['MyPage']="'Expenditure Entry'";
            $this->redirect(['/disallowed/error']);
        }
    }

    public function actionCreateAccount(){
        Yii::$app->session['expenditure'] = true;
        Yii::$app->session['returnpath']='/finance/cashbook/expenditure';
        $this->redirect(['/finance/accountnames/create']);
    }
            
    /**
     * Finds the Cashbook model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Cashbook the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Cashbook::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
