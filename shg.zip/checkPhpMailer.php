<?php echo function_exists('proc_open') ? "Yep,
    that will work" : "Sorry, that won't work";

